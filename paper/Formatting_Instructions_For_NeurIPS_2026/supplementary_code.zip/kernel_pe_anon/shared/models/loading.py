from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from shared.config import default_paths
from shared.specs import ModelSpec


@dataclass
class LoadedModel:
    spec: ModelSpec
    model: AutoModelForCausalLM

    def to(self, device: str) -> "LoadedModel":
        self.model.to(device)
        return self


@lru_cache(maxsize=8)
def load_model(
    spec: ModelSpec,
    torch_dtype: torch.dtype | None = None,
    device_map: str | None = None,
    attn_implementation: str | None = None,
) -> LoadedModel:
    resolved = _resolve_model_kwargs(spec.download_kwargs, torch_dtype)
    if device_map is not None:
        resolved["device_map"] = device_map
    if attn_implementation is not None:
        resolved["attn_implementation"] = attn_implementation
    model_source = _resolve_model_source(spec)
    model = AutoModelForCausalLM.from_pretrained(
        model_source,
        **resolved,
    )
    _apply_runtime_model_patches(spec, model)
    model.eval()
    return LoadedModel(spec=spec, model=model)


@lru_cache(maxsize=8)
def load_tokenizer(spec: ModelSpec, use_fast: bool = True):
    model_source = _resolve_model_source(spec)
    tokenizer = AutoTokenizer.from_pretrained(model_source, use_fast=use_fast)
    return tokenizer


def _resolve_model_source(spec: ModelSpec) -> str | Path:
    """Return the local weights directory if fully downloaded, else the HF repo ID.

    The download script places model files directly in models/<name>/, so we
    check for .safetensors or .bin weight shards there.  Using the local path
    avoids any attempt to fetch from the network during experiments.
    """
    local_dir = default_paths().models_dir / spec.name
    has_weights = any(
        local_dir.glob("*.safetensors")
    ) or any(
        local_dir.glob("*.bin")
    )
    if has_weights:
        return local_dir
    return spec.hf_id


def _resolve_model_kwargs(
    spec_kwargs: Mapping[str, Any] | None,
    override_dtype: torch.dtype | None,
) -> dict[str, Any]:
    kwargs: dict[str, Any] = {}
    if spec_kwargs:
        if isinstance(spec_kwargs, Mapping):
            items = spec_kwargs.items()
        else:
            items = spec_kwargs
        kwargs.update(dict(items))
    dtype = override_dtype or kwargs.pop("torch_dtype", None)
    if isinstance(dtype, str):
        dtype = getattr(torch, dtype)
    if dtype is not None:
        kwargs["torch_dtype"] = dtype
    return kwargs


def _apply_runtime_model_patches(spec: ModelSpec, model: AutoModelForCausalLM) -> None:
    """Apply model-specific runtime patches required for semantic correctness."""
    if spec.name == "tinyllama-nope-1.1b":
        _patch_llama_rotary_to_identity(model)


def _patch_llama_rotary_to_identity(model: AutoModelForCausalLM) -> None:
    """Disable RoPE on a loaded LLaMA-family model instance.

    The AntNLP TinyLlama-NoPE checkpoint requires disabling RoPE at runtime.
    We patch only this model instance by overriding its rotary embedding module
    to emit identity rotation factors (cos=1, sin=0).
    """
    core = getattr(model, "model", None)
    rotary = getattr(core, "rotary_emb", None)
    if rotary is None:
        raise RuntimeError(
            "tinyllama-nope-1.1b requires rotary disable patch, but model.model.rotary_emb was not found"
        )
    if getattr(rotary, "_nope_identity_patch_applied", False):
        return

    orig_forward = rotary.forward

    def _identity_forward(self, hidden_states, *args, **kwargs):
        cos, sin = orig_forward(hidden_states, *args, **kwargs)
        return torch.ones_like(cos), torch.zeros_like(sin)

    rotary.forward = _identity_forward.__get__(rotary, rotary.__class__)
    setattr(rotary, "_nope_identity_patch_applied", True)
