from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment2.interventions import build_rope_intervention_plan


def test_pair_interventions_are_supported_and_deterministic() -> None:
    plan = build_rope_intervention_plan(head_dim=128, intervention="ablate_pair_8", seed=7)
    assert plan.removed_indices == (8,)
    assert plan.target == "single_pair"

    rand_a = build_rope_intervention_plan(head_dim=128, intervention="random_pair", seed=7, random_draw=1)
    rand_b = build_rope_intervention_plan(head_dim=128, intervention="random_pair", seed=7, random_draw=1)
    rand_c = build_rope_intervention_plan(head_dim=128, intervention="random_pair", seed=7, random_draw=2)
    assert len(rand_a.removed_indices) == 1
    assert rand_a.removed_indices == rand_b.removed_indices
    assert rand_a.removed_indices != rand_c.removed_indices


def test_attenuation_interventions_are_supported_and_deterministic() -> None:
    high = build_rope_intervention_plan(head_dim=128, intervention="attenuate_high_75", seed=11)
    low = build_rope_intervention_plan(head_dim=128, intervention="attenuate_low_25", seed=11)
    assert high.target == "high"
    assert high.attenuation_percent == 75
    assert abs(float(high.attenuation_scale) - 0.25) < 1e-12
    assert len(high.removed_indices) > 0
    assert low.target == "low"
    assert low.attenuation_percent == 25
    assert abs(float(low.attenuation_scale) - 0.75) < 1e-12

    rand_a = build_rope_intervention_plan(head_dim=128, intervention="attenuate_random_50", seed=13, random_draw=0)
    rand_b = build_rope_intervention_plan(head_dim=128, intervention="attenuate_random_50", seed=13, random_draw=0)
    rand_c = build_rope_intervention_plan(head_dim=128, intervention="attenuate_random_50", seed=13, random_draw=1)
    assert rand_a.target == "random"
    assert rand_a.attenuation_percent == 50
    assert abs(float(rand_a.attenuation_scale) - 0.50) < 1e-12
    assert rand_a.removed_indices == rand_b.removed_indices
    assert rand_a.removed_indices != rand_c.removed_indices


def test_quick_manifest_builder_forces_spans_and_expands_random_draws(tmp_path: Path) -> None:
    base_manifest = tmp_path / "base.jsonl"
    rows = [
        {
            "phase": "phase2b",
            "split": "synthetic",
            "model": "llama-3.1-8b",
            "task": "long_range_retrieval",
            "seq_len": 1024,
            "intervention": "none",
            "seed": 0,
            "span": None,
            "random_draw": None,
            "run_id": "base",
        },
        {
            "phase": "phase2b",
            "split": "synthetic",
            "model": "llama-3.1-8b",
            "task": "long_range_retrieval",
            "seq_len": 1024,
            "intervention": "none",
            "seed": 1,
            "span": None,
            "random_draw": None,
            "run_id": "base",
        },
    ]
    base_manifest.write_text("".join(json.dumps(r) + "\n" for r in rows), encoding="utf-8")

    out_manifest = tmp_path / "quick.jsonl"
    cmd = [
        sys.executable,
        "scripts/experiment2_quick_manifest_build.py",
        "--input-manifest",
        str(base_manifest),
        "--output-manifest",
        str(out_manifest),
        "--run-id",
        "quick_run",
        "--phase",
        "quick_slope",
        "--model",
        "llama-3.1-8b",
        "--task",
        "long_range_retrieval",
        "--seeds",
        "0,1",
        "--force-spans",
        "32,64",
        "--source-interventions",
        "none",
        "--expand-interventions",
        "none,random_strong",
        "--random-draws",
        "3",
    ]
    subprocess.run(cmd, check=True, cwd=Path(__file__).resolve().parents[1])

    built = [
        json.loads(line)
        for line in out_manifest.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    # rows = seeds(2) * spans(2) * conditions(1 none + 3 random draws)
    assert len(built) == 16
    assert all(r["phase"] == "quick_slope" for r in built)
    assert all(r["run_id"] == "quick_run" for r in built)
    assert sorted({int(r["span"]) for r in built}) == [32, 64]
    random_rows = [r for r in built if r["intervention"] == "random_strong"]
    assert sorted({int(r["random_draw"]) for r in random_rows}) == [0, 1, 2]


def test_pair_report_emits_planned_contrasts(tmp_path: Path) -> None:
    agg_path = tmp_path / "aggregate_task_metrics.parquet"
    rows = []
    seeds = [0, 1, 2]
    span = 32
    model = "llama-3.1-8b"
    task = "long_range_retrieval"
    for seed in seeds:
        base = 0.30 + 0.01 * seed
        rows.append(
            {
                "split": "synthetic",
                "model": model,
                "task": task,
                "span": span,
                "seed": seed,
                "intervention": "none",
                "random_draw": None,
                "mean_accuracy": base,
                "floor_limited": False,
                "chance_accuracy": 0.10,
            }
        )
        for draw in range(3):
            rows.append(
                {
                    "split": "synthetic",
                    "model": model,
                    "task": task,
                    "span": span,
                    "seed": seed,
                    "intervention": "random_pair",
                    "random_draw": draw,
                    "mean_accuracy": base - 0.01,
                    "floor_limited": False,
                    "chance_accuracy": 0.10,
                }
            )
        pair_drops = {
            0: 0.12,
            8: 0.08,
            16: 0.05,
            40: 0.02,
            48: 0.01,
            56: -0.01,
        }
        for pair_idx, drop in pair_drops.items():
            rows.append(
                {
                    "split": "synthetic",
                    "model": model,
                    "task": task,
                    "span": span,
                    "seed": seed,
                    "intervention": f"ablate_pair_{pair_idx}",
                    "random_draw": None,
                    "mean_accuracy": base - drop,
                    "floor_limited": False,
                    "chance_accuracy": 0.10,
                }
            )
    pd.DataFrame(rows).to_parquet(agg_path, engine="pyarrow", index=False)

    families_json = tmp_path / "families.json"
    families_json.write_text(
        json.dumps([{"model": model, "task": task, "spans": [span]}], indent=2) + "\n",
        encoding="utf-8",
    )
    out_dir = tmp_path / "report"
    cmd = [
        sys.executable,
        "scripts/experiment2_pair_sweep_report.py",
        "--aggregate-task-metrics",
        str(agg_path),
        "--output-dir",
        str(out_dir),
        "--families-json",
        str(families_json),
        "--pair-indices",
        "0,8,16,40,48,56",
        "--floor-threshold",
        "0.15",
    ]
    subprocess.run(cmd, check=True, cwd=ROOT)

    planned_path = out_dir / "planned_contrasts.parquet"
    assert planned_path.exists()
    planned = pd.read_parquet(planned_path)
    assert {"pair0_vs_pair56", "low_third_vs_high_third"} <= set(planned["contrast_name"].tolist())
    assert {"effect_raw", "effect_over_headroom", "p_raw_holm", "p_headroom_holm"} <= set(planned.columns.tolist())
