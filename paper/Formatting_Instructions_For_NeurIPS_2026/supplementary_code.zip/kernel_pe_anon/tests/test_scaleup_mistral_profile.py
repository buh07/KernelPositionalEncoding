from __future__ import annotations

from experiment1.config import get_models_for_profile
from experiment2.config import model_names_for_profile


def test_scaleup_78b_mistral_profile_models() -> None:
    names = tuple(spec.name for spec in get_models_for_profile("scaleup_78b_mistral"))
    assert names == ("olmo-2-7b", "llama-3.1-8b", "mistral-7b-v0.1")


def test_experiment2_model_names_include_mistral_profile() -> None:
    names = model_names_for_profile("scaleup_78b_mistral")
    assert names == ("olmo-2-7b", "llama-3.1-8b", "mistral-7b-v0.1")
