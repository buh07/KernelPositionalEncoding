from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from experiment1.config import MODELS

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_ROOT = PROJECT_ROOT / "results"
OUT_DIR = RESULTS_ROOT / "reports" / "track_b_granularity_norm_v1"
EXPECTED_COMBOS = 36
NATURAL_DATASETS = {"wiki40b_en_pre2019", "codesearchnet_python_snapshot"}


@dataclass(frozen=True)
class VariantSpec:
    variant: str
    group: str
    bucket_size: int | None
    rank: int
    category: str


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Track B granularity + norm-aware report")
    parser.add_argument(
        "--out-dir",
        default=str(OUT_DIR),
        help="Output directory for markdown and parquet reports",
    )
    parser.add_argument(
        "--exclude-canonical",
        action="store_true",
        help="Exclude canonical_per_position from stratified summary tables.",
    )
    return parser.parse_args()


def _model_meta() -> pd.DataFrame:
    rows = []
    for model in MODELS:
        pe = model.pe_scheme
        if pe == "RoPE":
            family = "RoPE"
        elif pe == "learned-absolute":
            family = "AbsPE"
        else:
            family = "NoPE"
        rows.append(
            {
                "model": model.name,
                "norm": model.norm,
                "pe_scheme": pe,
                "model_family": family,
            }
        )
    return pd.DataFrame(rows)


def _discover_bucketed_variants() -> list[VariantSpec]:
    out: list[VariantSpec] = []
    pattern = re.compile(r"track_b_bucketed_mean(?:_b(?P<bucket>\d+))?_v1$")
    for group_dir in sorted(RESULTS_ROOT.glob("track_b_bucketed_mean*_v1")):
        if not group_dir.is_dir():
            continue
        match = pattern.fullmatch(group_dir.name)
        if not match:
            continue
        bucket_size = int(match.group("bucket")) if match.group("bucket") is not None else 32
        variant = f"bucketed_b{bucket_size}"
        out.append(
            VariantSpec(
                variant=variant,
                group=group_dir.name,
                bucket_size=bucket_size,
                rank=bucket_size,
                category="bucketed",
            )
        )
    return sorted(out, key=lambda item: item.bucket_size or 0)


def _variant_specs(include_canonical: bool) -> list[VariantSpec]:
    specs = [
        VariantSpec(
            variant="per_position",
            group="track_b",
            bucket_size=1,
            rank=1,
            category="per_position",
        ),
        VariantSpec(
            variant="shared_mean",
            group="track_b_shared_mean_v1",
            bucket_size=None,
            rank=10**9,
            category="shared",
        ),
    ]
    if include_canonical:
        specs.append(
            VariantSpec(
                variant="canonical_per_position",
                group="track_b_canonical_perpos_v1",
                bucket_size=1,
                rank=1,
                category="canonical",
            )
        )
    specs.extend(_discover_bucketed_variants())
    # Keep deterministic order: per_position -> canonical(optional) -> bucketed by bucket -> shared
    order = {"per_position": 0, "canonical_per_position": 1, "shared_mean": 3}
    return sorted(specs, key=lambda item: (order.get(item.variant, 2), item.rank))


def _load_track_a() -> pd.DataFrame:
    paths = sorted((RESULTS_ROOT / "track_a").glob("*/*/*/summary.parquet"))
    if not paths:
        raise FileNotFoundError("No Track A summaries found in results/track_a/**")
    df = pd.concat((pd.read_parquet(path) for path in paths), ignore_index=True)
    return df[["model", "dataset", "seq_len", "layer", "head", "mean_r2"]].rename(
        columns={"mean_r2": "track_a_r2"}
    )


def _load_variant(spec: VariantSpec) -> tuple[pd.DataFrame, dict[str, object]]:
    paths = sorted((RESULTS_ROOT / spec.group).glob("*/*/*/summary.parquet"))
    if not paths:
        raise FileNotFoundError(f"No Track B summaries found in results/{spec.group}/**")
    df = pd.concat((pd.read_parquet(path) for path in paths), ignore_index=True)
    reduced = df[
        ["model", "dataset", "seq_len", "layer", "head", "r2_raw", "r2_centered"]
    ].copy()
    reduced["variant"] = spec.variant
    reduced["group"] = spec.group
    reduced["bucket_size"] = spec.bucket_size
    reduced["rank"] = spec.rank
    combos = df[["model", "dataset", "seq_len"]].drop_duplicates().shape[0]
    meta = {
        "variant": spec.variant,
        "group": spec.group,
        "bucket_size": spec.bucket_size,
        "summary_files": len(paths),
        "present_combos": combos,
        "expected_combos": EXPECTED_COMBOS,
        "complete": len(paths) == EXPECTED_COMBOS and combos == EXPECTED_COMBOS,
    }
    return reduced, meta


def _markdown_table(df: pd.DataFrame, digits: int = 6) -> str:
    if df.empty:
        return "_(empty)_"
    out = df.copy()
    for col in out.columns:
        if pd.api.types.is_float_dtype(out[col]):
            out[col] = out[col].map(lambda x: f"{x:.{digits}f}" if pd.notna(x) else "NaN")
    headers = list(out.columns)
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for _, row in out.iterrows():
        lines.append("| " + " | ".join(str(row[h]) for h in headers) + " |")
    return "\n".join(lines)


def _build_summary_tables(combo_long: pd.DataFrame) -> dict[str, pd.DataFrame]:
    def summarize(df: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
        by_cols = group_cols + ["variant"] if group_cols else ["variant"]
        grouped = df.groupby(by_cols, as_index=False).agg(
            abs_a_minus_raw=("abs_a_minus_raw", "mean"),
            abs_a_minus_centered=("abs_a_minus_centered", "mean"),
            centered_minus_raw=("centered_minus_raw", "mean"),
        )
        grouped = grouped.sort_values(by_cols)
        grouped["recovery_vs_per_position"] = grouped["abs_a_minus_centered"]
        if group_cols:
            per_pos = grouped[grouped["variant"] == "per_position"][
                group_cols + ["abs_a_minus_centered"]
            ].rename(columns={"abs_a_minus_centered": "per_position_abs_gap"})
            grouped = grouped.merge(per_pos, on=group_cols, how="left")
            grouped["recovery_vs_per_position"] = grouped["per_position_abs_gap"] - grouped["abs_a_minus_centered"]
            grouped = grouped.drop(columns=["per_position_abs_gap"])
        else:
            per_pos_gap = grouped.loc[grouped["variant"] == "per_position", "abs_a_minus_centered"]
            if not per_pos_gap.empty:
                grouped["recovery_vs_per_position"] = float(per_pos_gap.iloc[0]) - grouped["abs_a_minus_centered"]
        return grouped

    tables: dict[str, pd.DataFrame] = {}
    tables["overall_all_layers"] = summarize(combo_long, [])
    tables["overall_early_layers"] = summarize(combo_long[combo_long["depth_slice"] == "early"], [])
    tables["by_dataset"] = summarize(combo_long, ["dataset"])
    tables["by_norm"] = summarize(combo_long, ["norm"])
    tables["by_family"] = summarize(combo_long, ["model_family"])
    tables["by_norm_family"] = summarize(combo_long, ["model_family", "norm"])
    tables["by_model"] = summarize(combo_long, ["model"])
    return tables


def _monotonicity_and_norm_delta(combo_long: pd.DataFrame, variants: list[str]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    natural = combo_long[
        (combo_long["dataset"].isin(NATURAL_DATASETS))
        & (combo_long["variant"].isin(variants))
    ].copy()
    per_combo = natural.pivot_table(
        index=["model", "dataset", "seq_len", "depth_slice"],
        columns="variant",
        values="abs_a_minus_centered",
    )
    ordered = [v for v in variants if v in per_combo.columns]
    step_rows = []
    monotonic_rows = []
    for depth_slice, slice_df in per_combo.groupby(level="depth_slice"):
        total = len(slice_df)
        if total == 0 or len(ordered) < 2:
            continue
        for left, right in zip(ordered[:-1], ordered[1:]):
            improved = (slice_df[right] <= slice_df[left]).sum()
            step_rows.append(
                {
                    "depth_slice": depth_slice,
                    "step": f"{left} -> {right}",
                    "improved_count": int(improved),
                    "total_count": int(total),
                    "improved_fraction": float(improved / total),
                }
            )
        monotonic_ok = pd.Series(True, index=slice_df.index)
        for left, right in zip(ordered[:-1], ordered[1:]):
            monotonic_ok &= slice_df[right] <= slice_df[left]
        monotonic_rows.append(
            {
                "depth_slice": depth_slice,
                "ordered_variants": " -> ".join(ordered),
                "monotonic_count": int(monotonic_ok.sum()),
                "total_count": int(total),
                "monotonic_fraction": float(monotonic_ok.mean()),
            }
        )

    step_df = pd.DataFrame(step_rows)
    monotonic_df = pd.DataFrame(monotonic_rows)

    # Norm interaction: delta_recovery = recovery_RMSNorm - recovery_LayerNorm.
    natural_norm = natural.copy()
    per_pos = natural_norm[natural_norm["variant"] == "per_position"][
        ["model", "dataset", "seq_len", "depth_slice", "abs_a_minus_centered"]
    ].rename(columns={"abs_a_minus_centered": "per_pos_gap"})
    merged = natural_norm.merge(per_pos, on=["model", "dataset", "seq_len", "depth_slice"], how="left")
    merged["recovery_vs_per_position"] = merged["per_pos_gap"] - merged["abs_a_minus_centered"]
    norm_delta_rows = []
    for depth_slice, depth_df in merged.groupby("depth_slice"):
        summary = (
            depth_df.groupby(["variant", "norm"], as_index=False)["recovery_vs_per_position"]
            .mean()
            .pivot(index="variant", columns="norm", values="recovery_vs_per_position")
        )
        if "RMSNorm" in summary.columns and "LayerNorm" in summary.columns:
            for variant, row in summary.iterrows():
                norm_delta_rows.append(
                    {
                        "depth_slice": depth_slice,
                        "variant": variant,
                        "recovery_layernorm": float(row["LayerNorm"]),
                        "recovery_rmsnorm": float(row["RMSNorm"]),
                        "delta_recovery_rms_minus_layer": float(row["RMSNorm"] - row["LayerNorm"]),
                    }
                )
    norm_delta_df = pd.DataFrame(norm_delta_rows).sort_values(["depth_slice", "variant"])
    return step_df, monotonic_df, norm_delta_df


def _invariant_checks(head_long: pd.DataFrame) -> pd.DataFrame:
    checks: list[dict[str, object]] = []
    pivot_raw = head_long.pivot_table(
        index=["model", "dataset", "seq_len", "layer", "head"],
        columns="variant",
        values="r2_raw",
    )
    if "per_position" in pivot_raw.columns:
        for variant in sorted(pivot_raw.columns):
            if variant == "per_position":
                continue
            diff = (pivot_raw["per_position"] - pivot_raw[variant]).abs()
            checks.append(
                {
                    "check": f"raw_invariance per_position vs {variant}",
                    "mean_abs_diff": float(diff.mean()),
                    "max_abs_diff": float(diff.max()),
                }
            )
    pivot_centered = head_long.pivot_table(
        index=["model", "dataset", "seq_len", "layer", "head"],
        columns="variant",
        values="r2_centered",
    )
    if "canonical_per_position" in pivot_centered.columns and "per_position" in pivot_centered.columns:
        diff = (pivot_centered["per_position"] - pivot_centered["canonical_per_position"]).abs()
        checks.append(
            {
                "check": "centered_equivalence per_position vs canonical_per_position",
                "mean_abs_diff": float(diff.mean()),
                "max_abs_diff": float(diff.max()),
            }
        )
    syn = head_long[head_long["dataset"] == "synthetic_random"]
    syn_diff = (syn["r2_centered"] - syn["r2_raw"]).abs()
    checks.append(
        {
            "check": "synthetic centered==raw",
            "mean_abs_diff": float(syn_diff.mean()),
            "max_abs_diff": float(syn_diff.max()),
        }
    )
    return pd.DataFrame(checks)


def main() -> None:
    args = _parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    meta = _model_meta()
    track_a = _load_track_a()
    specs = _variant_specs(include_canonical=not args.exclude_canonical)
    if not specs:
        raise RuntimeError("No Track B variants discovered.")

    variant_frames: list[pd.DataFrame] = []
    coverage_rows: list[dict[str, object]] = []
    for spec in specs:
        frame, coverage = _load_variant(spec)
        variant_frames.append(frame)
        coverage_rows.append(coverage)

    coverage_df = pd.DataFrame(coverage_rows).sort_values(["bucket_size", "variant"], na_position="first")
    head_long = pd.concat(variant_frames, ignore_index=True)
    merged = head_long.merge(track_a, on=["model", "dataset", "seq_len", "layer", "head"], how="inner")
    merged = merged.merge(meta, on="model", how="left")
    merged_all = merged.copy()
    merged_all["depth_slice"] = "all"
    merged_early = merged[merged["layer"].isin([0, 1])].copy()
    merged_early["depth_slice"] = "early"
    merged = pd.concat([merged_all, merged_early], ignore_index=True)
    merged["abs_a_minus_raw"] = (merged["track_a_r2"] - merged["r2_raw"]).abs()
    merged["abs_a_minus_centered"] = (merged["track_a_r2"] - merged["r2_centered"]).abs()
    merged["centered_minus_raw"] = merged["r2_centered"] - merged["r2_raw"]

    # Combo-level long table (model,dataset,len,depth_slice,variant).
    combo_long = (
        merged.groupby(
            ["model", "norm", "model_family", "dataset", "seq_len", "variant", "bucket_size", "depth_slice"],
            as_index=False,
            dropna=False,
        )
        .agg(
            track_a_mean=("track_a_r2", "mean"),
            raw_mean=("r2_raw", "mean"),
            centered_mean=("r2_centered", "mean"),
            abs_a_minus_raw=("abs_a_minus_raw", "mean"),
            abs_a_minus_centered=("abs_a_minus_centered", "mean"),
            centered_minus_raw=("centered_minus_raw", "mean"),
        )
        .sort_values(["model", "dataset", "seq_len", "depth_slice", "bucket_size"], na_position="last")
    )

    tables = _build_summary_tables(combo_long)
    granularity_order = (
        ["per_position"]
        + [spec.variant for spec in specs if spec.category == "bucketed"]
        + ["shared_mean"]
    )
    step_monotonic_df, monotonic_df, norm_delta_df = _monotonicity_and_norm_delta(combo_long, granularity_order)
    invariant_df = _invariant_checks(head_long)

    # Persist parquet outputs for downstream notebooks/docs.
    merged.to_parquet(out_dir / "head_metrics.parquet", index=False)
    combo_long.to_parquet(out_dir / "combo_metrics.parquet", index=False)
    coverage_df.to_parquet(out_dir / "coverage.parquet", index=False)
    step_monotonic_df.to_parquet(out_dir / "monotonicity_steps.parquet", index=False)
    monotonic_df.to_parquet(out_dir / "monotonicity_summary.parquet", index=False)
    norm_delta_df.to_parquet(out_dir / "norm_interaction.parquet", index=False)
    invariant_df.to_parquet(out_dir / "invariant_checks.parquet", index=False)

    lines: list[str] = []
    lines.append("# Track B Centering Granularity + Norm-Aware Analysis")
    lines.append("")
    lines.append(f"Snapshot: {datetime.now(timezone.utc).isoformat()}")
    lines.append("")
    lines.append("## Coverage")
    lines.append(_markdown_table(coverage_df))
    lines.append("")
    lines.append("## Invariant Checks")
    lines.append(_markdown_table(invariant_df))
    lines.append("")
    lines.append("## Overall (All Layers)")
    lines.append(_markdown_table(tables["overall_all_layers"]))
    lines.append("")
    lines.append("## Overall (Early Layers 0-1)")
    lines.append(_markdown_table(tables["overall_early_layers"]))
    lines.append("")
    lines.append("## Dataset-Stratified")
    lines.append(_markdown_table(tables["by_dataset"]))
    lines.append("")
    lines.append("## Norm-Stratified")
    lines.append(_markdown_table(tables["by_norm"]))
    lines.append("")
    lines.append("## Model-Family Stratified")
    lines.append(_markdown_table(tables["by_family"]))
    lines.append("")
    lines.append("## Model-Family x Norm")
    lines.append(_markdown_table(tables["by_norm_family"]))
    lines.append("")
    lines.append("## Model-Level Heterogeneity")
    lines.append(_markdown_table(tables["by_model"]))
    lines.append("")
    lines.append("## Granularity Monotonicity (Natural Data)")
    lines.append(_markdown_table(step_monotonic_df))
    lines.append("")
    lines.append("## Monotonicity Summary (Natural Data)")
    lines.append(_markdown_table(monotonic_df))
    lines.append("")
    lines.append("## Norm Interaction Delta (RMSNorm minus LayerNorm Recovery)")
    lines.append(_markdown_table(norm_delta_df))
    lines.append("")
    lines.append("## Per-Combo Long Table")
    lines.append(_markdown_table(combo_long))

    (out_dir / "summary.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote: {out_dir / 'summary.md'}")
    print(f"Wrote: {out_dir / 'head_metrics.parquet'}")
    print(f"Wrote: {out_dir / 'combo_metrics.parquet'}")
    print(f"Wrote: {out_dir / 'coverage.parquet'}")
    print(f"Wrote: {out_dir / 'monotonicity_steps.parquet'}")
    print(f"Wrote: {out_dir / 'monotonicity_summary.parquet'}")
    print(f"Wrote: {out_dir / 'norm_interaction.parquet'}")
    print(f"Wrote: {out_dir / 'invariant_checks.parquet'}")


if __name__ == "__main__":
    main()
