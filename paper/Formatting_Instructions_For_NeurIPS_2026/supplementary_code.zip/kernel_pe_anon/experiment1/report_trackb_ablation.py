from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_ROOT = PROJECT_ROOT / "results"
OUT_DIR = RESULTS_ROOT / "reports" / "track_b_shared_mean_v1"

TRACK_B_LEGACY = "track_b"
TRACK_B_CANONICAL = "track_b_canonical_perpos_v1"
TRACK_B_SHARED = "track_b_shared_mean_v1"

NATURAL_DATASETS = {"wiki40b_en_pre2019", "codesearchnet_python_snapshot"}
EXPECTED_COMBOS = 36


@dataclass(frozen=True)
class GroupLoad:
    name: str
    df: pd.DataFrame
    summary_files: int
    combos: int


def _load_track_a() -> pd.DataFrame:
    paths = sorted((RESULTS_ROOT / "track_a").glob("*/*/*/summary.parquet"))
    if not paths:
        raise FileNotFoundError("No Track A summary.parquet files found.")
    df = pd.concat((pd.read_parquet(p) for p in paths), ignore_index=True)
    return df[["model", "dataset", "seq_len", "layer", "head", "mean_r2"]].rename(
        columns={"mean_r2": "track_a_r2"}
    )


def _load_track_b_group(group: str, label: str) -> GroupLoad:
    paths = sorted((RESULTS_ROOT / group).glob("*/*/*/summary.parquet"))
    if not paths:
        raise FileNotFoundError(f"No Track B summaries found in results/{group}/**")
    df = pd.concat((pd.read_parquet(p) for p in paths), ignore_index=True)
    combos = (
        df[["model", "dataset", "seq_len"]]
        .drop_duplicates()
        .shape[0]
    )
    renamed = df[["model", "dataset", "seq_len", "layer", "head", "r2_centered", "r2_raw"]].rename(
        columns={
            "r2_centered": f"{label}_centered",
            "r2_raw": f"{label}_raw",
        }
    )
    return GroupLoad(name=label, df=renamed, summary_files=len(paths), combos=combos)


def _markdown_table(df: pd.DataFrame, float_digits: int = 6) -> str:
    if df.empty:
        return "_(empty)_"
    out = df.copy()
    for col in out.columns:
        if pd.api.types.is_float_dtype(out[col]):
            out[col] = out[col].map(lambda x: f"{x:.{float_digits}f}" if pd.notna(x) else "NaN")
    headers = list(out.columns)
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for _, row in out.iterrows():
        vals = [str(row[h]) for h in headers]
        lines.append("| " + " | ".join(vals) + " |")
    return "\n".join(lines)


def _build_combo_metrics(merged: pd.DataFrame) -> pd.DataFrame:
    combo = (
        merged.groupby(["model", "dataset", "seq_len"], as_index=False)
        .agg(
            track_a_mean=("track_a_r2", "mean"),
            legacy_centered=("legacy_centered", "mean"),
            legacy_raw=("legacy_raw", "mean"),
            canonical_centered=("canonical_centered", "mean"),
            canonical_raw=("canonical_raw", "mean"),
            shared_centered=("shared_centered", "mean"),
            shared_raw=("shared_raw", "mean"),
        )
        .sort_values(["model", "dataset", "seq_len"])
        .reset_index(drop=True)
    )
    for prefix in ("legacy", "canonical", "shared"):
        combo[f"abs_a_minus_{prefix}_centered"] = (combo["track_a_mean"] - combo[f"{prefix}_centered"]).abs()
        combo[f"abs_a_minus_{prefix}_raw"] = (combo["track_a_mean"] - combo[f"{prefix}_raw"]).abs()
    combo["delta_shared_vs_legacy_centered"] = (
        combo["abs_a_minus_legacy_centered"] - combo["abs_a_minus_shared_centered"]
    )
    combo["delta_shared_vs_canonical_centered"] = (
        combo["abs_a_minus_canonical_centered"] - combo["abs_a_minus_shared_centered"]
    )
    combo["abs_shared_centered_minus_raw"] = (combo["shared_centered"] - combo["shared_raw"]).abs()
    return combo


def _decision_text(combo: pd.DataFrame) -> tuple[str, float, float, float, float]:
    natural = combo[combo["dataset"].isin(NATURAL_DATASETS)]
    natural_shared_gap = float(natural["abs_a_minus_shared_centered"].mean())
    natural_canon_gap = float(natural["abs_a_minus_canonical_centered"].mean())
    natural_raw_gap = float(natural["abs_a_minus_shared_raw"].mean())
    improvement = natural_canon_gap - natural_shared_gap
    if natural_canon_gap > 0:
        improvement_ratio = improvement / natural_canon_gap
    else:
        improvement_ratio = 0.0

    if natural_shared_gap <= natural_raw_gap + 0.01:
        verdict = "Near parity with raw: per-position subtraction likely main driver."
    elif improvement_ratio >= 0.50:
        verdict = "Large reduction in natural-text centered gap: per-position confound likely dominant."
    elif improvement_ratio <= 0.20:
        verdict = "Little change in natural-text centered gap: genuine entanglement likely dominant."
    else:
        verdict = "Mixed shift: shared-mean helps but does not fully resolve the centered natural-text gap."
    return verdict, natural_shared_gap, natural_canon_gap, natural_raw_gap, improvement_ratio


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    track_a = _load_track_a()
    legacy = _load_track_b_group(TRACK_B_LEGACY, "legacy")
    canonical = _load_track_b_group(TRACK_B_CANONICAL, "canonical")
    shared = _load_track_b_group(TRACK_B_SHARED, "shared")

    coverage = pd.DataFrame(
        [
            {
                "group": TRACK_B_LEGACY,
                "expected_combos": EXPECTED_COMBOS,
                "present_summary_files": legacy.summary_files,
                "present_combos": legacy.combos,
            },
            {
                "group": TRACK_B_CANONICAL,
                "expected_combos": EXPECTED_COMBOS,
                "present_summary_files": canonical.summary_files,
                "present_combos": canonical.combos,
            },
            {
                "group": TRACK_B_SHARED,
                "expected_combos": EXPECTED_COMBOS,
                "present_summary_files": shared.summary_files,
                "present_combos": shared.combos,
            },
        ]
    )

    merged = (
        track_a.merge(legacy.df, on=["model", "dataset", "seq_len", "layer", "head"], how="left")
        .merge(canonical.df, on=["model", "dataset", "seq_len", "layer", "head"], how="left")
        .merge(shared.df, on=["model", "dataset", "seq_len", "layer", "head"], how="left")
    )
    combo = _build_combo_metrics(merged)

    dataset_agg = (
        combo.groupby("dataset", as_index=False)
        .agg(
            abs_a_minus_legacy_centered=("abs_a_minus_legacy_centered", "mean"),
            abs_a_minus_canonical_centered=("abs_a_minus_canonical_centered", "mean"),
            abs_a_minus_shared_centered=("abs_a_minus_shared_centered", "mean"),
            abs_a_minus_shared_raw=("abs_a_minus_shared_raw", "mean"),
            abs_shared_centered_minus_raw=("abs_shared_centered_minus_raw", "mean"),
        )
        .sort_values("dataset")
    )
    model_agg = (
        combo.groupby("model", as_index=False)
        .agg(
            abs_a_minus_legacy_centered=("abs_a_minus_legacy_centered", "mean"),
            abs_a_minus_canonical_centered=("abs_a_minus_canonical_centered", "mean"),
            abs_a_minus_shared_centered=("abs_a_minus_shared_centered", "mean"),
            abs_a_minus_shared_raw=("abs_a_minus_shared_raw", "mean"),
            abs_shared_centered_minus_raw=("abs_shared_centered_minus_raw", "mean"),
        )
        .sort_values("model")
    )
    length_agg = (
        combo.groupby("seq_len", as_index=False)
        .agg(
            abs_a_minus_legacy_centered=("abs_a_minus_legacy_centered", "mean"),
            abs_a_minus_canonical_centered=("abs_a_minus_canonical_centered", "mean"),
            abs_a_minus_shared_centered=("abs_a_minus_shared_centered", "mean"),
            abs_a_minus_shared_raw=("abs_a_minus_shared_raw", "mean"),
            abs_shared_centered_minus_raw=("abs_shared_centered_minus_raw", "mean"),
        )
        .sort_values("seq_len")
    )
    direct = combo[
        [
            "model",
            "dataset",
            "seq_len",
            "abs_a_minus_legacy_centered",
            "abs_a_minus_canonical_centered",
            "abs_a_minus_shared_centered",
            "delta_shared_vs_legacy_centered",
            "delta_shared_vs_canonical_centered",
        ]
    ].sort_values(["model", "dataset", "seq_len"])

    synthetic_sanity = (
        combo[combo["dataset"] == "synthetic_random"]
        .groupby("model", as_index=False)
        .agg(
            shared_abs_centered_minus_raw=("abs_shared_centered_minus_raw", "mean"),
            legacy_abs_centered_minus_raw=("legacy_centered", "mean"),
            canonical_abs_centered_minus_raw=("canonical_centered", "mean"),
        )
    )
    # Replace legacy/canonical placeholders with actual centered-vs-raw gaps.
    syn_subset = combo[combo["dataset"] == "synthetic_random"]
    legacy_gap = syn_subset.groupby("model")["legacy_centered"].mean() - syn_subset.groupby("model")["legacy_raw"].mean()
    canonical_gap = syn_subset.groupby("model")["canonical_centered"].mean() - syn_subset.groupby("model")["canonical_raw"].mean()
    synthetic_sanity["legacy_abs_centered_minus_raw"] = synthetic_sanity["model"].map(legacy_gap.abs())
    synthetic_sanity["canonical_abs_centered_minus_raw"] = synthetic_sanity["model"].map(canonical_gap.abs())

    verdict, natural_shared_gap, natural_canon_gap, natural_raw_gap, improvement_ratio = _decision_text(combo)

    combo.to_parquet(OUT_DIR / "comparison.parquet", index=False)

    lines: list[str] = []
    lines.append("# Track B Shared-Mean Ablation Comparison")
    lines.append("")
    lines.append(f"Snapshot: {datetime.now(timezone.utc).isoformat()}")
    lines.append("")
    lines.append("## Coverage Completeness")
    lines.append(_markdown_table(coverage, float_digits=0))
    lines.append("")
    lines.append("## Dataset Aggregates (`|TrackA - TrackB_centered|`)")
    lines.append(_markdown_table(dataset_agg))
    lines.append("")
    lines.append("## Model Aggregates (`|TrackA - TrackB_centered|`)")
    lines.append(_markdown_table(model_agg))
    lines.append("")
    lines.append("## Length Aggregates (`|TrackA - TrackB_centered|`)")
    lines.append(_markdown_table(length_agg))
    lines.append("")
    lines.append("## Direct Comparison: Per-Position vs Shared-Mean")
    lines.append(_markdown_table(direct))
    lines.append("")
    lines.append("## Synthetic Sanity Check (`centered ≈ raw` expected)")
    lines.append(_markdown_table(synthetic_sanity))
    lines.append("")
    lines.append("## Decision Rubric")
    lines.append("- Bands:")
    lines.append("  - Large reduction: `improvement_ratio >= 0.50`")
    lines.append("  - Little change: `improvement_ratio <= 0.20`")
    lines.append("  - Near parity with raw: `natural_shared_gap <= natural_raw_gap + 0.01`")
    lines.append("- Metrics:")
    lines.append(f"  - `natural_shared_gap = {natural_shared_gap:.6f}`")
    lines.append(f"  - `natural_canonical_gap = {natural_canon_gap:.6f}`")
    lines.append(f"  - `natural_raw_gap = {natural_raw_gap:.6f}`")
    lines.append(f"  - `improvement_ratio = {improvement_ratio:.6f}`")
    lines.append(f"- Verdict: **{verdict}**")
    lines.append("")
    lines.append("## Interpretation Notes")
    lines.append("- Shared-mean directly tests whether per-position subtraction caused centered natural-text attenuation.")
    lines.append("- Canonical per-position is retained as a frame-placement control baseline.")
    lines.append("- Track B raw remains the stable comparator to Track A.")

    (OUT_DIR / "comparison.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote: {OUT_DIR / 'comparison.md'}")
    print(f"Wrote: {OUT_DIR / 'comparison.parquet'}")


if __name__ == "__main__":
    main()
