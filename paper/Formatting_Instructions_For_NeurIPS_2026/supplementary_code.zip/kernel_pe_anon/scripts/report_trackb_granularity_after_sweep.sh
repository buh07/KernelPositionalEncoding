#!/usr/bin/env bash
set -euo pipefail

cd "/scratch2/anon/Kernel PE"
export PYTHONUNBUFFERED=1

LOG_DIR="logs/trackb"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/trackb_granularity_report_waiter.log"
exec > >(tee -a "$LOG_FILE") 2>&1

TARGET_COUNT=36
GROUPS=(
  "track_b_bucketed_mean_b8_v1"
  "track_b_bucketed_mean_b16_v1"
  "track_b_bucketed_mean_b64_v1"
)

echo "Waiting for granularity sweep completion..."
while true; do
  all_ready=1
  now=$(date -Iseconds)
  for group in "${GROUPS[@]}"; do
    count=$(find "results/${group}" -name summary.parquet 2>/dev/null | wc -l)
    echo "[$now] ${group}: ${count}/${TARGET_COUNT}"
    if [[ "${count}" -lt "${TARGET_COUNT}" ]]; then
      all_ready=0
    fi
  done
  if [[ "${all_ready}" -eq 1 ]]; then
    break
  fi
  sleep 300
done

echo "Sweep complete. Running report..."
.venv/bin/python experiment1/report_trackb_granularity_norm.py
echo "Report generation complete."
