#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


SHORT_TASKS = {"local_copy_offset", "local_key_match"}
LONG_TASKS = {"delayed_copy", "long_range_retrieval"}


def _parse_int_csv(raw: str) -> list[int]:
    out: list[int] = []
    seen: set[int] = set()
    for part in str(raw).split(","):
        tok = part.strip()
        if not tok:
            continue
        val = int(tok)
        if val not in seen:
            out.append(val)
            seen.add(val)
    return out


def _parse_str_csv(raw: str) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for part in str(raw).split(","):
        tok = part.strip()
        if not tok:
            continue
        if tok not in seen:
            out.append(tok)
            seen.add(tok)
    return out


def _task_span(task: str, short_span: int, long_span: int) -> int:
    if task in SHORT_TASKS:
        return int(short_span)
    if task in LONG_TASKS:
        return int(long_span)
    raise RuntimeError(f"Unsupported fastcheck task '{task}'.")


def main() -> None:
    ap = argparse.ArgumentParser(description="Build baseline-only fast-check synthetic manifest.")
    ap.add_argument("--output-manifest", type=Path, required=True)
    ap.add_argument("--summary-json", type=Path, required=True)
    ap.add_argument("--run-id", type=str, required=True)
    ap.add_argument("--phase", type=str, default="quick_fastchecks")
    ap.add_argument("--model", type=str, default="llama-3.1-8b")
    ap.add_argument("--seq-len", type=int, default=1024)
    ap.add_argument("--seeds", type=str, default="0,1,2")
    ap.add_argument("--tasks", type=str, default="local_copy_offset,delayed_copy,local_key_match,long_range_retrieval")
    ap.add_argument("--short-span", type=int, default=4)
    ap.add_argument("--long-span", type=int, default=32)
    ap.add_argument("--device", type=str, default="cuda")
    ap.add_argument("--notes-tag", type=str, default="fastcheck_baseline_decomposition")
    args = ap.parse_args()

    seeds = _parse_int_csv(args.seeds)
    tasks = _parse_str_csv(args.tasks)
    if not seeds:
        raise RuntimeError("No seeds provided.")
    if not tasks:
        raise RuntimeError("No tasks provided.")
    unknown = [t for t in tasks if t not in SHORT_TASKS | LONG_TASKS]
    if unknown:
        raise RuntimeError(f"Unsupported tasks in --tasks: {unknown}")

    rows: list[dict[str, object]] = []
    for task in tasks:
        span = _task_span(task, short_span=int(args.short_span), long_span=int(args.long_span))
        for seed in seeds:
            rows.append(
                {
                    "dataset": None,
                    "device": str(args.device),
                    "head_group": None,
                    "intervention": "none",
                    "model": str(args.model),
                    "notes": f"{args.notes_tag}|task={task}|span={span}",
                    "phase": str(args.phase),
                    "random_draw": None,
                    "run_id": str(args.run_id),
                    "scope": None,
                    "seed": int(seed),
                    "seq_len": int(args.seq_len),
                    "span": int(span),
                    "split": "synthetic",
                    "task": str(task),
                }
            )

    rows.sort(key=lambda r: (str(r["task"]), int(r["seed"])))
    args.output_manifest.parent.mkdir(parents=True, exist_ok=True)
    with args.output_manifest.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")

    summary = {
        "run_id": str(args.run_id),
        "phase": str(args.phase),
        "model": str(args.model),
        "seq_len": int(args.seq_len),
        "seeds": [int(x) for x in seeds],
        "tasks": tasks,
        "short_span": int(args.short_span),
        "long_span": int(args.long_span),
        "row_count": int(len(rows)),
        "output_manifest": str(args.output_manifest),
    }
    args.summary_json.parent.mkdir(parents=True, exist_ok=True)
    args.summary_json.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
