#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment2.config import MODEL_BY_NAME
from experiment2.execution import _build_restricted_candidates
from experiment2.tasks import build_token_pools, generate_task_examples
from shared.models.loading import load_tokenizer


def _parse_int_csv(raw: str) -> list[int]:
    out: list[int] = []
    seen: set[int] = set()
    for part in str(raw).split(","):
        tok = part.strip()
        if not tok:
            continue
        val = int(tok)
        if val not in seen:
            out.append(val)
            seen.add(val)
    return out


def _parse_str_csv(raw: str) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for part in str(raw).split(","):
        tok = part.strip()
        if not tok:
            continue
        if tok not in seen:
            out.append(tok)
            seen.add(tok)
    return out


def _span_for_task(task: str, short_span: int, long_span: int) -> int | None:
    if task in {"delayed_copy", "long_range_retrieval"}:
        return int(long_span)
    if task in {"local_copy_offset", "local_key_match"}:
        return int(short_span)
    return None


def main() -> None:
    ap = argparse.ArgumentParser(description="Oracle sanity checks for restricted-candidate evaluator path.")
    ap.add_argument("--model", type=str, default="llama-3.1-8b")
    ap.add_argument("--seq-len", type=int, default=1024)
    ap.add_argument("--tasks", type=str, default="local_copy_offset,delayed_copy,local_key_match,long_range_retrieval")
    ap.add_argument("--seeds", type=str, default="0,1,2")
    ap.add_argument("--count-per-task-seed", type=int, default=16)
    ap.add_argument("--candidate-size", type=int, default=10)
    ap.add_argument(
        "--candidate-policies",
        type=str,
        default="restricted_candidates_v1_structured_first,restricted_candidates_v1_structured_only,restricted_candidates_v1_random_only",
    )
    ap.add_argument("--short-span", type=int, default=4)
    ap.add_argument("--long-span", type=int, default=32)
    ap.add_argument("--aggregate-task-metrics", type=Path, default=None)
    ap.add_argument("--output-json", type=Path, required=True)
    args = ap.parse_args()

    if args.model not in MODEL_BY_NAME:
        raise SystemExit(f"Unknown model: {args.model}")
    spec = MODEL_BY_NAME[str(args.model)]
    tokenizer = load_tokenizer(spec)
    pools = build_token_pools(
        model_name=spec.name,
        vocab_size=int(tokenizer.vocab_size),
        special_ids=getattr(tokenizer, "all_special_ids", []),
    )

    tasks = _parse_str_csv(args.tasks)
    seeds = _parse_int_csv(args.seeds)
    policies = _parse_str_csv(args.candidate_policies)
    checks: list[dict[str, Any]] = []
    for task in tasks:
        span_override = _span_for_task(task, short_span=int(args.short_span), long_span=int(args.long_span))
        for seed in seeds:
            examples = generate_task_examples(
                task_name=task,
                model_name=spec.name,
                seq_len=int(args.seq_len),
                seed=int(seed),
                count=int(args.count_per_task_seed),
                pools=pools,
                span_override=span_override,
            )
            for ex in examples:
                seq_value_tokens = None
                if ex.task_name in {"local_key_match", "long_range_retrieval", "retrieval_bridge"}:
                    value_set = set(int(v) for v in pools.values)
                    seq_value_tokens = sorted({int(tok) for tok in ex.tokens if int(tok) in value_set})
                for pos, target in zip(ex.target_positions, ex.target_tokens):
                    for policy in policies:
                        cands = _build_restricted_candidates(
                            example=ex,
                            target=int(target),
                            position=int(pos),
                            pools=pools,
                            candidate_size=int(args.candidate_size),
                            candidate_policy_version=policy,
                            sequence_value_tokens=seq_value_tokens,
                        )
                        checks.append(
                            {
                                "task": task,
                                "seed": int(seed),
                                "policy": policy,
                                "example_id": ex.id,
                                "position": int(pos),
                                "candidate_count": int(len(cands)),
                                "unique": bool(len(set(cands)) == len(cands)),
                                "target_in_candidates": bool(int(target) in set(cands)),
                            }
                        )

    checks_df = pd.DataFrame(checks)
    payload: dict[str, Any] = {
        "model": spec.name,
        "seq_len": int(args.seq_len),
        "candidate_size": int(args.candidate_size),
        "checks_total": int(len(checks_df)),
        "target_in_candidates_rate": float(checks_df["target_in_candidates"].mean()),
        "candidate_size_consistent_rate": float((checks_df["candidate_count"] == int(args.candidate_size)).mean()),
        "unique_rate": float(checks_df["unique"].mean()),
        "by_policy": [],
        "restricted_full_vocab_parity": None,
        "status": "ok",
    }
    by_policy = (
        checks_df.groupby("policy", as_index=False)
        .agg(
            checks=("policy", "count"),
            target_in_candidates_rate=("target_in_candidates", "mean"),
            candidate_size_consistent_rate=("candidate_count", lambda s: float((s == int(args.candidate_size)).mean())),
            unique_rate=("unique", "mean"),
        )
        .sort_values("policy")
    )
    payload["by_policy"] = by_policy.to_dict(orient="records")

    if args.aggregate_task_metrics is not None and args.aggregate_task_metrics.exists():
        agg = pd.read_parquet(args.aggregate_task_metrics)
        if {"mean_accuracy_full_vocab", "mean_accuracy_restricted"}.issubset(set(agg.columns)):
            valid = agg[
                (agg["split"] == "synthetic")
                & (agg["intervention"] == "none")
                & (agg["mean_accuracy_full_vocab"].notna())
                & (agg["mean_accuracy_restricted"].notna())
            ].copy()
            if not valid.empty:
                diffs = (valid["mean_accuracy_restricted"] - valid["mean_accuracy_full_vocab"]).astype(float)
                payload["restricted_full_vocab_parity"] = {
                    "rows": int(len(valid)),
                    "mean_delta_restricted_minus_full": float(diffs.mean()),
                    "mean_abs_delta": float(diffs.abs().mean()),
                }

    if (
        payload["target_in_candidates_rate"] < 1.0
        or payload["candidate_size_consistent_rate"] < 1.0
        or payload["unique_rate"] < 1.0
    ):
        payload["status"] = "failed"

    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    if payload["status"] != "ok":
        raise SystemExit("Oracle sanity checks failed.")


if __name__ == "__main__":
    main()
