#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MODELS = ("llama-3.1-8b", "olmo-2-7b")


def _load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: Path, payload: dict) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def _compute_acceptance(acc: pd.DataFrame, chance: dict[str, float]) -> dict:
    summary = (
        acc.groupby(["layer", "feature", "condition"], as_index=False)["accuracy"]
        .mean()
        .copy()
    )
    summary["passes_chance_plus_10pp"] = summary.apply(
        lambda r: float(r["accuracy"]) >= float(chance[str(r["feature"])]) + 0.10,
        axis=1,
    )

    baseline = summary[summary["condition"] == "none"].copy()
    if baseline.empty:
        baseline = summary.copy()

    core_features = {"relative_position", "word_boundary"}

    strict_fail = (
        (baseline["layer"] >= 4)
        & (~baseline["passes_chance_plus_10pp"])
    )
    core_fail = (
        (baseline["layer"] >= 4)
        & (baseline["feature"].isin(core_features))
        & (~baseline["passes_chance_plus_10pp"])
    )
    legacy_fail = (
        (summary["layer"] >= 4)
        & (~summary["passes_chance_plus_10pp"])
    )

    return {
        "passes_chance_plus_10pp_all_features_layers_ge4": bool(len(baseline[strict_fail]) == 0),
        "passes_chance_plus_10pp_core_features_layers_ge4": bool(len(baseline[core_fail]) == 0),
        "n_fail_all_features_layers_ge4": int(len(baseline[strict_fail])),
        "n_fail_core_features_layers_ge4": int(len(baseline[core_fail])),
        "legacy_all_conditions_all_features_layers_ge4": bool(len(summary[legacy_fail]) == 0),
        "acceptance_scope": {
            "evaluated_condition": "none",
            "core_features": sorted(core_features),
            "notes": [
                "Backfilled after acceptance-scope bugfix: acceptance now evaluated on intact probes only.",
                "Legacy all-conditions value retained for backward auditability.",
            ],
        },
    }


def main() -> None:
    p = argparse.ArgumentParser(description="Backfill 3P2-A.2 probe_acceptance fields from existing artifacts")
    p.add_argument("--models", default=",".join(DEFAULT_MODELS))
    p.add_argument("--output-root", default="results/experiment3_phase2/exp3p2a_positional_broadcast")
    args = p.parse_args()

    models = [m.strip() for m in str(args.models).split(",") if m.strip()]
    output_root = ROOT / args.output_root

    for model in models:
        model_dir = output_root / model
        delta_path = model_dir / "delta_probe_comparison.json"
        acc_path = model_dir / "probe_accuracy.parquet"
        if not delta_path.exists() or not acc_path.exists():
            print(f"[skip] {model}: missing {delta_path} or {acc_path}")
            continue

        payload = _load_json(delta_path)
        chance = payload.get("chance_levels", {})
        if not chance:
            print(f"[skip] {model}: chance_levels missing in {delta_path}")
            continue

        acc = pd.read_parquet(acc_path)
        payload["probe_acceptance"] = _compute_acceptance(acc, chance)
        _write_json(delta_path, payload)
        print(f"[ok] updated {delta_path}")


if __name__ == "__main__":
    main()
