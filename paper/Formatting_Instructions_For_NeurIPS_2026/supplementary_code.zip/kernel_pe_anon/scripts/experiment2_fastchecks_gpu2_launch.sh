#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

RUN_TAG="${1:-fastchecks_$(date +%Y%m%d_%H%M%S)}"
LOG_ROOT="logs/experiment2/quick/${RUN_TAG}"
mkdir -p "${LOG_ROOT}"

tmux kill-session -t exp2_fastchecks_g2 2>/dev/null || true
tmux kill-session -t exp2_fastchecks_report 2>/dev/null || true

tmux new-session -d -s exp2_fastchecks_g2 \
  "cd '${ROOT_DIR}' && bash scripts/experiment2_fastchecks_gpu2_execute.sh '${RUN_TAG}' |& tee '${LOG_ROOT}/tmux_execute.log'"

tmux new-session -d -s exp2_fastchecks_report \
  "cd '${ROOT_DIR}' && bash scripts/experiment2_fastchecks_gpu2_report.sh '${RUN_TAG}' |& tee '${LOG_ROOT}/tmux_report.log'"

echo "Launched fast-check sessions:"
echo "  run_tag=${RUN_TAG}"
echo "  session=exp2_fastchecks_g2"
echo "  session=exp2_fastchecks_report"
echo "Logs: ${LOG_ROOT}"
