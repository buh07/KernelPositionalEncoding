#!/usr/bin/env bash
set -euo pipefail

QUEUE_FILE="${1:-logs/trackb/trackb_bucketed_queue.tsv}"
mkdir -p "$(dirname "$QUEUE_FILE")"

# Order jobs to prioritize heavier models and long context first.
JOB_GROUPS=(
  "track_b_bucketed_mean_b8_v1:8"
  "track_b_bucketed_mean_b16_v1:16"
  "track_b_bucketed_mean_b64_v1:64"
)
MODELS=(
  "tinyllama-nope-1.1b"
  "tinyllama-1.1b"
  "llama-3.2-1b"
  "gpt2-medium"
  "olmo-1b"
  "gpt2-small"
)
DATASETS=(
  "wiki40b_en_pre2019"
  "codesearchnet_python_snapshot"
  "synthetic_random"
)
SEQ_LENS=("1024" "256")

: > "$QUEUE_FILE"
for group_spec in "${JOB_GROUPS[@]}"; do
  output_group="${group_spec%%:*}"
  bucket_size="${group_spec##*:}"
  for model in "${MODELS[@]}"; do
    for dataset in "${DATASETS[@]}"; do
      for seq_len in "${SEQ_LENS[@]}"; do
        printf "%s\t%s\t%s\t%s\t%s\n" \
          "$output_group" "$bucket_size" "$model" "$dataset" "$seq_len" >> "$QUEUE_FILE"
      done
    done
  done
done

echo "Wrote $(wc -l < "$QUEUE_FILE") queued jobs to $QUEUE_FILE"
