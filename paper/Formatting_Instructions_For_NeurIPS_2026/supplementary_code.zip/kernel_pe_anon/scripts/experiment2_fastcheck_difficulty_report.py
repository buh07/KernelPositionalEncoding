#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd


def _parse_input_map(raw: str) -> dict[str, Path]:
    out: dict[str, Path] = {}
    for part in str(raw).split(","):
        tok = part.strip()
        if not tok:
            continue
        if "=" not in tok:
            raise RuntimeError(f"Invalid --inputs entry '{tok}'. Expected policy=path.")
        key, value = tok.split("=", 1)
        out[key.strip()] = Path(value.strip())
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description="Summarize baseline difficulty decomposition across candidate policies.")
    ap.add_argument(
        "--inputs",
        type=str,
        required=True,
        help="Comma-separated policy=aggregate_task_metrics.parquet entries.",
    )
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--model", type=str, default="llama-3.1-8b")
    args = ap.parse_args()

    policy_to_path = _parse_input_map(args.inputs)
    if "structured_first" not in policy_to_path:
        raise RuntimeError("inputs must include structured_first=... as anchor policy.")

    frames: list[pd.DataFrame] = []
    for policy, path in policy_to_path.items():
        if not path.exists():
            raise FileNotFoundError(f"Missing aggregate metrics for policy '{policy}': {path}")
        df = pd.read_parquet(path)
        need_cols = {"split", "model", "task", "span", "seed", "intervention", "mean_accuracy", "chance_accuracy"}
        missing = sorted(need_cols - set(df.columns))
        if missing:
            raise RuntimeError(f"{path} missing required columns: {missing}")
        sub = df[
            (df["split"] == "synthetic")
            & (df["model"] == args.model)
            & (df["intervention"] == "none")
        ][["model", "task", "span", "seed", "mean_accuracy", "chance_accuracy"]].copy()
        sub["policy"] = policy
        frames.append(sub)

    long_df = pd.concat(frames, ignore_index=True)
    if long_df.empty:
        raise RuntimeError("No baseline synthetic rows found for difficulty decomposition.")

    per_seed = (
        long_df.groupby(["model", "task", "span", "seed", "policy"], as_index=False)
        .agg(mean_accuracy=("mean_accuracy", "mean"), chance_accuracy=("chance_accuracy", "mean"))
    )

    by_policy = (
        per_seed.groupby(["model", "task", "span", "policy"], as_index=False)
        .agg(
            n=("seed", "count"),
            mean_accuracy=("mean_accuracy", "mean"),
            std_accuracy=("mean_accuracy", "std"),
            chance_accuracy=("chance_accuracy", "mean"),
        )
        .sort_values(["task", "span", "policy"])
    )

    pivot = by_policy.pivot_table(
        index=["model", "task", "span"],
        columns="policy",
        values="mean_accuracy",
        aggfunc="first",
    ).reset_index()
    if "structured_first" in pivot.columns:
        for policy in ("structured_only", "random_only"):
            if policy in pivot.columns:
                pivot[f"delta_{policy}_vs_structured_first"] = (
                    pivot[policy].astype(float) - pivot["structured_first"].astype(float)
                )

    summary: dict[str, Any] = {
        "generated_at": pd.Timestamp.utcnow().isoformat(),
        "model": str(args.model),
        "input_policies": sorted(policy_to_path.keys()),
        "input_paths": {k: str(v) for k, v in policy_to_path.items()},
        "rows_per_seed": int(len(per_seed)),
        "rows_by_policy": int(len(by_policy)),
        "notes": [
            "Baseline-only difficulty decomposition across restricted candidate policies.",
            "All metrics are exploratory and non-gating.",
        ],
    }
    if "delta_structured_only_vs_structured_first" in pivot.columns:
        summary["mean_delta_structured_only_vs_structured_first"] = float(
            pivot["delta_structured_only_vs_structured_first"].mean()
        )
    if "delta_random_only_vs_structured_first" in pivot.columns:
        summary["mean_delta_random_only_vs_structured_first"] = float(
            pivot["delta_random_only_vs_structured_first"].mean()
        )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    per_seed.to_parquet(args.output_dir / "difficulty_decomp_per_seed.parquet", engine="pyarrow", index=False)
    by_policy.to_parquet(args.output_dir / "difficulty_decomp_by_policy.parquet", engine="pyarrow", index=False)
    pivot.to_parquet(args.output_dir / "difficulty_decomp_summary.parquet", engine="pyarrow", index=False)
    (args.output_dir / "difficulty_decomp_summary.json").write_text(
        json.dumps({"summary": summary, "rows": pivot.to_dict(orient="records")}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
