#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

RUN_TAG="${1:-fastchecks_$(date +%Y%m%d_%H%M%S)}"
MODEL="llama-3.1-8b"
PHASE="quick_fastchecks"
DECOMP_RUN_ID="${RUN_TAG}_decomp"
NAT_RUN_ID="${RUN_TAG}_natural"

OUTPUT_ROOT="results/experiment2/quick/${RUN_TAG}"
CHECKS_ROOT="${OUTPUT_ROOT}/checks"
MANIFEST_DIR="${OUTPUT_ROOT}/manifests"
LOG_ROOT="logs/experiment2/quick/${RUN_TAG}"
mkdir -p "${CHECKS_ROOT}" "${MANIFEST_DIR}" "${LOG_ROOT}"

MANIFEST_PATH="${MANIFEST_DIR}/${DECOMP_RUN_ID}.jsonl"
MANIFEST_SUMMARY="${MANIFEST_DIR}/${DECOMP_RUN_ID}.summary.json"

echo "[fastchecks] run_tag=${RUN_TAG}" | tee -a "${LOG_ROOT}/execute.log"

.venv/bin/python scripts/experiment2_fastcheck_build_manifest.py \
  --output-manifest "${MANIFEST_PATH}" \
  --summary-json "${MANIFEST_SUMMARY}" \
  --run-id "${DECOMP_RUN_ID}" \
  --phase "${PHASE}" \
  --model "${MODEL}" \
  --seq-len 1024 \
  --seeds 0,1,2 \
  --tasks local_copy_offset,delayed_copy,local_key_match,long_range_retrieval \
  --short-span 4 \
  --long-span 32 \
  --device cuda \
  --notes-tag fastcheck_decomp | tee -a "${LOG_ROOT}/execute.log"

declare -A POLICY_NAME
POLICY_NAME[structured_first]="restricted_candidates_v1_structured_first"
POLICY_NAME[structured_only]="restricted_candidates_v1_structured_only"
POLICY_NAME[random_only]="restricted_candidates_v1_random_only"

for key in structured_first structured_only random_only; do
  out_root="${CHECKS_ROOT}/decomp_${key}"
  mkdir -p "${out_root}"
  echo "[fastchecks] execute policy=${key}" | tee -a "${LOG_ROOT}/execute.log"
  CUDA_VISIBLE_DEVICES=2 .venv/bin/python experiment2/run.py \
    --mode execute \
    --manifest "${MANIFEST_PATH}" \
    --output-root "${out_root}" \
    --device cuda:0 \
    --kernel-engine optimized \
    --centered-compute defer \
    --synthetic-eval-mode restricted \
    --candidate-size 10 \
    --candidate-policy-version "${POLICY_NAME[$key]}" \
    --h12-endpoint-policy co_primary_raw_headroom \
    --track-a-enabled false \
    --intervention-profile strong_only \
    --synthetic-count 100 \
    --batch-size-synth 12 \
    --feasibility-task-only \
    --emit-target-level-records \
    --print-summary | tee -a "${LOG_ROOT}/execute.log"
done

echo "[fastchecks] running semi-natural bridge probe on GPU2" | tee -a "${LOG_ROOT}/execute.log"
CUDA_VISIBLE_DEVICES=2 .venv/bin/python scripts/experiment2_quick_seminatural_probe.py \
  --run-tag "${NAT_RUN_ID}_part0" \
  --output-root "${CHECKS_ROOT}/natural_shards" \
  --logs-root "${LOG_ROOT}" \
  --model "${MODEL}" \
  --dataset wiki40b_en_pre2019 \
  --seq-len 1024 \
  --spans 32,48,64 \
  --seeds 0,1,2 \
  --seed-start 0 \
  --seed-end 2 \
  --interventions none,ablate_high_strong,ablate_low_strong,random_strong \
  --random-draws 3 \
  --synthetic-count 100 \
  --candidate-size 10 \
  --batch-size 1 \
  --device cuda:0 \
  --data-root data | tee -a "${LOG_ROOT}/execute.log"

.venv/bin/python scripts/experiment2_quick_natural_merge.py \
  --inputs "${CHECKS_ROOT}/natural_shards/${NAT_RUN_ID}_part0" \
  --output-dir "${CHECKS_ROOT}/natural" | tee -a "${LOG_ROOT}/execute.log"

cat > "${CHECKS_ROOT}/run_context.json" <<JSON
{
  "run_tag": "${RUN_TAG}",
  "model": "${MODEL}",
  "phase": "${PHASE}",
  "manifest_path": "${MANIFEST_PATH}",
  "decomp_run_id": "${DECOMP_RUN_ID}",
  "natural_run_id": "${NAT_RUN_ID}",
  "aggregates": {
    "structured_first": "${CHECKS_ROOT}/decomp_structured_first/${PHASE}/${DECOMP_RUN_ID}/aggregate_task_metrics.parquet",
    "structured_only": "${CHECKS_ROOT}/decomp_structured_only/${PHASE}/${DECOMP_RUN_ID}/aggregate_task_metrics.parquet",
    "random_only": "${CHECKS_ROOT}/decomp_random_only/${PHASE}/${DECOMP_RUN_ID}/aggregate_task_metrics.parquet"
  },
  "natural_summary": "${CHECKS_ROOT}/natural/summary.json"
}
JSON

echo "[fastchecks] execute stage complete run_tag=${RUN_TAG}" | tee -a "${LOG_ROOT}/execute.log"
