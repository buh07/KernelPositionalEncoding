#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment1.config import DATASETS, get_models_for_profile
from shared.data.tokenization import TokenizationRequest, tokenize_and_save
from shared.specs import SequenceLengthSpec


def _count_usable_sequences(model_name: str, min_len: int) -> int:
    model_dir = ROOT / "data" / "experiment1" / "wiki40b_en_pre2019" / model_name
    if not model_dir.exists():
        return 0
    count = 0
    for jsonl_path in sorted(model_dir.rglob("*.jsonl")):
        with jsonl_path.open("r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                tokens = row.get("tokens", row.get("input_ids", []))
                if isinstance(tokens, list) and len(tokens) >= min_len:
                    count += 1
    return count


def _resolve_model(name: str):
    profiles = ("scaleup_78b_mistral", "scaleup_78b", "legacy_1b")
    by_name = {}
    for profile in profiles:
        for spec in get_models_for_profile(profile):
            by_name[spec.name] = spec
    if name not in by_name:
        raise ValueError(f"Unknown model name: {name}")
    return by_name[name]


def _resolve_dataset(name: str):
    for ds in DATASETS:
        if ds.name == name:
            return ds
    raise ValueError(f"Unknown dataset: {name}")


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def main() -> None:
    p = argparse.ArgumentParser(description="Stage4 preflight: ensure enough wiki sequences for 3P2-A.2")
    p.add_argument("--model", required=True)
    p.add_argument("--dataset", default="wiki40b_en_pre2019")
    p.add_argument("--probe-seq-len", type=int, default=512)
    p.add_argument("--probe-train-sequences", type=int, default=500)
    p.add_argument("--probe-eval-sequences", type=int, default=100)
    p.add_argument("--extra-eval-buffer", type=int, default=16)
    p.add_argument("--safety-margin", type=int, default=64)
    p.add_argument("--min-generate", type=int, default=500)
    p.add_argument("--tokenized-seq-len", type=int, default=1024)
    p.add_argument("--seed", type=int, default=20260408)
    args = p.parse_args()

    required = int(args.probe_train_sequences + args.probe_eval_sequences + args.extra_eval_buffer)
    needed_target = required + int(args.safety_margin)
    before = _count_usable_sequences(args.model, int(args.probe_seq_len))

    generated_path = None
    generated_manifest = None

    if before < needed_target:
        model_spec = _resolve_model(args.model)
        dataset_spec = _resolve_dataset(args.dataset)
        add_total = max(int(args.min_generate), int(needed_target - before))
        center_count = add_total // 2
        eval_count = add_total - center_count
        if not dataset_spec.needs_center_split:
            center_count = 0
            eval_count = add_total

        out_dir = ROOT / "data" / "experiment1" / args.dataset / args.model
        out_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_path = out_dir / f"len_{int(args.tokenized_seq_len)}_stage4a2_supp_{ts}.jsonl"

        req = TokenizationRequest(
            model=model_spec,
            dataset=dataset_spec,
            seq_len=SequenceLengthSpec(tokens=int(args.tokenized_seq_len)),
            center_count=center_count,
            eval_count=eval_count,
            data_root=ROOT / "data",
            seed=int(args.seed),
        )
        generated_manifest = tokenize_and_save(req, out_path)
        generated_path = str(out_path)

    after = _count_usable_sequences(args.model, int(args.probe_seq_len))
    if after < required:
        raise RuntimeError(
            f"A.2 preflight still below hard minimum for {args.model}: have {after}, need {required}"
        )

    summary = {
        "model": args.model,
        "dataset": args.dataset,
        "probe_seq_len": int(args.probe_seq_len),
        "probe_train_sequences": int(args.probe_train_sequences),
        "probe_eval_sequences": int(args.probe_eval_sequences),
        "extra_eval_buffer": int(args.extra_eval_buffer),
        "required_min_sequences": required,
        "required_with_margin": needed_target,
        "usable_sequences_before": before,
        "usable_sequences_after": after,
        "generated_path": generated_path,
        "generated_manifest": generated_manifest,
        "status": "ok",
    }

    report = (
        ROOT
        / "results"
        / "experiment3_phase2"
        / "phase2_governance"
        / "stage4_data_prep"
        / f"{args.model}_a2_preflight.json"
    )
    _write_json(report, summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
