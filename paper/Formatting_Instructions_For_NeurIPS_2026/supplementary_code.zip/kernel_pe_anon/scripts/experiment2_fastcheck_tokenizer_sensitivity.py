#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import sys
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment2.config import MODEL_BY_NAME
from shared.models.loading import load_tokenizer


def _load_sample_token_frequencies(*, model: str, dataset: str, seq_len: int, sample_sequences: int) -> Counter[int]:
    path = Path("data") / "experiment1" / str(dataset) / str(model) / f"len_{int(seq_len)}.jsonl"
    if not path.exists():
        raise FileNotFoundError(f"Tokenized dataset file not found for frequency sampling: {path}")
    counter: Counter[int] = Counter()
    with path.open("r", encoding="utf-8") as handle:
        for idx, line in enumerate(handle):
            if idx >= int(sample_sequences):
                break
            text = line.strip()
            if not text:
                continue
            rec = json.loads(text)
            toks = rec.get("tokens", [])
            for tok in toks:
                counter[int(tok)] += 1
    return counter


def _freq_quantile_bins(values: pd.Series, quantiles: int) -> pd.Series:
    if values.empty:
        return pd.Series(dtype="string")
    transformed = np.log1p(values.astype(float))
    unique = transformed.nunique(dropna=True)
    q = min(max(2, int(quantiles)), int(unique))
    if q < 2:
        return pd.Series(["q1"] * len(values), index=values.index, dtype="string")
    try:
        bins = pd.qcut(transformed, q=q, labels=[f"q{i+1}" for i in range(q)], duplicates="drop")
        return bins.astype("string")
    except ValueError:
        return pd.Series(["q1"] * len(values), index=values.index, dtype="string")


def main() -> None:
    ap = argparse.ArgumentParser(description="Tokenizer-sensitivity audit from per-target metrics.")
    ap.add_argument("--run-root", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--model", type=str, default="llama-3.1-8b")
    ap.add_argument("--dataset", type=str, default="wiki40b_en_pre2019")
    ap.add_argument("--seq-len", type=int, default=1024)
    ap.add_argument("--sample-sequences", type=int, default=1000)
    ap.add_argument("--freq-quantiles", type=int, default=4)
    ap.add_argument("--exclude-special", action="store_true", default=True)
    args = ap.parse_args()

    if args.model not in MODEL_BY_NAME:
        raise SystemExit(f"Unknown model: {args.model}")
    tokenizer = load_tokenizer(MODEL_BY_NAME[args.model])
    special_ids = set(int(x) for x in getattr(tokenizer, "all_special_ids", []) if x is not None)

    files = sorted(args.run_root.rglob("target_level_metrics.parquet"))
    if not files:
        raise RuntimeError(f"No target_level_metrics.parquet files found under {args.run_root}")

    rows = [pd.read_parquet(path) for path in files]
    df = pd.concat(rows, ignore_index=True)
    need_cols = {"target_id", "pred_id", "correct", "task", "span", "seed", "intervention", "model"}
    missing = sorted(need_cols - set(df.columns))
    if missing:
        raise RuntimeError(f"Missing required target-level columns: {missing}")

    df = df[
        (df["model"] == args.model)
        & (df["intervention"] == "none")
        & (df["split"] == "synthetic")
    ].copy()
    if bool(args.exclude_special):
        df = df[~df["target_id"].astype(int).isin(special_ids)].copy()
    if df.empty:
        raise RuntimeError("No usable target-level rows after filtering baseline synthetic non-special records.")

    freq = _load_sample_token_frequencies(
        model=str(args.model),
        dataset=str(args.dataset),
        seq_len=int(args.seq_len),
        sample_sequences=int(args.sample_sequences),
    )

    uniq_ids = sorted(set(int(x) for x in df["target_id"].tolist()))
    token_meta: list[dict[str, Any]] = []
    for tok_id in uniq_ids:
        piece = tokenizer.convert_ids_to_tokens(int(tok_id))
        decoded = tokenizer.decode([int(tok_id)], skip_special_tokens=False, clean_up_tokenization_spaces=False)
        token_meta.append(
            {
                "target_id": int(tok_id),
                "token_piece_len": int(len(piece) if piece is not None else 0),
                "token_char_len": int(len(decoded)),
                "freq_count": int(freq.get(int(tok_id), 0)),
            }
        )
    meta_df = pd.DataFrame(token_meta)
    df = df.merge(meta_df, on="target_id", how="left")

    df["freq_bin"] = _freq_quantile_bins(df["freq_count"], quantiles=int(args.freq_quantiles))
    df["token_piece_bin"] = pd.cut(
        df["token_piece_len"].astype(float),
        bins=[-math.inf, 2, 4, 8, math.inf],
        labels=["<=2", "3-4", "5-8", "9+"],
    ).astype("string")
    df["token_char_bin"] = pd.cut(
        df["token_char_len"].astype(float),
        bins=[-math.inf, 1, 3, 6, math.inf],
        labels=["<=1", "2-3", "4-6", "7+"],
    ).astype("string")

    def _agg(block: pd.DataFrame, col: str) -> pd.DataFrame:
        return (
            block.groupby(["task", "span", col], as_index=False)
            .agg(
                n=("correct", "count"),
                accuracy=("correct", "mean"),
                unique_tokens=("target_id", "nunique"),
            )
            .rename(columns={col: "bin"})
            .assign(bin_type=col)
        )

    out = pd.concat(
        [
            _agg(df, "freq_bin"),
            _agg(df, "token_piece_bin"),
            _agg(df, "token_char_bin"),
        ],
        ignore_index=True,
    )
    out = out.sort_values(["bin_type", "task", "span", "bin"]).reset_index(drop=True)

    summary = {
        "generated_at": pd.Timestamp.utcnow().isoformat(),
        "run_root": str(args.run_root),
        "model": str(args.model),
        "dataset": str(args.dataset),
        "seq_len": int(args.seq_len),
        "source_files": [str(p) for p in files],
        "rows_total": int(len(df)),
        "unique_target_tokens": int(df["target_id"].nunique()),
        "special_tokens_excluded": bool(args.exclude_special),
        "freq_quantiles": int(args.freq_quantiles),
        "notes": [
            "Baseline-only (intervention=none) exploratory tokenizer-sensitivity summary.",
            "Frequency bins are approximate and derived from sampled tokenized wiki sequences.",
        ],
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    df.to_parquet(args.output_dir / "tokenizer_sensitivity_targets.parquet", engine="pyarrow", index=False)
    out.to_parquet(args.output_dir / "tokenizer_sensitivity.parquet", engine="pyarrow", index=False)
    (args.output_dir / "tokenizer_sensitivity.json").write_text(
        json.dumps({"summary": summary, "rows": out.to_dict(orient="records")}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
