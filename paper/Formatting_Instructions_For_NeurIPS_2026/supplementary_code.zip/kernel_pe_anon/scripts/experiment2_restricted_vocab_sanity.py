#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.append(str(ROOT_DIR))

from experiment2.config import MODEL_BY_NAME
from experiment2.execution import _build_restricted_candidates
from experiment2.tasks import build_token_pools, generate_task_examples
from shared.models.loading import load_tokenizer


def main() -> None:
    ap = argparse.ArgumentParser(description="Sanity-check restricted candidate construction for a model/tokenizer.")
    ap.add_argument("--model", type=str, required=True)
    ap.add_argument("--seq-len", type=int, default=1024)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--count", type=int, default=2)
    ap.add_argument("--candidate-size", type=int, default=10)
    ap.add_argument("--candidate-policy-version", type=str, default="restricted_candidates_v1_structured_first")
    args = ap.parse_args()

    if args.model not in MODEL_BY_NAME:
        raise SystemExit(f"Unknown model: {args.model}")
    spec = MODEL_BY_NAME[args.model]
    tokenizer = load_tokenizer(spec)
    vocab_size = int(tokenizer.vocab_size)
    pools = build_token_pools(
        model_name=spec.name,
        vocab_size=vocab_size,
        special_ids=getattr(tokenizer, "all_special_ids", []),
    )

    checks: list[dict[str, object]] = []
    task_settings = (
        ("local_key_match", None),
        ("long_range_retrieval", 24),
    )
    for task_name, span_override in task_settings:
        examples = generate_task_examples(
            task_name=task_name,
            model_name=spec.name,
            seq_len=int(args.seq_len),
            seed=int(args.seed),
            count=int(args.count),
            pools=pools,
            span_override=span_override,
        )
        for ex in examples:
            for pos, target in zip(ex.target_positions[: min(4, len(ex.target_positions))], ex.target_tokens[: min(4, len(ex.target_tokens))]):
                candidates = _build_restricted_candidates(
                    example=ex,
                    target=int(target),
                    position=int(pos),
                    pools=pools,
                    candidate_size=int(args.candidate_size),
                    candidate_policy_version=str(args.candidate_policy_version),
                )
                uniq = len(set(candidates)) == len(candidates)
                in_vocab = all(0 <= int(tok) < vocab_size for tok in candidates)
                has_target = int(target) in set(candidates)
                checks.append(
                    {
                        "task": task_name,
                        "example_id": ex.id,
                        "position": int(pos),
                        "candidate_count": int(len(candidates)),
                        "unique": bool(uniq),
                        "in_vocab": bool(in_vocab),
                        "has_target": bool(has_target),
                    }
                )

    all_ok = all(
        rec["candidate_count"] == int(args.candidate_size)
        and rec["unique"]
        and rec["in_vocab"]
        and rec["has_target"]
        for rec in checks
    )
    payload = {
        "status": "ok" if all_ok else "failed",
        "model": spec.name,
        "vocab_size": vocab_size,
        "candidate_size": int(args.candidate_size),
        "checks": checks,
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    if not all_ok:
        raise SystemExit("Restricted-candidate sanity check failed.")


if __name__ == "__main__":
    main()
