#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

RUN_TAG="${1:-quick_pair_gemma_norm_$(date +%Y%m%d_%H%M%S)}"
GPU_LIST="${GPU_LIST:-0 1}"
PAIR_INDICES="${PAIR_INDICES:-0,12,24,36,48,60,72,84}"
SEEDS="${SEEDS:-0,1,2}"

OUTPUT_ROOT="results/experiment2/quick/${RUN_TAG}"
LOG_ROOT="logs/experiment2/quick/${RUN_TAG}"
MANIFEST_DIR="${OUTPUT_ROOT}/manifests"
REPORT_DIR="${OUTPUT_ROOT}/reports/pair_expanded"
UNIFIED_DIR="${OUTPUT_ROOT}/reports/pair_unified_gemma_norm"

BASE_RUN_ID="${RUN_TAG}_base"
PAIR_RUN_ID="${RUN_TAG}_pair"
BASE_MANIFEST="${OUTPUT_ROOT}/phase2b/${BASE_RUN_ID}/manifest.jsonl"
PAIR_MANIFEST="${MANIFEST_DIR}/${PAIR_RUN_ID}.jsonl"
FAMILIES_JSON="${MANIFEST_DIR}/${PAIR_RUN_ID}.families.json"

LLAMA_STD_REPORT="results/experiment2/quick/quick_hstress_stage2_20260313_223708/reports/pair_expanded_standardized"
LEGACY_EXPANDED_REPORT="results/experiment2/quick/quick_pair_expand_pivot_20260314_0043_v2/reports/pair_expanded"
COMPARE_MEMO="${OUTPUT_ROOT}/reports/gemma_legacy_vs_norm_comparison.md"

mkdir -p "${LOG_ROOT}" "${MANIFEST_DIR}" "${REPORT_DIR}" "${UNIFIED_DIR}"

read -r -a GPUS <<< "${GPU_LIST//,/ }"
if (( ${#GPUS[@]} != 2 )); then
  echo "This launcher expects exactly 2 GPUs (received: ${GPU_LIST})." >&2
  exit 1
fi
G0="${GPUS[0]}"
G1="${GPUS[1]}"

for req in "${LLAMA_STD_REPORT}/pair_effects.parquet" "${LEGACY_EXPANDED_REPORT}/pair_effects.parquet"; do
  if [[ ! -f "${req}" ]]; then
    echo "Missing required report artifact: ${req}" >&2
    exit 1
  fi
done

cat > "${FAMILIES_JSON}" <<'JSON'
[
  {"model": "gemma-7b", "task": "long_range_retrieval", "spans": [16, 24]},
  {"model": "gemma-7b", "task": "local_key_match"}
]
JSON

.venv/bin/python experiment2/run.py \
  --mode build \
  --phase phase2b \
  --run-id "${BASE_RUN_ID}" \
  --device cuda \
  --output-root "${OUTPUT_ROOT}" \
  --model-profile scaleup_78b \
  --model-allowlist gemma-7b \
  --phase2b-core-synthetic-only \
  --intervention-profile strong_only \
  --random-draws-confirmatory 3 \
  --print-summary | tee "${LOG_ROOT}/build.log"

.venv/bin/python scripts/experiment2_pair_sweep_manifest.py \
  --input-manifest "${BASE_MANIFEST}" \
  --output-manifest "${PAIR_MANIFEST}" \
  --summary-json "${MANIFEST_DIR}/${PAIR_RUN_ID}.summary.json" \
  --run-id "${PAIR_RUN_ID}" \
  --phase quick_pair_gemma_norm \
  --seeds "${SEEDS}" \
  --pair-indices "${PAIR_INDICES}" \
  --random-draws 3 \
  --families-json "${FAMILIES_JSON}" \
  --notes-tag quick_pair_gemma_percentile_norm | tee "${LOG_ROOT}/manifest.log"

.venv/bin/python - <<PY
import json
from pathlib import Path
summary = json.loads(Path("${MANIFEST_DIR}/${PAIR_RUN_ID}.summary.json").read_text())
rows = int(summary.get("row_count", -1))
if rows != 108:
    raise SystemExit(f"Expected 108 rows, got {rows}")
print(json.dumps({"manifest_row_count": rows, "expected": 108}, indent=2))
PY

for sess in "exp2_gnorm_g${G0}" "exp2_gnorm_g${G1}" exp2_gnorm_report exp2_gnorm_merge; do
  tmux kill-session -t "${sess}" 2>/dev/null || true
done

tmux new-session -d -s "exp2_gnorm_g${G0}" \
  "cd '${ROOT_DIR}' && CUDA_VISIBLE_DEVICES=${G0} .venv/bin/python experiment2/run.py --mode execute --manifest '${PAIR_MANIFEST}' --output-root '${OUTPUT_ROOT}' --device cuda:0 --kernel-engine optimized --centered-compute defer --synthetic-eval-mode restricted --candidate-size 10 --h12-endpoint-policy co_primary_raw_headroom --track-a-enabled false --intervention-profile full --synthetic-count 100 --batch-size-synth 12 --seed-start 0 --seed-end 1 --print-summary |& tee '${LOG_ROOT}/exp2_gnorm_g${G0}.log'"

tmux new-session -d -s "exp2_gnorm_g${G1}" \
  "cd '${ROOT_DIR}' && CUDA_VISIBLE_DEVICES=${G1} .venv/bin/python experiment2/run.py --mode execute --manifest '${PAIR_MANIFEST}' --output-root '${OUTPUT_ROOT}' --device cuda:0 --kernel-engine optimized --centered-compute defer --synthetic-eval-mode restricted --candidate-size 10 --h12-endpoint-policy co_primary_raw_headroom --track-a-enabled false --intervention-profile full --synthetic-count 100 --batch-size-synth 12 --seed-start 2 --seed-end 2 --print-summary |& tee '${LOG_ROOT}/exp2_gnorm_g${G1}.log'"

tmux new-session -d -s exp2_gnorm_report \
  "cd '${ROOT_DIR}' && while tmux has-session -t exp2_gnorm_g${G0} 2>/dev/null || tmux has-session -t exp2_gnorm_g${G1} 2>/dev/null; do sleep 30; done && \
   .venv/bin/python scripts/experiment2_pair_sweep_report.py --aggregate-task-metrics '${OUTPUT_ROOT}/quick_pair_gemma_norm/${PAIR_RUN_ID}/aggregate_task_metrics.parquet' --output-dir '${REPORT_DIR}' --families-json '${FAMILIES_JSON}' --pair-indices '${PAIR_INDICES}' --floor-threshold 0.15 |& tee '${LOG_ROOT}/exp2_gnorm_report.log'"

tmux new-session -d -s exp2_gnorm_merge \
  "cd '${ROOT_DIR}' && while [ ! -f '${REPORT_DIR}/summary.json' ]; do sleep 30; done && \
   .venv/bin/python scripts/experiment2_pair_sweep_merge.py --inputs '${LLAMA_STD_REPORT},${LEGACY_EXPANDED_REPORT},${REPORT_DIR}' --source-runs 'quick_hstress_stage2_20260313_223708,quick_pair_expand_pivot_20260314_0043_v2,${RUN_TAG}' --output-dir '${UNIFIED_DIR}' |& tee '${LOG_ROOT}/exp2_gnorm_merge.log' && \
   .venv/bin/python scripts/experiment2_pair_gemma_compare.py --legacy-report-dir '${LEGACY_EXPANDED_REPORT}' --normalized-report-dir '${REPORT_DIR}' --output-md '${COMPARE_MEMO}' |& tee '${LOG_ROOT}/exp2_gnorm_compare.log'"

cat <<EOF
[gemma-norm] launched on GPUs ${G0}/${G1}
  tmux sessions:
    - exp2_gnorm_g${G0}
    - exp2_gnorm_g${G1}
    - exp2_gnorm_report
    - exp2_gnorm_merge
  run tag: ${RUN_TAG}
  manifest: ${PAIR_MANIFEST}
  report dir: ${REPORT_DIR}
  unified dir: ${UNIFIED_DIR}
EOF
