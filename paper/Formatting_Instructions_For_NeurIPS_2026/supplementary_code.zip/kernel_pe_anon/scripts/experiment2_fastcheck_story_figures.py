#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def _theme() -> None:
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update(
        {
            "figure.dpi": 140,
            "savefig.dpi": 220,
            "font.size": 11,
            "axes.titlesize": 13,
            "axes.labelsize": 11,
            "legend.fontsize": 10,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def fig_difficulty(summary_parquet: Path, out: Path) -> None:
    df = pd.read_parquet(summary_parquet).copy()
    df = df.sort_values(["task", "span"])
    x_labels = [f"{r.task}\nspan={int(r.span)}" for r in df.itertuples(index=False)]
    x = range(len(df))

    fig, ax = plt.subplots(figsize=(9.4, 4.6))
    ax.plot(x, df["structured_first"], marker="o", linewidth=2.0, label="structured_first")
    ax.plot(x, df["structured_only"], marker="o", linewidth=1.8, linestyle="--", label="structured_only")
    ax.plot(x, df["random_only"], marker="o", linewidth=2.0, label="random_only")
    ax.set_xticks(list(x))
    ax.set_xticklabels(x_labels, rotation=22, ha="right")
    ax.set_ylabel("Baseline accuracy (none)")
    ax.set_title("Difficulty decomposition by candidate policy")
    ax.legend(loc="best")
    ax.text(
        0.01,
        0.02,
        "structured_only == structured_first across all tasks",
        transform=ax.transAxes,
        fontsize=9,
        color="#444",
    )
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def fig_headroom(headroom_parquet: Path, out: Path) -> None:
    df = pd.read_parquet(headroom_parquet).copy()
    df = df.sort_values(["task_class", "task", "span"])
    labels = [f"{r.task}\nspan={int(r.span)}" for r in df.itertuples(index=False)]
    x = range(len(df))

    fig, ax = plt.subplots(figsize=(9.4, 4.6))
    ax.bar(x, df["baseline_headroom_mean"], color=["#2ca02c" if t == "short" else "#d62728" for t in df["task_class"]])
    ax.set_xticks(list(x))
    ax.set_xticklabels(labels, rotation=22, ha="right")
    ax.set_ylabel("Baseline headroom (none - chance)")
    ax.set_title("Headroom audit by task family")
    ax.axhline(0.0, color="#666", linewidth=1.0, linestyle="--")
    for xi, v in zip(x, df["baseline_headroom_mean"], strict=True):
        ax.text(xi, float(v) + 0.005, f"{float(v):.3f}", ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def fig_natural_bridge(summary_json: Path, out: Path) -> None:
    payload = json.loads(summary_json.read_text(encoding="utf-8"))
    rows = pd.DataFrame(payload["summary_rows"])
    rows = rows.sort_values(["intervention", "span"])
    interventions = ["none", "ablate_high_strong", "ablate_low_strong", "random_strong"]
    colors = {
        "none": "#1f77b4",
        "ablate_high_strong": "#d62728",
        "ablate_low_strong": "#2ca02c",
        "random_strong": "#9467bd",
    }

    fig, ax = plt.subplots(figsize=(8.6, 4.6))
    for name in interventions:
        sub = rows[rows["intervention"] == name]
        if sub.empty:
            continue
        ax.plot(
            sub["span"].astype(int).tolist(),
            sub["mean_accuracy_restricted"].astype(float).tolist(),
            marker="o",
            linewidth=2.0,
            color=colors.get(name, None),
            label=name,
        )
    ax.set_xlabel("Span")
    ax.set_ylabel("Restricted accuracy")
    ax.set_title("Semi-natural bridge: restricted accuracy by span")
    ax.set_ylim(0.70, 1.01)
    ax.legend(loc="lower left")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def fig_tokenizer(tokenizer_parquet: Path, out: Path) -> None:
    df = pd.read_parquet(tokenizer_parquet).copy()
    sub = df[df["bin_type"] == "token_piece_bin"].copy()
    order = ["<=2", "3-4", "5-8", "9+"]
    sub["bin"] = pd.Categorical(sub["bin"], categories=order, ordered=True)
    agg = sub.groupby("bin", as_index=False).agg(accuracy=("accuracy", "mean"), n=("n", "sum")).sort_values("bin")

    fig, ax1 = plt.subplots(figsize=(8.2, 4.6))
    ax1.bar(agg["bin"].astype(str), agg["accuracy"], color="#1f77b4", alpha=0.85)
    ax1.set_ylabel("Accuracy")
    ax1.set_ylim(0.0, max(0.5, float(agg["accuracy"].max()) + 0.08))
    ax1.set_xlabel("Token piece-length bin")
    ax1.set_title("Tokenizer sensitivity (baseline only)")
    for x, v in zip(range(len(agg)), agg["accuracy"], strict=True):
        ax1.text(x, float(v) + 0.01, f"{float(v):.3f}", ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser(description="Generate fast-check figure pack for Experiment 2 narrative.")
    ap.add_argument("--run-tag", required=True)
    ap.add_argument("--quick-root", default="results/experiment2/quick")
    ap.add_argument("--output-dir", default="experiment2/figures")
    args = ap.parse_args()

    root = Path(args.quick_root) / args.run_tag / "checks" / "reports"
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    _theme()
    fig_difficulty(root / "difficulty_decomp_summary.parquet", out_dir / "fig8_fastcheck_difficulty_decomp.png")
    fig_headroom(root / "headroom_audit_by_span.parquet", out_dir / "fig9_fastcheck_headroom_audit.png")
    fig_natural_bridge(root / "natural_bridge_summary.json", out_dir / "fig10_fastcheck_natural_bridge.png")
    fig_tokenizer(root / "tokenizer_sensitivity.parquet", out_dir / "fig11_fastcheck_tokenizer_sensitivity.png")
    print(
        json.dumps(
            {
                "status": "ok",
                "output_dir": str(out_dir),
                "figures": [
                    "fig8_fastcheck_difficulty_decomp.png",
                    "fig9_fastcheck_headroom_audit.png",
                    "fig10_fastcheck_natural_bridge.png",
                    "fig11_fastcheck_tokenizer_sensitivity.png",
                ],
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
