#!/usr/bin/env bash
set -euo pipefail

ROOT="/path/to/kernel-pe"
cd "$ROOT"

for s in exp3p2_stage3_llama exp3p2_stage3_olmo; do
  tmux kill-session -t "$s" 2>/dev/null || true
done

tmux new-session -d -s exp3p2_stage3_llama "cd '$ROOT' && bash scripts/experiment3_phase2_stage3_gpu0.sh"
tmux new-session -d -s exp3p2_stage3_olmo "cd '$ROOT' && bash scripts/experiment3_phase2_stage3_gpu1.sh"

echo "Launched stage3 tmux sessions: exp3p2_stage3_llama, exp3p2_stage3_olmo"
echo "Monitor with:"
echo "  tmux ls"
echo "  bash scripts/experiment3_phase2_stage3_status.sh"
