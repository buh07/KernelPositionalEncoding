#!/usr/bin/env bash
set -euo pipefail

ROOT="/scratch2/anon/Kernel PE"
cd "$ROOT"

LOG_DIR="logs/trackb"
mkdir -p "$LOG_DIR"
MONITOR_LOG="$LOG_DIR/trackb_sharedmean_watchdog.log"
ALERT_FILE="$LOG_DIR/trackb_sharedmean_watchdog.alert"

TARGET_SUMMARIES=36
PATTERN="experiment1/run.py track-b --device cuda --track-b-centering-mode shared_mean --track-b-output-group track_b_shared_mean_v1"
LOG_FILES=(
  "$LOG_DIR/trackb_sharedmean_resume_gpu0.log"
  "$LOG_DIR/trackb_sharedmean_resume_gpu1.log"
)

echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] watchdog start" | tee -a "$MONITOR_LOG"

while true; do
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

  summaries="$(find results/track_b_shared_mean_v1 -name summary.parquet | wc -l | tr -d ' ')"

  active_lines="$(pgrep -af "$PATTERN" || true)"
  if [[ -n "$active_lines" ]]; then
    active_count="$(printf '%s\n' "$active_lines" | rg -c "$PATTERN" || true)"
  else
    active_count=0
  fi

  error_lines="$(rg -n "ERROR|Traceback|RuntimeError|Exception|Killed|OOM|out of memory" "${LOG_FILES[@]}" || true)"

  echo "[$ts] active=$active_count summaries=$summaries/$TARGET_SUMMARIES" | tee -a "$MONITOR_LOG"

  if [[ -n "$error_lines" ]]; then
    {
      echo "[$ts] ALERT: error signature detected"
      echo "$error_lines"
    } | tee -a "$MONITOR_LOG" > "$ALERT_FILE"
    exit 1
  fi

  if (( summaries >= TARGET_SUMMARIES )) && (( active_count == 0 )); then
    echo "[$ts] COMPLETE: shared-mean Track B reached $summaries/$TARGET_SUMMARIES with no active workers" | tee -a "$MONITOR_LOG"
    exit 0
  fi

  if (( active_count == 0 )) && (( summaries < TARGET_SUMMARIES )); then
    echo "[$ts] WARNING: workers stopped early at $summaries/$TARGET_SUMMARIES" | tee -a "$MONITOR_LOG"
    exit 2
  fi

  sleep 60
done
