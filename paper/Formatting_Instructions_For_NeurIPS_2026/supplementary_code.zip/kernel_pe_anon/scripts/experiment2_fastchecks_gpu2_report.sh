#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

RUN_TAG="${1:?usage: $0 <run_tag>}"
PHASE="quick_fastchecks"
DECOMP_RUN_ID="${RUN_TAG}_decomp"

OUTPUT_ROOT="results/experiment2/quick/${RUN_TAG}"
CHECKS_ROOT="${OUTPUT_ROOT}/checks"
LOG_ROOT="logs/experiment2/quick/${RUN_TAG}"
REPORT_DIR="${CHECKS_ROOT}/reports"
mkdir -p "${REPORT_DIR}" "${LOG_ROOT}"

AGG_STRUCT="${CHECKS_ROOT}/decomp_structured_first/${PHASE}/${DECOMP_RUN_ID}/aggregate_task_metrics.parquet"
AGG_STRUCT_ONLY="${CHECKS_ROOT}/decomp_structured_only/${PHASE}/${DECOMP_RUN_ID}/aggregate_task_metrics.parquet"
AGG_RANDOM="${CHECKS_ROOT}/decomp_random_only/${PHASE}/${DECOMP_RUN_ID}/aggregate_task_metrics.parquet"
NAT_SUMMARY="${CHECKS_ROOT}/natural/summary.json"

echo "[fastchecks] waiting for execute artifacts run_tag=${RUN_TAG}" | tee -a "${LOG_ROOT}/report.log"
for _ in $(seq 1 360); do
  if [[ -f "${AGG_STRUCT}" && -f "${AGG_STRUCT_ONLY}" && -f "${AGG_RANDOM}" && -f "${NAT_SUMMARY}" ]]; then
    break
  fi
  sleep 30
done

if [[ ! -f "${AGG_STRUCT}" || ! -f "${AGG_STRUCT_ONLY}" || ! -f "${AGG_RANDOM}" ]]; then
  echo "[fastchecks] missing aggregate artifacts after wait window" | tee -a "${LOG_ROOT}/report.log"
  exit 1
fi

.venv/bin/python scripts/experiment2_fastcheck_oracle_sanity.py \
  --model llama-3.1-8b \
  --seq-len 1024 \
  --tasks local_copy_offset,delayed_copy,local_key_match,long_range_retrieval \
  --seeds 0,1,2 \
  --count-per-task-seed 16 \
  --candidate-size 10 \
  --candidate-policies restricted_candidates_v1_structured_first,restricted_candidates_v1_structured_only,restricted_candidates_v1_random_only \
  --short-span 4 \
  --long-span 32 \
  --aggregate-task-metrics "${AGG_STRUCT}" \
  --output-json "${REPORT_DIR}/oracle_sanity.json" | tee -a "${LOG_ROOT}/report.log"

.venv/bin/python scripts/experiment2_fastcheck_difficulty_report.py \
  --inputs "structured_first=${AGG_STRUCT},structured_only=${AGG_STRUCT_ONLY},random_only=${AGG_RANDOM}" \
  --output-dir "${REPORT_DIR}" \
  --model llama-3.1-8b | tee -a "${LOG_ROOT}/report.log"

.venv/bin/python scripts/experiment2_fastcheck_headroom_audit.py \
  --aggregate-task-metrics "${AGG_STRUCT}" \
  --output-dir "${REPORT_DIR}" \
  --model llama-3.1-8b \
  --chance-default 0.10 | tee -a "${LOG_ROOT}/report.log"

.venv/bin/python scripts/experiment2_fastcheck_tokenizer_sensitivity.py \
  --run-root "${CHECKS_ROOT}/decomp_structured_first/${PHASE}/${DECOMP_RUN_ID}" \
  --output-dir "${REPORT_DIR}" \
  --model llama-3.1-8b \
  --dataset wiki40b_en_pre2019 \
  --seq-len 1024 \
  --sample-sequences 1000 \
  --freq-quantiles 4 | tee -a "${LOG_ROOT}/report.log"

cp "${NAT_SUMMARY}" "${REPORT_DIR}/natural_bridge_summary.json"

echo "[fastchecks] reporting complete run_tag=${RUN_TAG}" | tee -a "${LOG_ROOT}/report.log"
