#!/usr/bin/env python3
"""
Experiment 3.2a: Induction Head Detection + R² Cross-Reference
===============================================================

Tests whether shift-invariant heads are induction heads, sub-word composition
heads, or something else entirely, by computing per-head induction scores
and cross-referencing against shift-invariance R² from Experiment 3.1.

Induction Head Detection
------------------------
Following Olsson et al. (2022), we use the "repeated random sequence" test:
  1. Generate random token sequences of form [A B C ... A B C ...]
  2. Run a forward pass and capture attention patterns
  3. An induction head is one that, on the second occurrence of token X,
     attends strongly to the token immediately AFTER the first occurrence of X
     (the "induction stripe" at offset = period)
  4. The induction score is the average attention mass on the induction stripe

The induction score is computed per-(layer, head) across many random sequences.

Output
------
  - Per-head induction scores and R² values
  - Scatter plot data for induction_score vs R²
  - Classification of heads into quadrants:
    Q1: high-SI, high-induction (shift-invariant induction heads)
    Q2: high-SI, low-induction (sub-word composition candidates!)
    Q3: low-SI, low-induction (content/semantic heads)
    Q4: low-SI, high-induction (non-stationary induction? rare)

Usage
-----
    python scripts/experiment3_induction_r2_crossref.py --model llama-3.1-8b --device cuda:0
    python scripts/experiment3_induction_r2_crossref.py --model olmo-2-7b --device cuda:1
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from experiment1.shift_kernels import RoPEEstimator, KernelFit
from experiment1.norm_utils import normalize_logits_for_norm
from shared.attention.adapters import get_adapter
from shared.specs import ModelSpec

# ── constants ────────────────────────────────────────────────────────────────
NUM_INDUCTION_SEQUENCES = 100       # number of random repeated sequences
INDUCTION_PERIOD = 32               # length of the base pattern before repeat
INDUCTION_SEQ_LEN = 128             # total length = 2*period + padding
NUM_R2_SEQUENCES = 50               # for R² profiling (reuse saved if available)
R2_SEQ_LEN = 512

MODELS: dict[str, ModelSpec] = {
    "llama-3.1-8b": ModelSpec(
        name="llama-3.1-8b",
        hf_id="meta-llama/Meta-Llama-3.1-8B",
        norm="RMSNorm",
        pe_scheme="RoPE",
        notes="Llama 3.1 8B (GQA: 32Q/8KV heads).",
    ),
    "olmo-2-7b": ModelSpec(
        name="olmo-2-7b",
        hf_id="allenai/OLMo-2-1124-7B",
        norm="LayerNorm",
        pe_scheme="RoPE",
        notes="OLMo 2 7B.",
        download_kwargs=(("torch_dtype", "bfloat16"),),
    ),
    "mistral-7b-v0.1": ModelSpec(
        name="mistral-7b-v0.1",
        hf_id="mistralai/Mistral-7B-v0.1",
        norm="RMSNorm",
        pe_scheme="RoPE",
        notes="Mistral 7B v0.1 (GQA).",
    ),
}


# ═══════════════════════════════════════════════════════════════════════════════
# INDUCTION HEAD DETECTION (Olsson et al. 2022)
# ═══════════════════════════════════════════════════════════════════════════════

def generate_repeated_random_sequence(
    vocab_size: int,
    period: int,
    total_len: int,
    seed: int,
    special_ids: set[int],
) -> list[int]:
    """Generate a token sequence [A₁..Aₚ A₁..Aₚ ...] with random tokens.

    The key property: in the second copy of the pattern, an induction head
    at position i (where i > period) should attend to position (i - period + 1),
    because that's the token that followed the same token last time.
    """
    rng = np.random.RandomState(seed)
    # Build a pool excluding special tokens
    pool = [t for t in range(vocab_size) if t not in special_ids]
    # Sample the base pattern
    base = rng.choice(pool, size=period, replace=True).tolist()
    # Repeat to fill total_len
    n_repeats = (total_len // period) + 1
    full = (base * n_repeats)[:total_len]
    return full


def compute_induction_scores(
    model,
    adapter,
    tokenizer,
    model_spec: ModelSpec,
    device: str,
    num_sequences: int,
    period: int,
    total_len: int,
) -> pd.DataFrame:
    """Compute per-(layer, head) induction scores using repeated random sequences.

    Induction score = average attention weight at offset = period in the
    repeated portion of the sequence. Specifically, for position i in the
    second+ copy, we look at attention[i, i - period + 1] — the token that
    followed the previous occurrence of the current token.
    """
    vocab_size = tokenizer.vocab_size
    special_ids = set()
    for attr in ("bos_token_id", "eos_token_id", "pad_token_id", "unk_token_id"):
        sid = getattr(tokenizer, attr, None)
        if sid is not None:
            special_ids.add(sid)

    all_scores: dict[tuple[int, int], list[float]] = {}

    for seq_idx in range(num_sequences):
        tokens = generate_repeated_random_sequence(
            vocab_size=vocab_size,
            period=period,
            total_len=total_len,
            seed=seq_idx * 7 + 42,
            special_ids=special_ids,
        )
        input_ids = torch.tensor([tokens], dtype=torch.long, device=device)

        # Capture attention logits
        capture = adapter.capture(
            model,
            input_ids=input_ids,
            include_logits=True,
            return_token_logits=False,
            capture_attention=True,
            output_device="cpu",
        )

        if capture.logits is None:
            continue

        # capture.logits: [layers, heads, seq, seq]
        # Convert logits to attention weights (softmax over causal mask)
        n_layers, n_heads, seq_len, _ = capture.logits.shape

        # Apply causal mask and softmax
        causal_mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()
        logits_masked = capture.logits.clone()
        logits_masked[:, :, :, :][..., causal_mask] = float('-inf')
        attn_weights = torch.softmax(logits_masked, dim=-1)  # [layers, heads, seq, seq]

        # Compute induction score: for positions in 2nd+ repeat,
        # check attention at offset = period (the "induction stripe")
        for layer_idx in range(n_layers):
            for head_idx in range(n_heads):
                attn = attn_weights[layer_idx, head_idx]  # [seq, seq]

                # For each position i >= period, the induction target is i - period + 1
                # (the token after the previous occurrence of the same token)
                induction_scores_this = []
                for i in range(period, min(seq_len, 2 * period)):
                    target_pos = i - period + 1  # position after previous occurrence
                    if 0 <= target_pos < seq_len:
                        induction_scores_this.append(attn[i, target_pos].item())

                if induction_scores_this:
                    score = np.mean(induction_scores_this)
                    all_scores.setdefault((layer_idx, head_idx), []).append(score)

        del capture, input_ids, logits_masked, attn_weights
        torch.cuda.empty_cache()

        if (seq_idx + 1) % 20 == 0 or seq_idx == 0:
            print(f"  Induction scoring: {seq_idx + 1}/{num_sequences} sequences")

    # Average across sequences
    rows = []
    for (layer, head), scores in all_scores.items():
        rows.append({
            "layer": layer,
            "head": head,
            "induction_score": np.mean(scores),
            "induction_std": np.std(scores),
            "n_sequences": len(scores),
        })

    return pd.DataFrame(rows)


# ═══════════════════════════════════════════════════════════════════════════════
# R² LOADING (reuse from Experiment 3.1)
# ═══════════════════════════════════════════════════════════════════════════════

def load_or_compute_r2(
    model, adapter, tokenizer, model_spec, device, model_name, r2_cache_dir
) -> pd.DataFrame:
    """Load R² data from Experiment 3.1 if available, else compute fresh."""
    cached = Path(r2_cache_dir) / "per_sequence_r2.parquet"
    if cached.exists():
        print(f"  Loading cached R² data from {cached}")
        r2_df = pd.read_parquet(cached)
        mean_r2 = r2_df.groupby(["layer", "head"])["r2"].mean().reset_index()
        mean_r2.columns = ["layer", "head", "mean_r2"]
        return mean_r2

    # Compute fresh
    print(f"  No cached R² found. Computing from wiki sequences...")
    from experiment1.shift_kernels import RoPEEstimator
    from experiment1.norm_utils import normalize_logits_for_norm

    data_dir = Path("data/experiment1/wiki40b_en_pre2019") / model_name
    candidates = sorted(data_dir.rglob("*.jsonl"))
    sequences = []
    for jsonl_path in candidates:
        with open(jsonl_path) as f:
            for line in f:
                row = json.loads(line)
                tokens = row.get("tokens", row.get("input_ids", []))
                if len(tokens) >= R2_SEQ_LEN:
                    sequences.append(tokens[:R2_SEQ_LEN])
                if len(sequences) >= NUM_R2_SEQUENCES:
                    break
        if len(sequences) >= NUM_R2_SEQUENCES:
            break

    estimator = RoPEEstimator()
    rows = []
    for seq_idx, tokens in enumerate(sequences):
        input_ids = torch.tensor([tokens], dtype=torch.long, device=device)
        capture = adapter.capture(
            model, input_ids=input_ids,
            include_logits=True, return_token_logits=False,
            capture_attention=True, output_device="cpu",
        )
        if capture.logits is None:
            continue
        n_layers, n_heads = capture.logits.shape[:2]
        for li in range(n_layers):
            for hi in range(n_heads):
                head_logits = capture.logits[li, hi]
                prepared = normalize_logits_for_norm(head_logits, model_spec.norm)
                fit = estimator.fit_logits(prepared)
                rows.append({"layer": li, "head": hi, "r2": fit.r2})
        del capture, input_ids
        torch.cuda.empty_cache()
        if (seq_idx + 1) % 10 == 0:
            print(f"    R² profiling: {seq_idx + 1}/{len(sequences)}")

    r2_df = pd.DataFrame(rows)
    mean_r2 = r2_df.groupby(["layer", "head"])["r2"].mean().reset_index()
    mean_r2.columns = ["layer", "head", "mean_r2"]
    return mean_r2


# ═══════════════════════════════════════════════════════════════════════════════
# ANALYSIS: Cross-reference induction scores with R²
# ═══════════════════════════════════════════════════════════════════════════════

def cross_reference_analysis(
    induction_df: pd.DataFrame,
    r2_df: pd.DataFrame,
    model_name: str,
) -> dict[str, Any]:
    """Merge induction scores with R² and classify into quadrants."""
    merged = pd.merge(
        induction_df[["layer", "head", "induction_score", "induction_std"]],
        r2_df[["layer", "head", "mean_r2"]],
        on=["layer", "head"],
        how="inner",
    )

    # Compute thresholds (median split)
    r2_median = merged["mean_r2"].median()
    ind_median = merged["induction_score"].median()

    # Also compute a stricter induction threshold: top 10% = "strong induction"
    ind_p90 = merged["induction_score"].quantile(0.90)
    r2_p75 = merged["mean_r2"].quantile(0.75)
    r2_p25 = merged["mean_r2"].quantile(0.25)

    # Quadrant classification (median split)
    def classify(row):
        hi_r2 = row["mean_r2"] >= r2_median
        hi_ind = row["induction_score"] >= ind_median
        if hi_r2 and hi_ind:
            return "Q1_high_SI_high_induction"
        elif hi_r2 and not hi_ind:
            return "Q2_high_SI_low_induction"
        elif not hi_r2 and not hi_ind:
            return "Q3_low_SI_low_induction"
        else:
            return "Q4_low_SI_high_induction"

    merged["quadrant"] = merged.apply(classify, axis=1)

    # Correlation
    from scipy.stats import pearsonr, spearmanr
    r_pearson, p_pearson = pearsonr(merged["mean_r2"], merged["induction_score"])
    r_spearman, p_spearman = spearmanr(merged["mean_r2"], merged["induction_score"])

    # Strong induction heads analysis
    strong_induction = merged[merged["induction_score"] >= ind_p90]
    strong_induction_r2_mean = strong_induction["mean_r2"].mean()
    strong_induction_r2_std = strong_induction["mean_r2"].std()

    # High-SI non-induction heads (Q2 — sub-word composition candidates)
    subword_candidates = merged[
        (merged["mean_r2"] >= r2_p75) & (merged["induction_score"] < ind_median)
    ]

    # Layer distribution analysis
    quadrant_layer_means = {}
    for q in merged["quadrant"].unique():
        q_heads = merged[merged["quadrant"] == q]
        quadrant_layer_means[q] = {
            "count": len(q_heads),
            "mean_layer": float(q_heads["layer"].mean()),
            "mean_r2": float(q_heads["mean_r2"].mean()),
            "mean_induction": float(q_heads["induction_score"].mean()),
        }

    analysis = {
        "model": model_name,
        "n_heads_total": len(merged),
        "thresholds": {
            "r2_median": float(r2_median),
            "induction_median": float(ind_median),
            "induction_p90": float(ind_p90),
            "r2_p75": float(r2_p75),
            "r2_p25": float(r2_p25),
        },
        "correlation": {
            "pearson_r": float(r_pearson),
            "pearson_p": float(p_pearson),
            "spearman_r": float(r_spearman),
            "spearman_p": float(p_spearman),
        },
        "quadrant_summary": quadrant_layer_means,
        "strong_induction_heads": {
            "count": len(strong_induction),
            "mean_r2": float(strong_induction_r2_mean),
            "std_r2": float(strong_induction_r2_std),
            "mean_layer": float(strong_induction["layer"].mean()),
            "heads": [
                {"layer": int(r.layer), "head": int(r.head),
                 "induction_score": float(r.induction_score),
                 "r2": float(r.mean_r2)}
                for r in strong_induction.sort_values("induction_score", ascending=False).head(20).itertuples()
            ],
        },
        "subword_candidates": {
            "count": len(subword_candidates),
            "description": "Heads with high R² (top 25%) but low induction score (below median)",
            "mean_r2": float(subword_candidates["mean_r2"].mean()) if len(subword_candidates) > 0 else 0.0,
            "mean_layer": float(subword_candidates["layer"].mean()) if len(subword_candidates) > 0 else 0.0,
            "mean_induction": float(subword_candidates["induction_score"].mean()) if len(subword_candidates) > 0 else 0.0,
            "heads": [
                {"layer": int(r.layer), "head": int(r.head),
                 "induction_score": float(r.induction_score),
                 "r2": float(r.mean_r2)}
                for r in subword_candidates.sort_values("mean_r2", ascending=False).head(20).itertuples()
            ],
        },
    }

    return analysis, merged


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Experiment 3.2a: Induction Head Detection + R² Cross-Reference"
    )
    parser.add_argument("--model", required=True, choices=list(MODELS.keys()))
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output-dir", default="results/experiment3/induction_r2_crossref")
    parser.add_argument("--num-sequences", type=int, default=NUM_INDUCTION_SEQUENCES)
    parser.add_argument("--period", type=int, default=INDUCTION_PERIOD)
    args = parser.parse_args()

    output_dir = Path(args.output_dir) / args.model
    output_dir.mkdir(parents=True, exist_ok=True)
    model_spec = MODELS[args.model]

    print(f"{'=' * 72}")
    print(f"Experiment 3.2a: Induction Head + R² Cross-Reference — {args.model}")
    print(f"Device: {args.device}")
    print(f"Output: {output_dir}")
    print(f"{'=' * 72}")

    # ── Load model ───────────────────────────────────────────────────────────
    print("\n[1/5] Loading model and tokenizer...")
    from shared.models.loading import load_model, load_tokenizer
    loader = load_model(model_spec)
    model = loader.model.to(args.device)
    model.eval()
    tokenizer = load_tokenizer(model_spec)
    adapter = get_adapter(model_spec)
    adapter.register(model)
    print(f"  Model loaded: {model_spec.hf_id}")

    # ── Phase 1: Induction scoring ───────────────────────────────────────────
    print(f"\n[2/5] Computing induction scores ({args.num_sequences} sequences, period={args.period})...")
    t0 = time.time()
    total_len = args.period * 4  # 4 repeats for robust scoring
    induction_df = compute_induction_scores(
        model=model, adapter=adapter, tokenizer=tokenizer,
        model_spec=model_spec, device=args.device,
        num_sequences=args.num_sequences, period=args.period,
        total_len=total_len,
    )
    elapsed = time.time() - t0
    print(f"  Induction scoring complete: {len(induction_df)} heads scored in {elapsed:.1f}s")
    induction_df.to_parquet(output_dir / "induction_scores.parquet", index=False)

    # ── Phase 2: Load R² ─────────────────────────────────────────────────────
    print(f"\n[3/5] Loading shift-invariance R² data...")
    r2_cache = Path("results/experiment3/theory1_si_circuits") / args.model
    r2_df = load_or_compute_r2(
        model, adapter, tokenizer, model_spec, args.device, args.model, r2_cache
    )
    print(f"  R² data for {len(r2_df)} heads")

    # ── Phase 3: Cross-reference analysis ────────────────────────────────────
    print(f"\n[4/5] Cross-reference analysis...")
    analysis, merged_df = cross_reference_analysis(induction_df, r2_df, args.model)
    merged_df.to_parquet(output_dir / "merged_induction_r2.parquet", index=False)

    # ── Print results ────────────────────────────────────────────────────────
    print(f"\n{'=' * 72}")
    print(f"RESULTS — {args.model}")
    print(f"{'=' * 72}")

    print(f"\n  Correlation (R² vs induction score):")
    print(f"    Pearson:  r={analysis['correlation']['pearson_r']:+.4f}  p={analysis['correlation']['pearson_p']:.2e}")
    print(f"    Spearman: r={analysis['correlation']['spearman_r']:+.4f}  p={analysis['correlation']['spearman_p']:.2e}")

    print(f"\n  Quadrant analysis (median split):")
    for qname, qdata in analysis["quadrant_summary"].items():
        print(f"    {qname}: n={qdata['count']:3d}  mean_layer={qdata['mean_layer']:.1f}  "
              f"mean_R²={qdata['mean_r2']:.4f}  mean_ind={qdata['mean_induction']:.4f}")

    print(f"\n  Strong induction heads (top 10%):")
    si = analysis["strong_induction_heads"]
    print(f"    Count: {si['count']}, mean R²={si['mean_r2']:.4f} ± {si['std_r2']:.4f}, mean_layer={si['mean_layer']:.1f}")
    print(f"    Top 10:")
    for h in si["heads"][:10]:
        print(f"      L{h['layer']:2d} H{h['head']:2d}  ind={h['induction_score']:.4f}  R²={h['r2']:.4f}")

    print(f"\n  Sub-word composition candidates (high R², low induction):")
    sc = analysis["subword_candidates"]
    print(f"    Count: {sc['count']}, mean R²={sc['mean_r2']:.4f}, mean_layer={sc['mean_layer']:.1f}")
    print(f"    Top 10:")
    for h in sc["heads"][:10]:
        print(f"      L{h['layer']:2d} H{h['head']:2d}  ind={h['induction_score']:.4f}  R²={h['r2']:.4f}")

    # ── Save report ──────────────────────────────────────────────────────────
    print(f"\n[5/5] Writing report...")
    report = {
        "experiment": "3.2a_induction_r2_crossref",
        "model": args.model,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "config": {
            "num_induction_sequences": args.num_sequences,
            "induction_period": args.period,
            "total_len": total_len,
        },
        "analysis": analysis,
    }
    (output_dir / "report.json").write_text(
        json.dumps(report, indent=2, default=str), encoding="utf-8"
    )
    print(f"  Report saved to {output_dir / 'report.json'}")
    print(f"\nDone. All artifacts in: {output_dir}")


if __name__ == "__main__":
    main()
