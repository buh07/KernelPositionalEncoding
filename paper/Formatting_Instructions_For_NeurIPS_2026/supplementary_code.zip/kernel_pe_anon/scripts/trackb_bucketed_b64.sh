#!/usr/bin/env bash
set -euo pipefail

cd "/scratch2/anon/Kernel PE"
export CUDA_VISIBLE_DEVICES=5
export PYTHONUNBUFFERED=1

LOG_DIR="logs/trackb"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/trackb_bucketed_b64.log"
exec > >(tee -a "$LOG_FILE") 2>&1

PY=".venv/bin/python"

"$PY" experiment1/run.py track-b \
  --model all \
  --dataset all \
  --seq-len all \
  --device cuda \
  --track-b-centering-mode bucketed_mean \
  --track-b-bucket-size 64 \
  --track-b-output-group track_b_bucketed_mean_b64_v1 \
  --track-b-artifact-level compact

echo "Bucketed Track B b64 complete."
