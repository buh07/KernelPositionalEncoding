#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def _top_pairs(df: pd.DataFrame, *, n: int = 3) -> str:
    if df.empty:
        return "none"
    work = df.copy()
    work["abs_raw"] = work["effect_raw"].abs()
    top = work.sort_values("abs_raw", ascending=False).head(n)
    parts: list[str] = []
    for row in top.to_dict(orient="records"):
        parts.append(f"pair {int(row['pair_idx'])} (effect_raw={float(row['effect_raw']):+.4f})")
    return ", ".join(parts)


def main() -> None:
    ap = argparse.ArgumentParser(description="Compare legacy vs percentile-normalized Gemma pair sweep reports.")
    ap.add_argument("--legacy-report-dir", type=Path, required=True)
    ap.add_argument("--normalized-report-dir", type=Path, required=True)
    ap.add_argument("--output-md", type=Path, required=True)
    args = ap.parse_args()

    legacy_pair = pd.read_parquet(args.legacy_report_dir / "pair_effects.parquet")
    norm_pair = pd.read_parquet(args.normalized_report_dir / "pair_effects.parquet")
    legacy_floor = pd.read_parquet(args.legacy_report_dir / "floor_exclusion_summary.parquet")
    norm_floor = pd.read_parquet(args.normalized_report_dir / "floor_exclusion_summary.parquet")

    legacy_pair = legacy_pair[legacy_pair["model"] == "gemma-7b"].copy()
    norm_pair = norm_pair[norm_pair["model"] == "gemma-7b"].copy()
    legacy_floor = legacy_floor[legacy_floor["model"] == "gemma-7b"].copy()
    norm_floor = norm_floor[norm_floor["model"] == "gemma-7b"].copy()

    keys = sorted(
        set(zip(legacy_pair["task"].astype(str), legacy_pair["span"].astype(int)))
        | set(zip(norm_pair["task"].astype(str), norm_pair["span"].astype(int)))
    )

    lines: list[str] = [
        "# Gemma Legacy vs Percentile-Normalized Pair Sweep",
        "",
        "Policy: exploratory comparison only; non-retroactive to confirmatory claims.",
        "",
        "## Top-pair shift summary",
    ]
    if not keys:
        lines.append("- No Gemma pair rows found in one or both reports.")
    for task, span in keys:
        old_sub = legacy_pair[(legacy_pair["task"] == task) & (legacy_pair["span"] == span)]
        new_sub = norm_pair[(norm_pair["task"] == task) & (norm_pair["span"] == span)]
        lines.append(f"- `{task}` span `{span}`")
        lines.append(f"  legacy top |abs(effect_raw)|: {_top_pairs(old_sub)}")
        lines.append(f"  normalized top |abs(effect_raw)|: {_top_pairs(new_sub)}")

    lines.extend(["", "## Floor/evaluability comparison"])
    floor_keys = sorted(
        set(zip(legacy_floor["task"].astype(str), legacy_floor["span"].astype(int)))
        | set(zip(norm_floor["task"].astype(str), norm_floor["span"].astype(int)))
    )
    if not floor_keys:
        lines.append("- No Gemma floor summary rows found in one or both reports.")
    for task, span in floor_keys:
        old_sub = legacy_floor[(legacy_floor["task"] == task) & (legacy_floor["span"] == span)]
        new_sub = norm_floor[(norm_floor["task"] == task) & (norm_floor["span"] == span)]
        if old_sub.empty:
            old_text = "legacy: n/a"
        else:
            r = old_sub.iloc[0]
            old_text = (
                f"legacy: none_acc={float(r['none_accuracy_mean']):.4f}, "
                f"pass_rate={float(r['none_pass_rate_at_floor']):.3f}, "
                f"excluded={int(r['excluded_floor_rows'])}"
            )
        if new_sub.empty:
            new_text = "normalized: n/a"
        else:
            r = new_sub.iloc[0]
            new_text = (
                f"normalized: none_acc={float(r['none_accuracy_mean']):.4f}, "
                f"pass_rate={float(r['none_pass_rate_at_floor']):.3f}, "
                f"excluded={int(r['excluded_floor_rows'])}"
            )
        lines.append(f"- `{task}` span `{span}`: {old_text}; {new_text}")

    lines.extend(
        [
            "",
            "## Interpretation guardrails",
            "- Compare spectral location by percentile, not raw pair index, across different head dimensions.",
            "- Use Holm-adjusted outputs in the corresponding report folders for inferential claims.",
            "- Treat this memo as descriptive context for model-comparability interpretation.",
        ]
    )

    args.output_md.parent.mkdir(parents=True, exist_ok=True)
    args.output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(str(args.output_md))


if __name__ == "__main__":
    main()
