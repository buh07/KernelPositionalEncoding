#!/usr/bin/env bash
set -euo pipefail

cd "/scratch2/anon/Kernel PE"
export CUDA_VISIBLE_DEVICES=5
export PYTHONUNBUFFERED=1

LOG_DIR="logs/trackb"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/trackb_bucketed_resume_g5.log"
exec > >(tee -a "$LOG_FILE") 2>&1

PY=".venv/bin/python"
COMMON_ARGS=(
  experiment1/run.py track-b
  --device cuda
  --track-b-centering-mode bucketed_mean
  --track-b-bucket-size 32
  --track-b-output-group track_b_bucketed_mean_v1
  --track-b-artifact-level compact
)

run_one() {
  local model="$1"
  local dataset="$2"
  local seq_len="$3"
  local out="results/track_b_bucketed_mean_v1/${model}/${dataset}/len_${seq_len}/summary.parquet"

  if [[ -f "$out" ]]; then
    echo "SKIP already complete: model=${model} dataset=${dataset} len=${seq_len}"
    return 0
  fi

  echo "START model=${model} dataset=${dataset} len=${seq_len}"
  "$PY" "${COMMON_ARGS[@]}" --model "$model" --dataset "$dataset" --seq-len "$seq_len"
  echo "DONE  model=${model} dataset=${dataset} len=${seq_len}"
}

# Resume only missing combos from the interrupted run.
run_one "gpt2-medium" "synthetic_random" "1024"
run_one "llama-3.2-1b" "synthetic_random" "1024"

run_one "gpt2-small" "wiki40b_en_pre2019" "256"
run_one "gpt2-small" "wiki40b_en_pre2019" "1024"
run_one "gpt2-small" "codesearchnet_python_snapshot" "256"
run_one "gpt2-small" "codesearchnet_python_snapshot" "1024"
run_one "gpt2-small" "synthetic_random" "256"
run_one "gpt2-small" "synthetic_random" "1024"

run_one "olmo-1b" "wiki40b_en_pre2019" "256"
run_one "olmo-1b" "wiki40b_en_pre2019" "1024"
run_one "olmo-1b" "codesearchnet_python_snapshot" "256"
run_one "olmo-1b" "codesearchnet_python_snapshot" "1024"
run_one "olmo-1b" "synthetic_random" "256"
run_one "olmo-1b" "synthetic_random" "1024"

echo "All missing bucketed Track B combos complete."
