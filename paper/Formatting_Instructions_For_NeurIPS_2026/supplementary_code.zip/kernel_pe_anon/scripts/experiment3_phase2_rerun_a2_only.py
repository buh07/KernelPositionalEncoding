#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import pandas as pd

import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiment3.phase2 import exp3p2a_positional_broadcast as a2mod  # noqa: E402
from experiment3.theory1_si_circuits import MODELS  # noqa: E402
from shared.models.loading import load_model, load_tokenizer  # noqa: E402


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def _load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _parse_device_map(raw: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for tok in [x.strip() for x in str(raw).split(",") if x.strip()]:
        k, v = tok.split(":", 1)
        out[k.strip()] = v.strip()
    return out


def _run_model(
    *,
    model_name: str,
    device: str,
    output_root: Path,
    probe_train_sequences: int,
    probe_eval_sequences: int,
    probe_seq_len: int,
    probe_positions_per_seq: int,
    probe_batch_size: int,
    bootstrap_samples: int,
    seed: int,
    pos_backend: str,
    allow_nltk_download: bool,
) -> dict[str, Any]:
    print(
        f"[A2-only] model={model_name} device={device} "
        f"train={probe_train_sequences} eval={probe_eval_sequences} pos_backend={pos_backend}",
        flush=True,
    )
    out_dir = output_root / model_name
    out_dir.mkdir(parents=True, exist_ok=True)

    model_spec = MODELS[model_name]
    loaded = load_model(model_spec)
    model = loaded.model.to(device)
    model.eval()
    tokenizer = load_tokenizer(model_spec)
    conditions = a2mod._load_head_groups(model_name)

    t0 = time.time()
    probe_df, delta_report = a2mod._run_subexp_a2(
        model_name=model_name,
        model=model,
        tokenizer=tokenizer,
        device=device,
        conditions=conditions,
        output_dir=out_dir,
        probe_train_sequences=max(20, int(probe_train_sequences)),
        probe_eval_sequences=max(10, int(probe_eval_sequences)),
        probe_seq_len=max(128, int(probe_seq_len)),
        probe_positions_per_seq=max(4, int(probe_positions_per_seq)),
        probe_batch_size=max(1, int(probe_batch_size)),
        bootstrap_samples=max(500, int(bootstrap_samples)),
        seed=int(seed),
        pos_backend=str(pos_backend),
        allow_nltk_download=bool(allow_nltk_download),
    )
    probe_df.to_parquet(out_dir / "probe_accuracy.parquet", index=False)
    _write_json(out_dir / "delta_probe_comparison.json", delta_report)

    # Refresh A report metadata if present.
    rep_path = out_dir / "a_report.json"
    if rep_path.exists():
        rep = _load_json(rep_path)
        rep["timestamp"] = time.strftime("%Y-%m-%d %H:%M:%S")
        rep["a2_pos_label_backend"] = delta_report.get("pos_label_backend", {})
        if isinstance(rep.get("artifacts"), dict):
            rep["artifacts"]["probe_accuracy"] = str(out_dir / "probe_accuracy.parquet")
            rep["artifacts"]["delta_probe_comparison"] = str(out_dir / "delta_probe_comparison.json")
        limitations = [str(x) for x in rep.get("limitations", [])]
        new_lim = (
            "A.2 coarse POS probe uses context-aware NLTK tagging."
            if str(delta_report.get("pos_label_backend", {}).get("effective", "")) == "nltk"
            else "A.2 coarse POS probe uses heuristic lexical tagging (NLTK unavailable/disabled)."
        )
        replaced = False
        for i, s in enumerate(limitations):
            if s.startswith("A.2 coarse POS probe uses"):
                limitations[i] = new_lim
                replaced = True
                break
        if not replaced:
            limitations.insert(0, new_lim)
        rep["limitations"] = limitations
        _write_json(rep_path, rep)

    elapsed = time.time() - t0
    return {
        "model": model_name,
        "elapsed_seconds": float(elapsed),
        "probe_acceptance": delta_report.get("probe_acceptance", {}),
        "pos_label_backend": delta_report.get("pos_label_backend", {}),
        "paths": {
            "probe_accuracy": str(out_dir / "probe_accuracy.parquet"),
            "delta_probe_comparison": str(out_dir / "delta_probe_comparison.json"),
        },
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="Rerun only 3P2-A.2 probe decoding")
    ap.add_argument("--model", choices=["all", *a2mod.TARGET_MODELS], default="all")
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument(
        "--device-map",
        default="llama-3.1-8b:cuda:0,olmo-2-7b:cuda:1",
        help="Comma-separated model:device map when --model all",
    )
    ap.add_argument("--probe-train-sequences", type=int, default=500)
    ap.add_argument("--probe-eval-sequences", type=int, default=100)
    ap.add_argument("--probe-seq-len", type=int, default=512)
    ap.add_argument("--probe-positions-per-seq", type=int, default=64)
    ap.add_argument("--probe-batch-size", type=int, default=4)
    ap.add_argument("--bootstrap-samples", type=int, default=5000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--pos-backend", choices=a2mod.POS_BACKENDS, default="auto")
    ap.add_argument("--allow-nltk-download", action="store_true")
    ap.add_argument("--output-root", default="results/experiment3_phase2/exp3p2a_positional_broadcast")
    args = ap.parse_args()

    output_root = ROOT / str(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    models = list(a2mod.TARGET_MODELS) if args.model == "all" else [str(args.model)]
    device_map = _parse_device_map(args.device_map) if args.model == "all" else {}

    summary: dict[str, Any] = {"timestamp": time.strftime("%Y-%m-%d %H:%M:%S"), "models": {}}
    for model_name in models:
        device = device_map.get(model_name, str(args.device))
        rep = _run_model(
            model_name=model_name,
            device=device,
            output_root=output_root,
            probe_train_sequences=int(args.probe_train_sequences),
            probe_eval_sequences=int(args.probe_eval_sequences),
            probe_seq_len=int(args.probe_seq_len),
            probe_positions_per_seq=int(args.probe_positions_per_seq),
            probe_batch_size=int(args.probe_batch_size),
            bootstrap_samples=int(args.bootstrap_samples),
            seed=int(args.seed),
            pos_backend=str(args.pos_backend),
            allow_nltk_download=bool(args.allow_nltk_download),
        )
        summary["models"][model_name] = rep

    _write_json(output_root / "a2_only_rerun_summary.json", summary)


if __name__ == "__main__":
    main()
