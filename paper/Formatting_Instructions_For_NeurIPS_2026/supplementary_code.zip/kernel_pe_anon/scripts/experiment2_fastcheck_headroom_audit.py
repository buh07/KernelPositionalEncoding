#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd


TASK_CLASS = {
    "local_copy_offset": "short",
    "local_key_match": "short",
    "delayed_copy": "long",
    "long_range_retrieval": "long",
}


def main() -> None:
    ap = argparse.ArgumentParser(description="Headroom audit by task/span for fast-check baselines.")
    ap.add_argument("--aggregate-task-metrics", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--model", type=str, default="llama-3.1-8b")
    ap.add_argument("--chance-default", type=float, default=0.10)
    args = ap.parse_args()

    df = pd.read_parquet(args.aggregate_task_metrics)
    need_cols = {"split", "model", "task", "span", "seed", "intervention", "mean_accuracy"}
    missing = sorted(need_cols - set(df.columns))
    if missing:
        raise RuntimeError(f"Missing required columns in aggregate metrics: {missing}")
    if "chance_accuracy" not in df.columns:
        df["chance_accuracy"] = float(args.chance_default)

    base = df[
        (df["split"] == "synthetic")
        & (df["model"] == args.model)
        & (df["intervention"] == "none")
        & (df["task"].isin(sorted(TASK_CLASS.keys())))
    ][["model", "task", "span", "seed", "mean_accuracy", "chance_accuracy"]].copy()
    if base.empty:
        raise RuntimeError("No baseline synthetic rows found for headroom audit.")

    base["task_class"] = base["task"].map(TASK_CLASS)
    base["chance_accuracy_effective"] = base["chance_accuracy"].fillna(float(args.chance_default)).astype(float)
    base["baseline_headroom"] = base["mean_accuracy"].astype(float) - base["chance_accuracy_effective"]
    base["max_possible_drop"] = base["baseline_headroom"]

    by_family = (
        base.groupby(["model", "task_class", "task", "span"], as_index=False)
        .agg(
            n=("seed", "count"),
            none_accuracy_mean=("mean_accuracy", "mean"),
            chance_accuracy_mean=("chance_accuracy_effective", "mean"),
            baseline_headroom_mean=("baseline_headroom", "mean"),
            max_possible_drop_mean=("max_possible_drop", "mean"),
            none_accuracy_min=("mean_accuracy", "min"),
        )
        .sort_values(["task_class", "task", "span"])
    )

    class_means = (
        base.groupby(["model", "task_class"], as_index=False)
        .agg(
            n=("seed", "count"),
            none_accuracy_mean=("mean_accuracy", "mean"),
            chance_accuracy_mean=("chance_accuracy_effective", "mean"),
            baseline_headroom_mean=("baseline_headroom", "mean"),
        )
    )
    short_row = class_means[class_means["task_class"] == "short"]
    long_row = class_means[class_means["task_class"] == "long"]
    headroom_ratio = None
    if (not short_row.empty) and (not long_row.empty):
        short_headroom = float(short_row["baseline_headroom_mean"].iloc[0])
        long_headroom = float(long_row["baseline_headroom_mean"].iloc[0])
        headroom_ratio = (long_headroom / max(short_headroom, 1e-12))

    summary: dict[str, Any] = {
        "generated_at": pd.Timestamp.utcnow().isoformat(),
        "model": str(args.model),
        "source": str(args.aggregate_task_metrics),
        "chance_default": float(args.chance_default),
        "rows_family": int(len(by_family)),
        "rows_class": int(len(class_means)),
        "long_short_headroom_ratio": (None if headroom_ratio is None else float(headroom_ratio)),
        "notes": [
            "baseline_headroom = none_accuracy - chance_accuracy_effective",
            "max_possible_drop = baseline_headroom",
        ],
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    base.to_parquet(args.output_dir / "headroom_audit_per_seed.parquet", engine="pyarrow", index=False)
    by_family.to_parquet(args.output_dir / "headroom_audit_by_span.parquet", engine="pyarrow", index=False)
    class_means.to_parquet(args.output_dir / "headroom_audit_by_class.parquet", engine="pyarrow", index=False)
    (args.output_dir / "headroom_audit_by_span.json").write_text(
        json.dumps(
            {
                "summary": summary,
                "task_span_rows": by_family.to_dict(orient="records"),
                "class_rows": class_means.to_dict(orient="records"),
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    memo_lines = [
        "# Headroom Audit Memo",
        "",
        f"Source: `{args.aggregate_task_metrics}`",
        f"Model: `{args.model}`",
        f"Long/short headroom ratio: `{summary['long_short_headroom_ratio']}`",
        "",
        "This artifact is exploratory and non-gating.",
    ]
    (args.output_dir / "headroom_audit_memo.md").write_text("\n".join(memo_lines) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
