#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def _parse_int_csv(raw: str) -> list[int]:
    vals: list[int] = []
    seen: set[int] = set()
    for part in str(raw).split(","):
        tok = part.strip()
        if not tok:
            continue
        value = int(tok)
        if value in seen:
            continue
        seen.add(value)
        vals.append(value)
    if not vals:
        raise RuntimeError("spans list is empty.")
    return vals


def _contiguous_prefix(values: list[int], feasible: dict[int, bool]) -> list[int]:
    out: list[int] = []
    for v in values:
        if bool(feasible.get(v, False)):
            out.append(int(v))
            continue
        break
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description="Finalize Mistral feasibility summary from aggregate task metrics.")
    ap.add_argument("--aggregate-task-metrics", type=Path, required=True)
    ap.add_argument("--output-json", type=Path, required=True)
    ap.add_argument("--model", type=str, default="mistral-7b-v0.1")
    ap.add_argument("--task", type=str, default="long_range_retrieval")
    ap.add_argument("--spans", type=str, default="24,32,48,64")
    ap.add_argument("--seeds", type=str, default="0,1,2")
    ap.add_argument("--floor-threshold", type=float, default=0.15)
    ap.add_argument("--min-pass-rate", type=float, default=2.0 / 3.0)
    args = ap.parse_args()

    spans = _parse_int_csv(args.spans)
    seeds = set(_parse_int_csv(args.seeds))
    df = pd.read_parquet(args.aggregate_task_metrics)
    req = {"split", "model", "task", "span", "seed", "intervention", "mean_accuracy"}
    missing = sorted(req - set(df.columns))
    if missing:
        raise RuntimeError(f"aggregate metrics missing columns: {missing}")

    filt = df[
        (df["split"] == "synthetic")
        & (df["intervention"] == "none")
        & (df["model"] == str(args.model))
        & (df["task"] == str(args.task))
        & (df["span"].isin(spans))
        & (df["seed"].isin(sorted(seeds)))
    ].copy()
    if filt.empty:
        raise RuntimeError("No rows matched Mistral feasibility filters.")

    filt["pass_floor"] = (filt["mean_accuracy"].astype(float) >= float(args.floor_threshold)).astype(float)
    grouped = (
        filt.groupby("span", as_index=False)
        .agg(
            n=("seed", "count"),
            none_accuracy_mean=("mean_accuracy", "mean"),
            pass_rate=("pass_floor", "mean"),
        )
        .sort_values("span")
    )
    feasible_map = {int(r["span"]): float(r["pass_rate"]) >= float(args.min_pass_rate) for r in grouped.to_dict(orient="records")}
    selected = _contiguous_prefix(spans, feasible_map)
    status = "ok" if len(selected) >= 2 else "insufficient_feasible_spans"
    payload = {
        "status": status,
        "model": str(args.model),
        "task": str(args.task),
        "spans_tested": [int(s) for s in spans],
        "seeds": sorted(int(x) for x in seeds),
        "floor_threshold": float(args.floor_threshold),
        "min_pass_rate": float(args.min_pass_rate),
        "span_rows": grouped.to_dict(orient="records"),
        "feasible_by_span": {str(k): bool(v) for k, v in feasible_map.items()},
        "selected_retrieval_spans": [int(s) for s in selected],
        "retrieval_evaluable": bool(len(selected) >= 2),
        "selection_policy": "contiguous_prefix_from_smallest_tested_span",
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
