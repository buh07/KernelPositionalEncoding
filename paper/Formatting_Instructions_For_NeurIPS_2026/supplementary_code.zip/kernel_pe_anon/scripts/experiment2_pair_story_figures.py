#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _load_story(story_path: Path) -> dict[str, Any]:
    if not story_path.exists():
        raise FileNotFoundError(f"Missing story snapshot: {story_path}")
    return json.loads(story_path.read_text(encoding="utf-8"))


def _theme() -> None:
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update(
        {
            "figure.dpi": 140,
            "savefig.dpi": 220,
            "font.size": 11,
            "axes.titlesize": 13,
            "axes.labelsize": 11,
            "legend.fontsize": 10,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def fig_llama_trend(story: dict[str, Any], out: Path) -> None:
    rows = story["outcome_board"]["llama"]["evidence"]["retrieval_pair0_vs_pair56"]
    spans = [int(r["span"]) for r in rows]
    eff_raw = [float(r["effect_raw"]) for r in rows]
    eff_head = [float(r["effect_over_headroom"]) for r in rows]

    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    ax.plot(spans, eff_raw, marker="o", linewidth=2.0, color="#1f77b4", label="effect_raw")
    ax.plot(spans, eff_head, marker="o", linewidth=2.0, color="#d62728", label="effect_over_headroom")
    ax.axhline(0.0, color="#555", linewidth=1.0, linestyle="--")
    ax.set_title("Llama Retrieval: pair0_vs_pair56 across span")
    ax.set_xlabel("Span")
    ax.set_ylabel("Effect size")
    ax.set_xticks(spans)
    ax.legend(loc="best")
    ax.text(
        0.02,
        0.02,
        "Exploratory only; Holm-corrected significance in report tables",
        transform=ax.transAxes,
        fontsize=9,
        color="#555",
    )
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def fig_heatmap(planned: pd.DataFrame, out: Path) -> None:
    # Heatmap over planned contrasts using headroom-normalized effect.
    df = planned.copy()
    df["family"] = df.apply(lambda r: f"{r['model']}\n{r['task']}\nspan={int(r['span'])}", axis=1)
    pivot = df.pivot(index="family", columns="contrast_name", values="effect_over_headroom")
    order_cols = ["pair0_vs_pair56", "low_third_vs_high_third"]
    pivot = pivot.reindex(columns=[c for c in order_cols if c in pivot.columns])

    vals = pivot.values
    vmax = np.nanmax(np.abs(vals)) if vals.size else 1.0
    vmax = max(float(vmax), 0.1)

    fig, ax = plt.subplots(figsize=(7.8, max(4.2, 0.52 * len(pivot.index))))
    im = ax.imshow(vals, cmap="coolwarm", vmin=-vmax, vmax=vmax, aspect="auto")
    ax.set_title("Planned-contrast heatmap (effect_over_headroom)")
    ax.set_xticks(np.arange(len(pivot.columns)))
    ax.set_xticklabels(list(pivot.columns), rotation=20, ha="right")
    ax.set_yticks(np.arange(len(pivot.index)))
    ax.set_yticklabels(list(pivot.index))

    for i in range(vals.shape[0]):
        for j in range(vals.shape[1]):
            v = vals[i, j]
            txt = "nan" if not np.isfinite(v) else f"{v:+.3f}"
            ax.text(j, i, txt, ha="center", va="center", fontsize=9, color="black")

    cbar = fig.colorbar(im, ax=ax, shrink=0.9)
    cbar.set_label("effect_over_headroom")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def fig_floor_panel(story: dict[str, Any], out: Path) -> None:
    rows = story["floor_evaluability"]["rows"]
    df = pd.DataFrame(rows)
    df["family"] = df.apply(lambda r: f"{r['model']}|{r['task']}|{int(r['span'])}", axis=1)
    df = df.sort_values(["model", "task", "span"]).reset_index(drop=True)

    x = np.arange(len(df))
    width = 0.42

    fig, ax1 = plt.subplots(figsize=(9.4, 4.6))
    ax1.bar(x - width / 2, df["none_accuracy_mean"], width=width, color="#1f77b4", label="none_accuracy_mean")
    ax1.set_ylabel("None accuracy")
    ax1.set_ylim(0.0, max(0.7, float(df["none_accuracy_mean"].max()) + 0.08))

    ax2 = ax1.twinx()
    ax2.bar(x + width / 2, df["none_pass_rate_at_floor"], width=width, color="#2ca02c", alpha=0.75, label="none_pass_rate_at_floor")
    ax2.set_ylabel("Pass rate at floor")
    ax2.set_ylim(0.0, 1.05)

    ax1.set_xticks(x)
    ax1.set_xticklabels(df["family"], rotation=30, ha="right")
    ax1.set_title("Baseline/evaluability panel by family")

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc="upper right")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def fig_mistral_feas(feas: dict[str, Any], out: Path) -> None:
    rows = feas.get("span_rows", [])
    if not rows:
        raise ValueError("No span_rows in Mistral feasibility summary")
    spans = [int(r["span"]) for r in rows]
    acc = [float(r["none_accuracy_mean"]) for r in rows]
    pr = [float(r["pass_rate"]) for r in rows]
    threshold = float(feas.get("floor_threshold", 0.15))

    fig, ax1 = plt.subplots(figsize=(7.2, 4.4))
    ax1.plot(spans, acc, marker="o", linewidth=2.0, color="#1f77b4", label="none_accuracy_mean")
    ax1.axhline(threshold, color="#d62728", linestyle="--", linewidth=1.5, label=f"floor_threshold={threshold:.2f}")
    ax1.set_xlabel("Span")
    ax1.set_ylabel("None accuracy")

    ax2 = ax1.twinx()
    ax2.plot(spans, pr, marker="s", linewidth=2.0, color="#2ca02c", label="pass_rate")
    ax2.set_ylabel("Pass rate")
    ax2.set_ylim(0.0, 1.05)

    ax1.set_title("Mistral retrieval feasibility pre-pass")
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper right")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def fig_pair_profiles_retrieval(story: dict[str, Any], out: Path) -> None:
    llama_keys = ["llama_retrieval_span32", "llama_retrieval_span48", "llama_retrieval_span64"]
    olmo_keys = ["olmo_retrieval_span24", "olmo_retrieval_span32"]
    profiles = story["pair_profiles"]

    fig, axes = plt.subplots(1, 2, figsize=(11.8, 4.6), sharey=True)

    ax = axes[0]
    for key, color in zip(llama_keys, ["#1f77b4", "#ff7f0e", "#2ca02c"], strict=True):
        rows = profiles.get(key, [])
        if not rows:
            continue
        x = [int(r["pair_idx"]) for r in rows]
        y = [float(r["effect_over_headroom"]) for r in rows]
        span = key.replace("llama_retrieval_span", "")
        ax.plot(x, y, marker="o", linewidth=2.0, color=color, label=f"span {span}")
    ax.axhline(0.0, color="#666", linestyle="--", linewidth=1.0)
    ax.set_title("Llama retrieval: per-pair headroom effect")
    ax.set_xlabel("Pair index")
    ax.set_ylabel("effect_over_headroom")
    ax.legend(loc="best")

    ax = axes[1]
    for key, color in zip(olmo_keys, ["#9467bd", "#8c564b"], strict=True):
        rows = profiles.get(key, [])
        if not rows:
            continue
        x = [int(r["pair_idx"]) for r in rows]
        y = [float(r["effect_over_headroom"]) for r in rows]
        span = key.replace("olmo_retrieval_span", "")
        ax.plot(x, y, marker="o", linewidth=2.0, color=color, label=f"span {span}")
    ax.axhline(0.0, color="#666", linestyle="--", linewidth=1.0)
    ax.set_title("OLMo retrieval: per-pair headroom effect")
    ax.set_xlabel("Pair index")
    ax.legend(loc="best")

    fig.suptitle("Pair profiles reveal monotonic vs non-monotonic retrieval structure", fontsize=13, y=1.02)
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def fig_pair_profiles_mirror(story: dict[str, Any], out: Path) -> None:
    profiles = story["pair_profiles"]
    keys = [
        ("llama_local_key_match", "llama-3.1-8b", "#1f77b4"),
        ("olmo_local_key_match", "olmo-2-7b", "#9467bd"),
        ("mistral_local_key_match", "mistral-7b-v0.1", "#17becf"),
    ]

    fig, ax = plt.subplots(figsize=(8.6, 4.6))
    for key, label, color in keys:
        rows = profiles.get(key, [])
        if not rows:
            continue
        x = [int(r["pair_idx"]) for r in rows]
        y = [float(r["effect_over_headroom"]) for r in rows]
        ax.plot(x, y, marker="o", linewidth=2.0, color=color, label=label)
    ax.axhline(0.0, color="#666", linestyle="--", linewidth=1.0)
    ax.set_title("Local-key-match mirror: per-pair headroom effect")
    ax.set_xlabel("Pair index")
    ax.set_ylabel("effect_over_headroom")
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def fig_pair_percentile_mapping(story: dict[str, Any], out: Path) -> None:
    cmp_meta = story.get("gemma_comparability", {})
    llama_pairs = int(cmp_meta.get("llama_pairs", 64))
    gemma_pairs = int(cmp_meta.get("gemma_pairs", 128))
    pair56_pct_llama = float(cmp_meta.get("percentile_examples", {}).get("pair56_in_llama_olmo", 0.888889))
    pair56_pct_gemma = float(cmp_meta.get("percentile_examples", {}).get("pair56_in_gemma", 0.440945))
    mapped_pair = int(cmp_meta.get("percentile_examples", {}).get("gemma_pair_at_llama56_percentile", 112))

    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    labels = [
        f"Llama/OLMo: pair 56\n({llama_pairs} pairs)",
        f"Gemma: pair 56\n({gemma_pairs} pairs)",
        f"Gemma mapped pair\n(index {mapped_pair})",
    ]
    vals = [pair56_pct_llama, pair56_pct_gemma, pair56_pct_llama]
    colors = ["#1f77b4", "#d62728", "#2ca02c"]
    bars = ax.bar(labels, vals, color=colors)
    ax.set_ylim(0.0, 1.0)
    ax.set_ylabel("Frequency percentile")
    ax.set_title("Cross-model pair-index comparability requires percentile mapping")
    for b, v in zip(bars, vals, strict=True):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.02, f"{v:.3f}", ha="center", va="bottom", fontsize=10)
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate figure pack for Experiment 2 pair-sweep story.")
    parser.add_argument("--run-tag", required=True)
    parser.add_argument("--quick-root", default="results/experiment2/quick")
    parser.add_argument("--report-subdir", default="reports/pair_expanded")
    parser.add_argument("--manifests-subdir", default="manifests")
    parser.add_argument("--story-file", default="story_snapshot.json")
    args = parser.parse_args()

    run_root = Path(args.quick_root) / args.run_tag
    report_dir = run_root / args.report_subdir
    manifests_dir = run_root / args.manifests_subdir
    story_path = report_dir / args.story_file
    out_dir = report_dir / "figures"
    out_dir.mkdir(parents=True, exist_ok=True)

    story = _load_story(story_path)
    planned = pd.read_parquet(report_dir / "planned_contrasts.parquet")
    pair_effects = pd.read_parquet(report_dir / "pair_effects.parquet")
    feas = json.loads((manifests_dir / f"{args.run_tag}_mistral_feas.summary.json").read_text(encoding="utf-8"))

    _theme()
    f1 = out_dir / "fig1_llama_retrieval_pair0_vs_pair56_trend.png"
    f2 = out_dir / "fig2_cross_model_planned_contrast_heatmap.png"
    f3 = out_dir / "fig3_baseline_floor_evaluability_panel.png"
    f4 = out_dir / "fig4_mistral_retrieval_feasibility.png"
    f5 = out_dir / "fig5_pair_profiles_retrieval.png"
    f6 = out_dir / "fig6_pair_profiles_local_key_match.png"
    f7 = out_dir / "fig7_pair_index_percentile_mapping.png"

    fig_llama_trend(story, f1)
    fig_heatmap(planned, f2)
    fig_floor_panel(story, f3)
    fig_mistral_feas(feas, f4)
    # pair_effects read above for schema validation; story carries profile rows used for plotting.
    _ = pair_effects
    fig_pair_profiles_retrieval(story, f5)
    fig_pair_profiles_mirror(story, f6)
    fig_pair_percentile_mapping(story, f7)

    print(
        json.dumps(
            {
                "status": "ok",
                "output_dir": str(out_dir),
                "figures": [str(f1), str(f2), str(f3), str(f4), str(f5), str(f6), str(f7)],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
