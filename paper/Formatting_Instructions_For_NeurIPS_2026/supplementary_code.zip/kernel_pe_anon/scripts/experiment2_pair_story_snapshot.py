#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


@dataclass
class StoryInputs:
    run_tag: str
    report_dir: Path
    manifests_dir: Path
    results_root: Path
    models_root: Path
    phase2b_run_id: str
    optiona_feas_run_id: str
    scaleup_lock_run_id: str
    scaleup_phase2a_run_id: str


def _float(v: Any) -> float:
    try:
        return float(v)
    except Exception:
        return float("nan")


def _load_inputs(inputs: StoryInputs) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    planned_path = inputs.report_dir / "planned_contrasts.parquet"
    floor_path = inputs.report_dir / "floor_exclusion_summary.parquet"
    effects_path = inputs.report_dir / "pair_effects.parquet"
    feas_path = inputs.manifests_dir / f"{inputs.run_tag}_mistral_feas.summary.json"
    if not planned_path.exists():
        raise FileNotFoundError(f"Missing planned contrasts file: {planned_path}")
    if not floor_path.exists():
        raise FileNotFoundError(f"Missing floor summary file: {floor_path}")
    if not effects_path.exists():
        raise FileNotFoundError(f"Missing pair effects file: {effects_path}")
    if not feas_path.exists():
        raise FileNotFoundError(f"Missing Mistral feasibility summary: {feas_path}")

    planned = pd.read_parquet(planned_path)
    floor = pd.read_parquet(floor_path)
    effects = pd.read_parquet(effects_path)
    feas = json.loads(feas_path.read_text(encoding="utf-8"))
    return planned, floor, {"mistral_feasibility": feas, "pair_effects": effects}


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Missing JSON artifact: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def _family_row(df: pd.DataFrame, *, model: str, task: str, span: int, contrast: str) -> pd.Series:
    m = (
        (df["model"] == model)
        & (df["task"] == task)
        & (df["span"].astype(int) == int(span))
        & (df["contrast_name"] == contrast)
    )
    sub = df.loc[m]
    if sub.empty:
        raise KeyError(f"No planned contrast row for model={model}, task={task}, span={span}, contrast={contrast}")
    return sub.iloc[0]


def _round(v: Any, nd: int = 6) -> float:
    fv = _float(v)
    if not np.isfinite(fv):
        return float("nan")
    return round(fv, nd)


def build_story_snapshot(inputs: StoryInputs) -> dict[str, Any]:
    planned, floor, extras = _load_inputs(inputs)
    feas = extras["mistral_feasibility"]
    pair_effects = extras["pair_effects"]

    # Key rows for concise narrative.
    llama_rows = [
        _family_row(
            planned,
            model="llama-3.1-8b",
            task="long_range_retrieval",
            span=span,
            contrast="pair0_vs_pair56",
        )
        for span in (32, 48, 64)
    ]
    llama_mirror = _family_row(
        planned,
        model="llama-3.1-8b",
        task="local_key_match",
        span=0,
        contrast="pair0_vs_pair56",
    )

    olmo_rows = [
        _family_row(
            planned,
            model="olmo-2-7b",
            task="long_range_retrieval",
            span=span,
            contrast="pair0_vs_pair56",
        )
        for span in (24, 32)
    ]
    olmo_mirror = _family_row(
        planned,
        model="olmo-2-7b",
        task="local_key_match",
        span=0,
        contrast="pair0_vs_pair56",
    )

    mistral_mirror = _family_row(
        planned,
        model="mistral-7b-v0.1",
        task="local_key_match",
        span=0,
        contrast="pair0_vs_pair56",
    )

    # Baselines/floor summary for caveats.
    floor_key_cols = [
        "model",
        "task",
        "span",
        "none_accuracy_mean",
        "none_pass_rate_at_floor",
        "excluded_floor_rows",
    ]
    floor_rows = floor[floor_key_cols].copy().sort_values(["model", "task", "span"])  # type: ignore[arg-type]

    llama_headroom_trend = [_float(r["effect_over_headroom"]) for r in llama_rows]
    llama_trend_monotonic_headroom = bool(
        llama_headroom_trend[0] < llama_headroom_trend[1] < llama_headroom_trend[2]
    )

    def _profile(model: str, task: str, span: int) -> list[dict[str, Any]]:
        m = (
            (pair_effects["model"] == model)
            & (pair_effects["task"] == task)
            & (pair_effects["span"].astype(int) == int(span))
        )
        sub = pair_effects.loc[m].sort_values("pair_idx")
        rows: list[dict[str, Any]] = []
        for _, r in sub.iterrows():
            rows.append(
                {
                    "pair_idx": int(r["pair_idx"]),
                    "effect_raw": _round(r["effect_raw"], 6),
                    "effect_over_headroom": _round(r["effect_over_headroom"], 6),
                    "p_headroom_holm": _round(r["p_headroom_holm"], 6),
                }
            )
        return rows

    # Artifact-locked chronology sources.
    phase2b_gate = _load_json(
        inputs.results_root / "phase2b" / inputs.phase2b_run_id / "gate_evaluation.json"
    )
    phase2a_scaleup_gate = _load_json(
        inputs.results_root / "phase2a" / inputs.scaleup_phase2a_run_id / "gate_evaluation.json"
    )
    optiona_summary = _load_json(
        inputs.results_root / "feasibility" / inputs.optiona_feas_run_id / "optionA_feasibility_summary.json"
    )
    scaleup_lock_preview = _load_json(
        inputs.results_root / "feasibility" / inputs.scaleup_lock_run_id / "lock_recommendation_preview.json"
    )

    gemma_config = _load_json(inputs.models_root / "gemma-7b" / "config.json")
    llama_config = _load_json(inputs.models_root / "llama-3.1-8b" / "config.json")
    olmo_config = _load_json(inputs.models_root / "olmo-2-7b" / "config.json")

    gemma_head_dim = int(gemma_config.get("head_dim", gemma_config["hidden_size"] // gemma_config["num_attention_heads"]))
    gemma_pairs = gemma_head_dim // 2
    llama_head_dim = int(llama_config.get("head_dim", llama_config["hidden_size"] // llama_config["num_attention_heads"]))
    llama_pairs = llama_head_dim // 2
    olmo_head_dim = int(olmo_config.get("head_dim", olmo_config["hidden_size"] // olmo_config["num_attention_heads"]))
    olmo_pairs = olmo_head_dim // 2

    snapshot = {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "run": {
            "run_tag": inputs.run_tag,
            "exploratory_only": True,
            "mc_method": "holm",
            "co_primary_metrics": ["effect_raw", "effect_over_headroom"],
        },
        "sources": {
            "planned_contrasts": str((inputs.report_dir / "planned_contrasts.parquet").as_posix()),
            "floor_exclusion_summary": str((inputs.report_dir / "floor_exclusion_summary.parquet").as_posix()),
            "mistral_feasibility_summary": str((inputs.manifests_dir / f"{inputs.run_tag}_mistral_feas.summary.json").as_posix()),
            "pair_effects": str((inputs.report_dir / "pair_effects.parquet").as_posix()),
            "phase2b_confirmatory_gate": str(
                (inputs.results_root / "phase2b" / inputs.phase2b_run_id / "gate_evaluation.json").as_posix()
            ),
            "scaleup_phase2a_gate": str(
                (inputs.results_root / "phase2a" / inputs.scaleup_phase2a_run_id / "gate_evaluation.json").as_posix()
            ),
            "optiona_feasibility_summary": str(
                (inputs.results_root / "feasibility" / inputs.optiona_feas_run_id / "optionA_feasibility_summary.json").as_posix()
            ),
            "scaleup_lock_preview": str(
                (inputs.results_root / "feasibility" / inputs.scaleup_lock_run_id / "lock_recommendation_preview.json").as_posix()
            ),
        },
        "outcome_board": {
            "llama": {
                "label": "strong_pair_level_range_selective_signal",
                "evidence": {
                    "retrieval_pair0_vs_pair56": [
                        {
                            "span": int(r["span"]),
                            "effect_raw": _round(r["effect_raw"], 6),
                            "effect_over_headroom": _round(r["effect_over_headroom"], 6),
                            "p_raw_holm": _round(r["p_raw_holm"], 6),
                            "p_headroom_holm": _round(r["p_headroom_holm"], 6),
                        }
                        for r in llama_rows
                    ],
                    "mirror_local_key_match_pair0_vs_pair56": {
                        "effect_raw": _round(llama_mirror["effect_raw"], 6),
                        "effect_over_headroom": _round(llama_mirror["effect_over_headroom"], 6),
                        "p_raw_holm": _round(llama_mirror["p_raw_holm"], 6),
                        "p_headroom_holm": _round(llama_mirror["p_headroom_holm"], 6),
                    },
                    "headroom_trend_monotonic": llama_trend_monotonic_headroom,
                },
            },
            "olmo": {
                "label": "different_non_monotonic_profile_in_this_setup",
                "evidence": {
                    "retrieval_pair0_vs_pair56": [
                        {
                            "span": int(r["span"]),
                            "effect_raw": _round(r["effect_raw"], 6),
                            "effect_over_headroom": _round(r["effect_over_headroom"], 6),
                            "p_raw_holm": _round(r["p_raw_holm"], 6),
                            "p_headroom_holm": _round(r["p_headroom_holm"], 6),
                        }
                        for r in olmo_rows
                    ],
                    "mirror_local_key_match_pair0_vs_pair56": {
                        "effect_raw": _round(olmo_mirror["effect_raw"], 6),
                        "effect_over_headroom": _round(olmo_mirror["effect_over_headroom"], 6),
                        "p_raw_holm": _round(olmo_mirror["p_raw_holm"], 6),
                        "p_headroom_holm": _round(olmo_mirror["p_headroom_holm"], 6),
                    },
                },
            },
            "mistral": {
                "label": "retrieval_nonevaluable_mirror_weak",
                "evidence": {
                    "retrieval_evaluable": bool(feas.get("retrieval_evaluable", False)),
                    "selected_retrieval_spans": [int(x) for x in feas.get("selected_retrieval_spans", [])],
                    "retrieval_feasibility_status": str(feas.get("status", "unknown")),
                    "mirror_local_key_match_pair0_vs_pair56": {
                        "effect_raw": _round(mistral_mirror["effect_raw"], 6),
                        "effect_over_headroom": _round(mistral_mirror["effect_over_headroom"], 6),
                        "p_raw_holm": _round(mistral_mirror["p_raw_holm"], 6),
                        "p_headroom_holm": _round(mistral_mirror["p_headroom_holm"], 6),
                    },
                },
            },
        },
        "floor_evaluability": {
            "rows": floor_rows.to_dict(orient="records"),
            "floor_threshold": _round(float(floor["floor_threshold"].iloc[0]), 6) if len(floor) else None,
        },
        "pair_profiles": {
            "llama_retrieval_span32": _profile("llama-3.1-8b", "long_range_retrieval", 32),
            "llama_retrieval_span48": _profile("llama-3.1-8b", "long_range_retrieval", 48),
            "llama_retrieval_span64": _profile("llama-3.1-8b", "long_range_retrieval", 64),
            "olmo_retrieval_span24": _profile("olmo-2-7b", "long_range_retrieval", 24),
            "olmo_retrieval_span32": _profile("olmo-2-7b", "long_range_retrieval", 32),
            "llama_local_key_match": _profile("llama-3.1-8b", "local_key_match", 0),
            "olmo_local_key_match": _profile("olmo-2-7b", "local_key_match", 0),
            "mistral_local_key_match": _profile("mistral-7b-v0.1", "local_key_match", 0),
        },
        "chronological_results": [
            {
                "window": "2026-03-03 to 2026-03-07",
                "stage": "1B confirmatory campaign",
                "run_id": inputs.phase2b_run_id,
                "h1_effect": _round(phase2b_gate["h1"]["effect"], 6),
                "h1_label": str(phase2b_gate["h1"]["label"]),
                "h2_effect": _round(phase2b_gate["h2"]["effect"], 6),
                "h2_label": str(phase2b_gate["h2"]["label"]),
                "h3_rate_point": _round(phase2b_gate.get("h3_rate_point"), 6),
                "headroom_ratio_long_short": _round(
                    phase2b_gate["task_class_headroom_summary"]["long_short_headroom_ratio"], 6
                ),
                "feas_subset_h1_effect": _round(phase2b_gate["feasibility_conditioned_subset"]["h1"]["effect"], 6),
                "feas_subset_h2_effect": _round(phase2b_gate["feasibility_conditioned_subset"]["h2"]["effect"], 6),
                "feas_subset_h2_headroom_effect": _round(
                    phase2b_gate["feasibility_conditioned_subset"]["headroom_normalized"]["h2_effect"], 6
                ),
            },
            {
                "window": "2026-03-10",
                "stage": "Option A feasibility sweep (1B)",
                "run_id": inputs.optiona_feas_run_id,
                "delayed_copy_max_feasible_offset_any_focus_model": optiona_summary["per_task_any_model_rollup"]["delayed_copy"]["max_feasible_offset_any_focus_model"],
                "retrieval_max_feasible_offset_any_focus_model": optiona_summary["per_task_any_model_rollup"]["long_range_retrieval"]["max_feasible_offset_any_focus_model"],
                "recommendation": optiona_summary["decision"]["recommendation"],
            },
            {
                "window": "2026-03-10 to 2026-03-11",
                "stage": "Scale-up lock/remediation",
                "run_id": inputs.scaleup_lock_run_id,
                "lock_resolution_mode": str(scaleup_lock_preview["lock_resolution_mode"]),
                "selected_long_offsets": [int(x) for x in scaleup_lock_preview["selected_long_offsets"]],
                "strict_selected_long_offsets": [int(x) for x in scaleup_lock_preview["strict_selected_long_offsets"]],
            },
            {
                "window": "2026-03-11",
                "stage": "Scale-up Phase 2A",
                "run_id": inputs.scaleup_phase2a_run_id,
                "h1_effect": _round(phase2a_scaleup_gate["h1"]["effect"], 6),
                "h1_label": str(phase2a_scaleup_gate["h1"]["label"]),
                "h2_effect": _round(phase2a_scaleup_gate["h2"]["effect"], 6),
                "h2_label": str(phase2a_scaleup_gate["h2"]["label"]),
                "span_overlap_offsets": [int(x) for x in phase2a_scaleup_gate["span_overlap_diagnostic"]["overlap_offsets"]],
                "selected_long_offsets": [int(x) for x in phase2a_scaleup_gate["span_overlap_diagnostic"]["selected_long_offsets"]],
            },
            {
                "window": "2026-03-13 to 2026-03-14",
                "stage": "7-seed pair-level program",
                "run_id": inputs.run_tag,
                "llama_label": "strong_pair_level_range_selective_signal",
                "olmo_label": "different_non_monotonic_profile_in_this_setup",
                "mistral_label": "retrieval_nonevaluable_mirror_weak",
            },
        ],
        "final_results_summary_rows": [
            {
                "analysis": "1B confirmatory (3 models)",
                "h1": f"fail ({phase2b_gate['h1']['effect']:+.3f})",
                "h2": f"fail ({phase2b_gate['h2']['effect']:+.3f})",
                "key_finding": "Near-miss H1 with substantial headroom asymmetry and H3 non-pass.",
            },
            {
                "analysis": "1B feasibility subset (llama+olmo; exploratory)",
                "h1": f"pass ({phase2b_gate['feasibility_conditioned_subset']['h1']['effect']:+.3f})",
                "h2": f"fail ({phase2b_gate['feasibility_conditioned_subset']['h2']['effect']:+.3f})",
                "key_finding": "H1 signal appears in capable subset; H2 remains reversed in raw effect.",
            },
            {
                "analysis": "7-8B Phase 2A (overlap lock branch)",
                "h1": f"pass ({phase2a_scaleup_gate['h1']['effect']:+.3f})",
                "h2": f"fail ({phase2a_scaleup_gate['h2']['effect']:+.3f})",
                "key_finding": "H2 reversal persists under overlap-prone long offsets [8,12,16,24,32].",
            },
            {
                "analysis": "Pair-level llama (7-seed)",
                "h1": "pair0_vs_pair56 significant",
                "h2": "pair0_vs_pair56 significant",
                "key_finding": "Monotonic frequency-to-range selectivity appears at pair resolution.",
            },
            {
                "analysis": "Pair-level OLMo (7-seed)",
                "h1": "mirror contrast near-null",
                "h2": "pair0_vs_pair56 near-null",
                "key_finding": "Non-monotonic profile; coarse band averaging obscures pair-level structure.",
            },
            {
                "analysis": "Pair-level Mistral (7-seed)",
                "h1": "mirror weak",
                "h2": "retrieval non-evaluable",
                "key_finding": "Insufficient retrieval feasibility for long-range adjudication in this branch.",
            },
        ],
        "gemma_comparability": {
            "gemma_head_dim": gemma_head_dim,
            "gemma_pairs": gemma_pairs,
            "llama_head_dim": llama_head_dim,
            "llama_pairs": llama_pairs,
            "olmo_head_dim": olmo_head_dim,
            "olmo_pairs": olmo_pairs,
            "percentile_examples": {
                "pair56_in_llama_olmo": _round(56 / max(llama_pairs - 1, 1), 6),
                "pair56_in_gemma": _round(56 / max(gemma_pairs - 1, 1), 6),
                "gemma_pair_at_llama56_percentile": int(round((56 / max(llama_pairs - 1, 1)) * (gemma_pairs - 1))),
            },
            "note": "Raw pair index is not cross-model comparable when pair count differs; use percentile-mapped indices.",
        },
        "claim_boundary": {
            "exploratory_only": True,
            "non_retroactive_to_confirmatory_runs": True,
            "no_mediation_claim_from_h3_style_evidence": True,
            "no_training_run_generalization_claim": True,
        },
    }
    return snapshot


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a consolidated Experiment 2 pair-sweep story snapshot JSON.")
    parser.add_argument("--run-tag", required=True)
    parser.add_argument("--quick-root", default="results/experiment2/quick")
    parser.add_argument("--report-subdir", default="reports/pair_expanded")
    parser.add_argument("--manifests-subdir", default="manifests")
    parser.add_argument("--output", default="story_snapshot.json")
    parser.add_argument("--results-root", default="results/experiment2")
    parser.add_argument("--models-root", default="models")
    parser.add_argument("--phase2b-run-id", default="exp2_phase2b_fastq_v8_20260307_170106")
    parser.add_argument("--optiona-feas-run-id", default="exp2_feas_optA_20260310_204817")
    parser.add_argument("--scaleup-lock-run-id", default="exp2_feas_scaleup_scaleup78b_remed_20260311_092924")
    parser.add_argument("--scaleup-phase2a-run-id", default="exp2_scaleup78b_p2a_scaleup78b_p2aeff_20260311_154844")
    args = parser.parse_args()

    run_root = Path(args.quick_root) / args.run_tag
    report_dir = run_root / args.report_subdir
    manifests_dir = run_root / args.manifests_subdir
    output = report_dir / args.output

    snapshot = build_story_snapshot(
        StoryInputs(
            run_tag=args.run_tag,
            report_dir=report_dir,
            manifests_dir=manifests_dir,
            results_root=Path(args.results_root),
            models_root=Path(args.models_root),
            phase2b_run_id=args.phase2b_run_id,
            optiona_feas_run_id=args.optiona_feas_run_id,
            scaleup_lock_run_id=args.scaleup_lock_run_id,
            scaleup_phase2a_run_id=args.scaleup_phase2a_run_id,
        )
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(snapshot, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": "ok", "output": str(output), "run_tag": args.run_tag}, indent=2))


if __name__ == "__main__":
    main()
