#!/usr/bin/env bash
set -euo pipefail

cd "/scratch2/anon/Kernel PE"
export CUDA_VISIBLE_DEVICES=0
export PYTHONUNBUFFERED=1

LOG_DIR="logs/trackb"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/trackb_sharedmean_resume_gpu0.log"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] GPU0 shared-mean resume start"

PY=".venv/bin/python"
COMMON_ARGS=(
  experiment1/run.py track-b
  --device cuda
  --track-b-centering-mode shared_mean
  --track-b-output-group track_b_shared_mean_v1
  --track-b-artifact-level compact
)

# Missing from prior run: tinyllama-nope synthetic
"$PY" "${COMMON_ARGS[@]}" --model tinyllama-nope-1.1b --dataset synthetic_random --seq-len all

# Entire model grid still missing in this output group
"$PY" "${COMMON_ARGS[@]}" --model gpt2-small --dataset all --seq-len all
"$PY" "${COMMON_ARGS[@]}" --model olmo-1b --dataset all --seq-len all

echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] GPU0 shared-mean resume complete"
