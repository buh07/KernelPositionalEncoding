#!/usr/bin/env bash
set -euo pipefail

cd "/scratch2/anon/Kernel PE"
export CUDA_VISIBLE_DEVICES=2
export PYTHONUNBUFFERED=1

LOG_DIR="logs/trackb"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/trackb_bucketed_g2.log"
exec > >(tee -a "$LOG_FILE") 2>&1

PY=".venv/bin/python"
COMMON_ARGS=(
  experiment1/run.py track-b
  --dataset all
  --seq-len all
  --device cuda
  --track-b-centering-mode bucketed_mean
  --track-b-bucket-size 32
  --track-b-output-group track_b_bucketed_mean_v1
  --track-b-artifact-level compact
)

"$PY" "${COMMON_ARGS[@]}" --model tinyllama-nope-1.1b
"$PY" "${COMMON_ARGS[@]}" --model llama-3.2-1b
"$PY" "${COMMON_ARGS[@]}" --model gpt2-small

echo "GPU2 bucketed Track B batch complete."
