#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path


def _parse_int_list(raw: str) -> list[int]:
    out: list[int] = []
    seen: set[int] = set()
    for part in str(raw).split(','):
        tok = part.strip()
        if not tok:
            continue
        v = int(tok)
        if v not in seen:
            out.append(v)
            seen.add(v)
    if not out:
        raise SystemExit('expected non-empty integer list')
    return out


def _parse_family_spec(raw: str) -> list[tuple[str, str, list[int] | None]]:
    """
    Format: model:task[:span1|span2], comma-separated
    Example:
      llama-3.1-8b:long_range_retrieval:32|48|64,olmo-2-7b:local_key_match
    """
    fams: list[tuple[str, str, list[int] | None]] = []
    for part in str(raw).split(','):
        piece = part.strip()
        if not piece:
            continue
        bits = piece.split(':')
        if len(bits) < 2:
            raise SystemExit(f'invalid family spec: {piece}')
        model = bits[0].strip()
        task = bits[1].strip()
        spans: list[int] | None = None
        if len(bits) >= 3 and bits[2].strip():
            spans = []
            for span_tok in bits[2].split('|'):
                span_tok = span_tok.strip()
                if not span_tok:
                    continue
                spans.append(int(span_tok))
            if not spans:
                spans = None
        fams.append((model, task, spans))
    if not fams:
        raise SystemExit('no families parsed from --families')
    return fams


def _intervention_conditions() -> list[tuple[str, int | None]]:
    rows: list[tuple[str, int | None]] = [
        ('none', None),
        ('ablate_high_strong', None),
        ('ablate_low_strong', None),
    ]
    rows.extend(('random_strong', draw) for draw in (0, 1, 2))
    for pct in (25, 50, 75):
        rows.append((f'attenuate_high_{pct}', None))
        rows.append((f'attenuate_low_{pct}', None))
        rows.extend((f'attenuate_random_{pct}', draw) for draw in (0, 1, 2))
    return rows


def build_rows(*, run_id: str, phase: str, seq_len: int, seeds: list[int], families: list[tuple[str, str, list[int] | None]]) -> list[dict[str, object]]:
    conditions = _intervention_conditions()
    out: list[dict[str, object]] = []

    # Keep families ordered as provided so model grouping can be controlled by caller.
    for model, task, spans in families:
        span_vals: list[int | None] = [None] if not spans else [int(s) for s in spans]
        for span in span_vals:
            for seed in seeds:
                for intervention, draw in conditions:
                    out.append(
                        {
                            'phase': phase,
                            'split': 'synthetic',
                            'model': model,
                            'task': task,
                            'seq_len': int(seq_len),
                            'intervention': intervention,
                            'seed': int(seed),
                            'span': span,
                            'random_draw': draw,
                            'device': 'cuda',
                            'run_id': run_id,
                            'notes': 'optiond_continuous_attenuation_crossmodel',
                        }
                    )
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description='Build cross-model Option D manifest (legacy strong + attenuation block).')
    ap.add_argument('--output-manifest', required=True)
    ap.add_argument('--summary-json', required=True)
    ap.add_argument('--run-id', required=True)
    ap.add_argument('--phase', default='phase2b')
    ap.add_argument('--seq-len', type=int, default=1024)
    ap.add_argument('--seeds', default='0,1,2')
    ap.add_argument(
        '--families',
        default=(
            'llama-3.1-8b:long_range_retrieval:32|48|64,'
            'llama-3.1-8b:local_key_match,'
            'olmo-2-7b:long_range_retrieval:24|32,'
            'olmo-2-7b:local_key_match,'
            'mistral-7b-v0.1:long_range_retrieval:24|32,'
            'mistral-7b-v0.1:local_key_match'
        ),
    )
    args = ap.parse_args()

    seeds = _parse_int_list(args.seeds)
    families = _parse_family_spec(args.families)
    rows = build_rows(
        run_id=str(args.run_id),
        phase=str(args.phase),
        seq_len=int(args.seq_len),
        seeds=seeds,
        families=families,
    )

    manifest_path = Path(args.output_manifest)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with manifest_path.open('w', encoding='utf-8') as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + '\n')

    model_counts = Counter(str(r['model']) for r in rows)
    task_counts = Counter(str(r['task']) for r in rows)
    intervention_counts = Counter(str(r['intervention']) for r in rows)
    family_payload: list[dict[str, object]] = []
    family_units = 0
    for model, task, spans in families:
        n_spans = len(spans) if spans else 1
        family_units += n_spans
        family_payload.append({'model': model, 'task': task, 'spans': (spans or [])})

    expected = family_units * len(seeds) * 21
    if len(rows) != expected:
        raise RuntimeError(f'unexpected row count got={len(rows)} expected={expected}')

    payload = {
        'run_id': str(args.run_id),
        'phase': str(args.phase),
        'seq_len': int(args.seq_len),
        'seeds': seeds,
        'families': family_payload,
        'family_units': int(family_units),
        'total_rows': int(len(rows)),
        'expected_rows': int(expected),
        'model_counts': dict(sorted(model_counts.items())),
        'task_counts': dict(sorted(task_counts.items())),
        'intervention_counts': dict(sorted(intervention_counts.items())),
        'optiond_policy': 'continuous_attenuation_parallel_block_v1',
        'attenuation_levels': [25, 50, 75],
        'attenuation_primary_level': 75,
        'legacy_ablation_block_unchanged': True,
    }
    summary_path = Path(args.summary_json)
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
