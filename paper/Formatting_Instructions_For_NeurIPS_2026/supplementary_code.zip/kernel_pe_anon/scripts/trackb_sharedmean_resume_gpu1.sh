#!/usr/bin/env bash
set -euo pipefail

cd "/scratch2/anon/Kernel PE"
export CUDA_VISIBLE_DEVICES=1
export PYTHONUNBUFFERED=1

LOG_DIR="logs/trackb"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/trackb_sharedmean_resume_gpu1.log"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] GPU1 shared-mean resume start"

PY=".venv/bin/python"
COMMON_ARGS=(
  experiment1/run.py track-b
  --device cuda
  --track-b-centering-mode shared_mean
  --track-b-output-group track_b_shared_mean_v1
  --track-b-artifact-level compact
)

# Missing from prior run: final synthetic 1024 combos for RoPE models
"$PY" "${COMMON_ARGS[@]}" --model tinyllama-1.1b --dataset synthetic_random --seq-len 1024
"$PY" "${COMMON_ARGS[@]}" --model llama-3.2-1b --dataset synthetic_random --seq-len 1024

# Entire model grid still missing in this output group
"$PY" "${COMMON_ARGS[@]}" --model gpt2-medium --dataset all --seq-len all

echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] GPU1 shared-mean resume complete"
