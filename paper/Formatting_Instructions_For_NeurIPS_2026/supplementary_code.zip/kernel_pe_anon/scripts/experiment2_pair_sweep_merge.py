#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd


def _load_parquet_if_exists(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_parquet(path)


def _coerce_source_runs(inputs: list[str], source_runs_arg: str | None) -> list[str]:
    if source_runs_arg is None or not source_runs_arg.strip():
        return inputs
    source_runs = [tok.strip() for tok in source_runs_arg.split(",") if tok.strip()]
    if len(source_runs) != len(inputs):
        raise RuntimeError(
            f"--source-runs count ({len(source_runs)}) must match --inputs count ({len(inputs)})."
        )
    return source_runs


def main() -> None:
    ap = argparse.ArgumentParser(description="Merge pair-sweep report directories into a unified exploratory package.")
    ap.add_argument("--inputs", type=str, required=True, help="Comma-separated report directories.")
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--source-runs", type=str, default="", help="Optional comma-separated source run IDs/tags.")
    ap.add_argument("--mc-method", type=str, default="holm")
    args = ap.parse_args()

    input_dirs = [Path(tok.strip()) for tok in args.inputs.split(",") if tok.strip()]
    if not input_dirs:
        raise RuntimeError("--inputs must include at least one report directory.")
    source_runs = _coerce_source_runs([str(p) for p in input_dirs], args.source_runs)

    merged_pairs: list[pd.DataFrame] = []
    merged_floor: list[pd.DataFrame] = []
    sources_meta: list[dict[str, Any]] = []

    for idx, report_dir in enumerate(input_dirs):
        pair_path = report_dir / "pair_effects.parquet"
        floor_path = report_dir / "floor_exclusion_summary.parquet"
        summary_path = report_dir / "summary.json"

        pair_df = _load_parquet_if_exists(pair_path)
        floor_df = _load_parquet_if_exists(floor_path)
        summary_payload: dict[str, Any] = {}
        if summary_path.exists():
            summary_payload = json.loads(summary_path.read_text(encoding="utf-8"))

        source_run = source_runs[idx]
        if not pair_df.empty:
            pair_df = pair_df.copy()
            pair_df["source_run"] = source_run
            pair_df["source_report_dir"] = str(report_dir)
            pair_df["exploratory_only"] = True
            pair_df["mc_method"] = str(args.mc_method)
            pair_df["family_key"] = (
                pair_df["model"].astype(str)
                + "|"
                + pair_df["task"].astype(str)
                + "|span="
                + pair_df["span"].astype(int).astype(str)
            )
            merged_pairs.append(pair_df)

        if not floor_df.empty:
            floor_df = floor_df.copy()
            floor_df["source_run"] = source_run
            floor_df["source_report_dir"] = str(report_dir)
            floor_df["exploratory_only"] = True
            floor_df["family_key"] = (
                floor_df["model"].astype(str)
                + "|"
                + floor_df["task"].astype(str)
                + "|span="
                + floor_df["span"].astype(int).astype(str)
            )
            merged_floor.append(floor_df)

        sources_meta.append(
            {
                "source_run": source_run,
                "source_report_dir": str(report_dir),
                "pair_effects_exists": pair_path.exists(),
                "floor_exclusion_exists": floor_path.exists(),
                "summary_exists": summary_path.exists(),
                "summary": summary_payload,
            }
        )

    out_dir = args.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    if merged_pairs:
        pair_out = pd.concat(merged_pairs, ignore_index=True)
        pair_out.to_parquet(out_dir / "pair_effects_merged.parquet", engine="pyarrow", index=False)
    else:
        pair_out = pd.DataFrame()
        pair_out.to_parquet(out_dir / "pair_effects_merged.parquet", engine="pyarrow", index=False)

    if merged_floor:
        floor_out = pd.concat(merged_floor, ignore_index=True)
        floor_out.to_parquet(out_dir / "floor_exclusion_summary_merged.parquet", engine="pyarrow", index=False)
    else:
        floor_out = pd.DataFrame()
        floor_out.to_parquet(out_dir / "floor_exclusion_summary_merged.parquet", engine="pyarrow", index=False)

    summary = {
        "generated_at": pd.Timestamp.now("UTC").isoformat(),
        "exploratory_only": True,
        "mc_method": str(args.mc_method),
        "sources": sources_meta,
        "rows": {
            "pair_effects_merged": int(pair_out.shape[0]),
            "floor_exclusion_merged": int(floor_out.shape[0]),
            "unique_families": int(pair_out["family_key"].nunique()) if "family_key" in pair_out.columns else 0,
        },
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    memo_lines = [
        "# Unified Pair-Profile Package",
        "",
        "Policy: exploratory-only (non-retroactive to confirmatory adjudication).",
        f"Multiple-comparison method: {args.mc_method}.",
        "",
        "## Sources",
    ]
    for src in sources_meta:
        memo_lines.append(
            f"- `{src['source_run']}` from `{src['source_report_dir']}` "
            f"(pair_effects={src['pair_effects_exists']}, floor_summary={src['floor_exclusion_exists']})"
        )
    memo_lines.append("")
    memo_lines.append("## Output")
    memo_lines.append(f"- pair effects merged rows: {int(pair_out.shape[0])}")
    memo_lines.append(f"- floor summary merged rows: {int(floor_out.shape[0])}")
    memo_lines.append("- includes source provenance and family-level metadata per row")
    (out_dir / "decision_memo.md").write_text("\n".join(memo_lines) + "\n", encoding="utf-8")

    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
