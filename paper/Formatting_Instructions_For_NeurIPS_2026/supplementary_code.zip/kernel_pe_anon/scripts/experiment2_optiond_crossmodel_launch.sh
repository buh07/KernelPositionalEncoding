#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

RUN_TAG="${1:-optiond_crossmodel_$(date +%Y%m%d_%H%M%S)}"
GPU_ID="${GPU_ID:-2}"
RUN_ID="${RUN_TAG}_phase2b"
OUTPUT_ROOT="results/experiment2/quick/${RUN_TAG}"
LOG_ROOT="logs/experiment2/quick/${RUN_TAG}"
MANIFEST_DIR="${OUTPUT_ROOT}/manifests"

MANIFEST_PATH="${MANIFEST_DIR}/${RUN_ID}.jsonl"
SUMMARY_PATH="${MANIFEST_DIR}/${RUN_ID}.summary.json"

mkdir -p "${LOG_ROOT}" "${MANIFEST_DIR}"

for sess in exp2_optd_xmodel_g${GPU_ID} exp2_optd_xmodel_report; do
  tmux kill-session -t "${sess}" 2>/dev/null || true
done

echo "[optiond-xmodel] building manifest run_id=${RUN_ID}" | tee "${LOG_ROOT}/launch.log"
.venv/bin/python scripts/experiment2_optiond_crossmodel_build_manifest.py \
  --output-manifest "${MANIFEST_PATH}" \
  --summary-json "${SUMMARY_PATH}" \
  --run-id "${RUN_ID}" \
  --phase phase2b \
  --seq-len 1024 \
  --seeds 0,1,2 | tee -a "${LOG_ROOT}/launch.log"

ROW_COUNT="$(( $(wc -l < "${MANIFEST_PATH}") ))"
if [[ "${ROW_COUNT}" -le 0 ]]; then
  echo "[optiond-xmodel] manifest has zero rows; aborting." >&2
  exit 1
fi

echo "[optiond-xmodel] launching execute on GPU ${GPU_ID}" | tee -a "${LOG_ROOT}/launch.log"
tmux new-session -d -s "exp2_optd_xmodel_g${GPU_ID}" \
  "cd '${ROOT_DIR}' && CUDA_VISIBLE_DEVICES=${GPU_ID} .venv/bin/python experiment2/run.py --mode execute --manifest '${MANIFEST_PATH}' --output-root '${OUTPUT_ROOT}' --device cuda:0 --kernel-engine optimized --centered-compute defer --synthetic-eval-mode restricted --candidate-size 10 --h12-endpoint-policy co_primary_raw_headroom --track-a-enabled false --intervention-profile full --synthetic-count 100 --batch-size-synth 12 --feasibility-task-only --print-summary |& tee '${LOG_ROOT}/exp2_optd_xmodel_g${GPU_ID}.log'"

echo "[optiond-xmodel] launching reanalyze watcher" | tee -a "${LOG_ROOT}/launch.log"
tmux new-session -d -s exp2_optd_xmodel_report \
  "cd '${ROOT_DIR}' && while tmux has-session -t exp2_optd_xmodel_g${GPU_ID} 2>/dev/null; do sleep 30; done && .venv/bin/python experiment2/run.py --mode reanalyze --phase phase2b --run-id '${RUN_ID}' --output-root '${OUTPUT_ROOT}' --print-summary |& tee '${LOG_ROOT}/exp2_optd_xmodel_reanalyze.log'"

cat <<EOF
[optiond-xmodel] launched
  run_tag: ${RUN_TAG}
  run_id: ${RUN_ID}
  manifest_rows: ${ROW_COUNT}
  sessions:
    - exp2_optd_xmodel_g${GPU_ID}
    - exp2_optd_xmodel_report
  logs: ${LOG_ROOT}
EOF
