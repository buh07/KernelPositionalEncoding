#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

RUN_TAG="${1:-quick_pair_7seed_mistral_$(date +%Y%m%d_%H%M%S)}"
GPU_LIST="${GPU_LIST:-0 1}"
OUTPUT_ROOT="results/experiment2/quick/${RUN_TAG}"
LOG_ROOT="logs/experiment2/quick/${RUN_TAG}"
MANIFEST_DIR="${OUTPUT_ROOT}/manifests"
REPORT_DIR="${OUTPUT_ROOT}/reports/pair_expanded"

BASE_RUN_ID="${RUN_TAG}_base"
MISTRAL_FEAS_RUN_ID="${RUN_TAG}_mistral_feas"
PAIR_RUN_ID="${RUN_TAG}_pair7"

mkdir -p "${LOG_ROOT}" "${MANIFEST_DIR}" "${REPORT_DIR}"

read -r -a GPUS <<< "${GPU_LIST//,/ }"
if (( ${#GPUS[@]} < 1 )); then
  echo "This launcher expects at least 1 GPU (received: ${GPU_LIST})." >&2
  exit 1
fi
G0="${GPUS[0]}"

PAIR_INDICES="0,8,16,24,32,40,48,56"

BASE_MANIFEST="${OUTPUT_ROOT}/phase2b/${BASE_RUN_ID}/manifest.jsonl"
MISTRAL_FEAS_MANIFEST="${MANIFEST_DIR}/${MISTRAL_FEAS_RUN_ID}.jsonl"
PAIR_MANIFEST="${MANIFEST_DIR}/${PAIR_RUN_ID}.jsonl"
MISTRAL_FEAS_JSON="${MANIFEST_DIR}/${MISTRAL_FEAS_RUN_ID}.summary.json"
FAMILIES_JSON="${MANIFEST_DIR}/${PAIR_RUN_ID}.families.json"

for g in "${GPUS[@]}"; do
  tmux kill-session -t "exp2_p7_g${g}" 2>/dev/null || true
done
for sess in exp2_p7_report; do
  tmux kill-session -t "${sess}" 2>/dev/null || true
done

if ! find "models/mistral-7b-v0.1" -maxdepth 1 \( -name "*.safetensors" -o -name "*.bin" \) | grep -q . ; then
  echo "[preflight] Mistral weights missing. Downloading mistral-7b-v0.1 ..."
  .venv/bin/python scripts/download_assets.py \
    --models-only \
    --model-profile scaleup_78b_mistral \
    --names mistral-7b-v0.1 |& tee "${LOG_ROOT}/preflight_download_mistral.log"
fi

echo "[preflight] Adapter smoke: mistral-7b-v0.1 on cuda:${G0}"
CUDA_VISIBLE_DEVICES="${G0}" \
  .venv/bin/python scripts/experiment2_adapter_smoke.py \
  --model-profile scaleup_78b_mistral \
  --models mistral-7b-v0.1 \
  --device cuda:0 \
  --include-logits |& tee "${LOG_ROOT}/preflight_adapter_smoke.log"

echo "[preflight] Restricted-candidate vocab sanity: mistral-7b-v0.1"
.venv/bin/python scripts/experiment2_restricted_vocab_sanity.py \
  --model mistral-7b-v0.1 \
  --seq-len 1024 \
  --seed 0 \
  --count 2 \
  --candidate-size 10 |& tee "${LOG_ROOT}/preflight_vocab_sanity.log"

echo "[build] Base manifest for pair templates"
.venv/bin/python experiment2/run.py \
  --mode build \
  --phase phase2b \
  --run-id "${BASE_RUN_ID}" \
  --device cuda \
  --output-root "${OUTPUT_ROOT}" \
  --model-profile scaleup_78b_mistral \
  --phase2b-core-synthetic-only \
  --intervention-profile strong_only \
  --random-draws-confirmatory 3 \
  --print-summary |& tee "${LOG_ROOT}/build.log"

echo "[feasibility] Building Mistral retrieval-only feasibility manifest"
.venv/bin/python scripts/experiment2_quick_manifest_build.py \
  --input-manifest "${BASE_MANIFEST}" \
  --output-manifest "${MISTRAL_FEAS_MANIFEST}" \
  --summary-json "${MANIFEST_DIR}/${MISTRAL_FEAS_RUN_ID}.manifest_summary.json" \
  --run-id "${MISTRAL_FEAS_RUN_ID}" \
  --phase quick_mistral_feasibility \
  --split synthetic \
  --model mistral-7b-v0.1 \
  --task long_range_retrieval \
  --seq-len 1024 \
  --seeds 0,1,2 \
  --force-spans 24,32,48,64 \
  --source-interventions none \
  --expand-interventions none \
  --random-draws 1 \
  --notes-tag quick_mistral_retrieval_feasibility |& tee "${LOG_ROOT}/mistral_feas_manifest.log"

echo "[feasibility] Executing Mistral retrieval feasibility rows"
CUDA_VISIBLE_DEVICES="${G0}" \
  .venv/bin/python experiment2/run.py \
  --mode execute \
  --manifest "${MISTRAL_FEAS_MANIFEST}" \
  --output-root "${OUTPUT_ROOT}" \
  --device cuda:0 \
  --kernel-engine optimized \
  --centered-compute defer \
  --synthetic-eval-mode restricted \
  --candidate-size 10 \
  --h12-endpoint-policy co_primary_raw_headroom \
  --track-a-enabled false \
  --intervention-profile full \
  --synthetic-count 100 \
  --batch-size-synth 12 \
  --feasibility-task-only \
  --seed-start 0 \
  --seed-end 2 \
  --print-summary |& tee "${LOG_ROOT}/mistral_feas_execute.log"

echo "[feasibility] Finalizing Mistral retrieval feasibility summary"
.venv/bin/python scripts/experiment2_mistral_feasibility_finalize.py \
  --aggregate-task-metrics "${OUTPUT_ROOT}/quick_mistral_feasibility/${MISTRAL_FEAS_RUN_ID}/aggregate_task_metrics.parquet" \
  --output-json "${MISTRAL_FEAS_JSON}" \
  --model mistral-7b-v0.1 \
  --task long_range_retrieval \
  --spans 24,32,48,64 \
  --seeds 0,1,2 \
  --floor-threshold 0.15 \
  --min-pass-rate 0.6666666666666666 |& tee "${LOG_ROOT}/mistral_feas_finalize.log"

MISTRAL_SPANS_CSV="$(
  .venv/bin/python - <<PY
import json
from pathlib import Path
p = Path("${MISTRAL_FEAS_JSON}")
payload = json.loads(p.read_text(encoding="utf-8"))
vals = [int(x) for x in payload.get("selected_retrieval_spans", [])]
print(",".join(str(v) for v in vals))
PY
)"

MISTRAL_RETRIEVAL_EVAL="$(
  .venv/bin/python - <<PY
import json
from pathlib import Path
p = Path("${MISTRAL_FEAS_JSON}")
payload = json.loads(p.read_text(encoding="utf-8"))
print("true" if bool(payload.get("retrieval_evaluable", False)) else "false")
PY
)"

echo "[feasibility] selected_mistral_spans=${MISTRAL_SPANS_CSV:-<none>} retrieval_evaluable=${MISTRAL_RETRIEVAL_EVAL}"

echo "[build] Creating pair-sweep family matrix"
.venv/bin/python - <<PY
import json
from pathlib import Path
out = Path("${FAMILIES_JSON}")
families = [
  {"model": "llama-3.1-8b", "task": "long_range_retrieval", "spans": [32, 48, 64]},
  {"model": "olmo-2-7b", "task": "long_range_retrieval", "spans": [24, 32]},
  {"model": "llama-3.1-8b", "task": "local_key_match"},
  {"model": "olmo-2-7b", "task": "local_key_match"},
  {"model": "mistral-7b-v0.1", "task": "local_key_match"},
]
if "${MISTRAL_RETRIEVAL_EVAL}" == "true":
    spans = [int(x) for x in "${MISTRAL_SPANS_CSV}".split(",") if str(x).strip()]
    if len(spans) >= 2:
        families.insert(2, {"model": "mistral-7b-v0.1", "task": "long_range_retrieval", "spans": spans})
out.write_text(json.dumps(families, indent=2) + "\\n", encoding="utf-8")
print(json.dumps({"families": families}, indent=2))
PY

echo "[build] Building pair-sweep manifest"
.venv/bin/python scripts/experiment2_pair_sweep_manifest.py \
  --input-manifest "${BASE_MANIFEST}" \
  --output-manifest "${PAIR_MANIFEST}" \
  --summary-json "${MANIFEST_DIR}/${PAIR_RUN_ID}.summary.json" \
  --run-id "${PAIR_RUN_ID}" \
  --phase quick_pair_7seed_mistral \
  --seeds 0,1,2,3,4,5,6 \
  --pair-indices "${PAIR_INDICES}" \
  --random-draws 3 \
  --families-json "${FAMILIES_JSON}" \
  --source-intervention none \
  --notes-tag quick_pair_7seed_loma_mistral |& tee "${LOG_ROOT}/pair_manifest.log"

echo "[execute] Launching pair workers on GPUs ${GPU_LIST}"
SEEDS=(0 1 2 3 4 5 6)
NUM_GPUS=${#GPUS[@]}
NUM_SEEDS=${#SEEDS[@]}
for idx in "${!GPUS[@]}"; do
  g="${GPUS[$idx]}"
  start_idx=$(( idx * NUM_SEEDS / NUM_GPUS ))
  end_idx=$(( (idx + 1) * NUM_SEEDS / NUM_GPUS - 1 ))
  if (( start_idx > end_idx )); then
    continue
  fi
  seed_start="${SEEDS[$start_idx]}"
  seed_end="${SEEDS[$end_idx]}"
  echo "[execute] gpu=${g} seed-range ${seed_start}-${seed_end}"
  tmux new-session -d -s "exp2_p7_g${g}" \
    "cd '${ROOT_DIR}' && CUDA_VISIBLE_DEVICES=${g} .venv/bin/python experiment2/run.py --mode execute --manifest '${PAIR_MANIFEST}' --output-root '${OUTPUT_ROOT}' --device cuda:0 --kernel-engine optimized --centered-compute defer --synthetic-eval-mode restricted --candidate-size 10 --h12-endpoint-policy co_primary_raw_headroom --track-a-enabled false --intervention-profile full --synthetic-count 100 --batch-size-synth 24 --feasibility-task-only --seed-start ${seed_start} --seed-end ${seed_end} --print-summary |& tee '${LOG_ROOT}/exp2_p7_g${g}.log'"
done

wait_clause=""
for g in "${GPUS[@]}"; do
  if [[ -n "${wait_clause}" ]]; then
    wait_clause+=" || "
  fi
  wait_clause+="tmux has-session -t exp2_p7_g${g} 2>/dev/null"
done

tmux new-session -d -s exp2_p7_report \
  "cd '${ROOT_DIR}' && while ${wait_clause}; do sleep 30; done && \
   .venv/bin/python scripts/experiment2_pair_sweep_report.py --aggregate-task-metrics '${OUTPUT_ROOT}/quick_pair_7seed_mistral/${PAIR_RUN_ID}/aggregate_task_metrics.parquet' --output-dir '${REPORT_DIR}' --families-json '${FAMILIES_JSON}' --pair-indices '${PAIR_INDICES}' --floor-threshold 0.15 |& tee '${LOG_ROOT}/exp2_p7_report.log' && \
   .venv/bin/python scripts/experiment2_pair_story_snapshot.py --run-tag '${RUN_TAG}' --quick-root results/experiment2/quick |& tee '${LOG_ROOT}/exp2_p7_story_snapshot.log' && \
   .venv/bin/python scripts/experiment2_pair_story_figures.py --run-tag '${RUN_TAG}' --quick-root results/experiment2/quick |& tee '${LOG_ROOT}/exp2_p7_story_figures.log' && \
   .venv/bin/python scripts/experiment2_pair_story_validate.py --story '${REPORT_DIR}/story_snapshot.json' --overview experiment2/experiment2overview.md --presentation experiment2/experiment2presentation.html |& tee '${LOG_ROOT}/exp2_p7_story_validate.log'"

cat <<EOF
[pair-7seed-mistral] launched on GPUs ${GPU_LIST}
  tmux sessions:
EOF
for g in "${GPUS[@]}"; do
cat <<EOF
    - exp2_p7_g${g}
EOF
done
cat <<EOF
    - exp2_p7_report
  run tag: ${RUN_TAG}
  families json: ${FAMILIES_JSON}
  mistral feasibility summary: ${MISTRAL_FEAS_JSON}
  report dir: ${REPORT_DIR}
EOF
