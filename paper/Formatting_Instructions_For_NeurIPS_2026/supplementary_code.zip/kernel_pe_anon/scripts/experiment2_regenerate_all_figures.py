#!/usr/bin/env python3
"""Regenerate all Experiment 2 figures with improved clarity, sizing, and captions."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd


OUT_DIR = Path("experiment2/figures")

# ── Data paths ──────────────────────────────────────────────────────────────
PAIR_STORY = Path("results/experiment2/quick/quick_pair_7seed_mistral_20260315_0205/reports/pair_expanded/story_snapshot.json")
PAIR_CONTRASTS = Path("results/experiment2/quick/quick_pair_7seed_mistral_20260315_0205/reports/pair_expanded/planned_contrasts.parquet")
MISTRAL_FEAS = Path("results/experiment2/quick/quick_pair_7seed_mistral_20260315_0205/manifests/quick_pair_7seed_mistral_20260315_0205_mistral_feas.summary.json")

FC_ROOT = Path("results/experiment2/quick/fastchecks_additive_20260314_203629/checks/reports")
FC_DIFF_PARQUET = FC_ROOT / "difficulty_decomp_summary.parquet"
FC_HEADROOM_PARQUET = FC_ROOT / "headroom_audit_by_span.parquet"
FC_NATURAL_JSON = FC_ROOT / "natural_bridge_summary.json"
FC_TOKEN_PARQUET = FC_ROOT / "tokenizer_sensitivity.parquet"

OPTIOND_PILOT = Path("results/experiment2/quick/optiond_kickoff_20260314_232424/phase2b/optiond_kickoff_20260314_232424_phase2b/gate_evaluation.json")
OPTIOND_CROSS = Path("results/experiment2/quick/optiond_crossmodel_20260315_012525/phase2b/optiond_crossmodel_20260315_012525_phase2b/gate_evaluation.json")


def _theme() -> None:
    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update({
        "figure.dpi": 120,
        "savefig.dpi": 180,
        "font.size": 11,
        "axes.titlesize": 13,
        "axes.titleweight": "bold",
        "axes.labelsize": 11,
        "legend.fontsize": 9.5,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.facecolor": "white",
        "axes.facecolor": "#fafafa",
        "grid.alpha": 0.4,
    })


def _save(fig: plt.Figure, name: str) -> None:
    path = OUT_DIR / name
    fig.savefig(path, bbox_inches="tight", pad_inches=0.15)
    plt.close(fig)
    print(f"  -> {path}")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 1 — Llama retrieval: pair0 vs pair56 trend across span
# ═══════════════════════════════════════════════════════════════════════════
def fig1_llama_trend(story: dict) -> None:
    rows = story["outcome_board"]["llama"]["evidence"]["retrieval_pair0_vs_pair56"]
    spans = [int(r["span"]) for r in rows]
    eff_raw = [float(r["effect_raw"]) for r in rows]
    eff_head = [float(r["effect_over_headroom"]) for r in rows]

    fig, ax = plt.subplots(figsize=(7, 4.2))
    ax.plot(spans, eff_raw, "o-", lw=2.2, color="#2563eb", ms=8, label="Raw effect (accuracy delta)", zorder=5)
    ax.plot(spans, eff_head, "s-", lw=2.2, color="#dc2626", ms=8, label="Headroom-normalized effect", zorder=5)
    ax.axhline(0.0, color="#999", lw=0.8, ls="--", zorder=1)
    ax.fill_between(spans, 0, eff_raw, alpha=0.08, color="#2563eb")
    ax.fill_between(spans, 0, eff_head, alpha=0.08, color="#dc2626")

    ax.set_xlabel("Retrieval span (tokens)")
    ax.set_ylabel("Effect size (pair 0 drop minus pair 56 drop)")
    ax.set_title("Llama 8B: Pair 0 vs Pair 56 Contrast Across Span")
    ax.set_xticks(spans)
    ax.legend(loc="center left", framealpha=0.9)

    for s, r, h in zip(spans, eff_raw, eff_head):
        ax.annotate(f"{r:+.3f}", (s, r), textcoords="offset points", xytext=(0, 10), fontsize=8.5, ha="center", color="#2563eb")
        ax.annotate(f"{h:+.3f}", (s, h), textcoords="offset points", xytext=(0, -14), fontsize=8.5, ha="center", color="#dc2626")

    ax.text(0.01, 0.01, "All contrasts p_holm = 0.031; exploratory only", transform=ax.transAxes, fontsize=8, color="#888")
    fig.tight_layout()
    _save(fig, "fig1_llama_retrieval_pair0_vs_pair56_trend.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 2 — Cross-model planned contrast heatmap
# ═══════════════════════════════════════════════════════════════════════════
def fig2_heatmap(planned: pd.DataFrame) -> None:
    df = planned.copy()
    # Build clean family labels
    df["family"] = df.apply(
        lambda r: f"{r['model']}\n{r['task']}  (span {int(r['span'])})", axis=1
    )
    pivot = df.pivot(index="family", columns="contrast_name", values="effect_over_headroom")
    order_cols = ["pair0_vs_pair56", "low_third_vs_high_third"]
    pivot = pivot.reindex(columns=[c for c in order_cols if c in pivot.columns])

    # Build significance overlay
    sig_df = df.pivot(index="family", columns="contrast_name", values="p_headroom_holm")
    sig_df = sig_df.reindex(columns=pivot.columns)

    vals = pivot.values
    vmax = max(float(np.nanmax(np.abs(vals))), 0.1)

    nrows = len(pivot.index)
    fig, ax = plt.subplots(figsize=(7.5, max(4.5, 0.48 * nrows + 1.2)))
    im = ax.imshow(vals, cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="auto")

    ax.set_title("Planned-Contrast Heatmap (Headroom-Normalized)")
    ax.set_xticks(np.arange(len(pivot.columns)))
    ax.set_xticklabels(["pair 0 vs pair 56\n(primary)", "low-third vs high-third\n(secondary)"], fontsize=10)
    ax.set_yticks(np.arange(nrows))
    ax.set_yticklabels(list(pivot.index), fontsize=9)

    for i in range(vals.shape[0]):
        for j in range(vals.shape[1]):
            v = vals[i, j]
            p = sig_df.values[i, j] if np.isfinite(sig_df.values[i, j]) else 1.0
            txt = f"{v:+.3f}"
            star = " *" if p < 0.05 else ""
            color = "white" if abs(v) > vmax * 0.6 else "black"
            ax.text(j, i, txt + star, ha="center", va="center", fontsize=9, color=color, fontweight="bold" if star else "normal")

    cbar = fig.colorbar(im, ax=ax, shrink=0.85, pad=0.02)
    cbar.set_label("Headroom-normalized effect", fontsize=9)
    ax.text(0.01, -0.06, "* = Holm-corrected p < 0.05; exploratory only", transform=ax.transAxes, fontsize=8, color="#888")
    fig.tight_layout()
    _save(fig, "fig2_cross_model_planned_contrast_heatmap.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 3 — Baseline/floor evaluability panel
# ═══════════════════════════════════════════════════════════════════════════
def fig3_floor_panel(story: dict) -> None:
    rows = story["floor_evaluability"]["rows"]
    df = pd.DataFrame(rows).sort_values(["model", "task", "span"]).reset_index(drop=True)
    df["family"] = df.apply(lambda r: f"{r['model'].split('-')[0]}\n{r['task']}\nspan {int(r['span'])}", axis=1)

    x = np.arange(len(df))
    w = 0.38

    fig, ax1 = plt.subplots(figsize=(9, 4.5))
    bars1 = ax1.bar(x - w/2, df["none_accuracy_mean"], width=w, color="#2563eb", alpha=0.85, label="Baseline accuracy")
    ax1.set_ylabel("Baseline accuracy (none intervention)")
    ax1.set_ylim(0.0, min(0.75, float(df["none_accuracy_mean"].max()) + 0.1))
    ax1.axhline(0.15, color="#dc2626", ls="--", lw=1.2, alpha=0.7, label="Floor threshold (0.15)")

    ax2 = ax1.twinx()
    bars2 = ax2.bar(x + w/2, df["none_pass_rate_at_floor"], width=w, color="#16a34a", alpha=0.7, label="Floor pass rate")
    ax2.set_ylabel("Pass rate at floor threshold")
    ax2.set_ylim(0.0, 1.08)
    ax2.yaxis.set_major_formatter(mticker.PercentFormatter(xmax=1.0))

    ax1.set_xticks(x)
    ax1.set_xticklabels(df["family"], fontsize=8.5)
    ax1.set_title("Baseline Accuracy and Floor Evaluability by Family")

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc="upper right", fontsize=8.5, framealpha=0.9)
    fig.tight_layout()
    _save(fig, "fig3_baseline_floor_evaluability_panel.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 4 — Mistral retrieval feasibility
# ═══════════════════════════════════════════════════════════════════════════
def fig4_mistral_feas(feas: dict) -> None:
    rows = feas.get("span_rows", [])
    spans = [int(r["span"]) for r in rows]
    acc = [float(r["none_accuracy_mean"]) for r in rows]
    pr = [float(r["pass_rate"]) for r in rows]
    threshold = float(feas.get("floor_threshold", 0.15))

    fig, ax1 = plt.subplots(figsize=(7, 4.2))
    ax1.plot(spans, acc, "o-", lw=2.2, color="#2563eb", ms=8, label="Baseline accuracy", zorder=5)
    ax1.axhline(threshold, color="#dc2626", ls="--", lw=1.5, label=f"Floor threshold = {threshold:.2f}", zorder=3)
    ax1.fill_between(spans, threshold, acc, where=[a < threshold for a in acc], alpha=0.15, color="#dc2626")
    ax1.set_xlabel("Retrieval span (tokens)")
    ax1.set_ylabel("Baseline accuracy")

    ax2 = ax1.twinx()
    ax2.plot(spans, pr, "s-", lw=2.0, color="#16a34a", ms=8, label="Seed pass rate")
    ax2.set_ylabel("Pass rate (seeds above floor)")
    ax2.set_ylim(-0.05, 1.1)
    ax2.yaxis.set_major_formatter(mticker.PercentFormatter(xmax=1.0))

    ax1.set_title("Mistral 7B Retrieval Feasibility Pre-Pass")
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="center right", fontsize=9, framealpha=0.9)

    for s, a in zip(spans, acc):
        ax1.annotate(f"{a:.3f}", (s, a), textcoords="offset points", xytext=(0, 8), fontsize=8.5, ha="center", color="#2563eb")

    fig.tight_layout()
    _save(fig, "fig4_mistral_retrieval_feasibility.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 5 — Retrieval pair profiles (Llama + OLMo side by side)
# ═══════════════════════════════════════════════════════════════════════════
def fig5_retrieval_profiles(story: dict) -> None:
    profiles = story["pair_profiles"]
    llama_keys = [("llama_retrieval_span32", "span 32", "#2563eb"),
                  ("llama_retrieval_span48", "span 48", "#f59e0b"),
                  ("llama_retrieval_span64", "span 64", "#16a34a")]
    olmo_keys = [("olmo_retrieval_span24", "span 24", "#7c3aed"),
                 ("olmo_retrieval_span32", "span 32", "#b45309")]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5), sharey=True)

    for key, label, color in llama_keys:
        rows = profiles.get(key, [])
        if not rows:
            continue
        x = [int(r["pair_idx"]) for r in rows]
        y = [float(r["effect_over_headroom"]) for r in rows]
        ax1.plot(x, y, "o-", lw=2.0, color=color, ms=7, label=label)

    ax1.axhline(0.0, color="#999", lw=0.8, ls="--")
    ax1.fill_between([0, 56], 0, 1.1, alpha=0.03, color="#16a34a")
    ax1.set_title("Llama 8B Retrieval")
    ax1.set_xlabel("RoPE pair index (0 = highest frequency)")
    ax1.set_ylabel("Headroom-normalized effect")
    ax1.legend(loc="upper right", framealpha=0.9)
    ax1.annotate("High freq\n(local)", xy=(2, -0.15), fontsize=8, color="#666", ha="center")
    ax1.annotate("Low freq\n(global)", xy=(54, -0.15), fontsize=8, color="#666", ha="center")

    for key, label, color in olmo_keys:
        rows = profiles.get(key, [])
        if not rows:
            continue
        x = [int(r["pair_idx"]) for r in rows]
        y = [float(r["effect_over_headroom"]) for r in rows]
        ax2.plot(x, y, "o-", lw=2.0, color=color, ms=7, label=label)

    ax2.axhline(0.0, color="#999", lw=0.8, ls="--")
    ax2.set_title("OLMo 7B Retrieval")
    ax2.set_xlabel("RoPE pair index (0 = highest frequency)")
    ax2.legend(loc="upper right", framealpha=0.9)

    fig.suptitle("Per-Pair Ablation Effect on Retrieval Accuracy", fontsize=14, fontweight="bold", y=1.02)
    fig.tight_layout()
    _save(fig, "fig5_pair_profiles_retrieval.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 6 — Mirror task (local_key_match) pair profiles
# ═══════════════════════════════════════════════════════════════════════════
def fig6_mirror_profiles(story: dict) -> None:
    profiles = story["pair_profiles"]
    models = [("llama_local_key_match", "Llama 8B", "#2563eb"),
              ("olmo_local_key_match", "OLMo 7B", "#7c3aed"),
              ("mistral_local_key_match", "Mistral 7B", "#06b6d4")]

    fig, ax = plt.subplots(figsize=(8, 4.5))
    for key, label, color in models:
        rows = profiles.get(key, [])
        if not rows:
            continue
        x = [int(r["pair_idx"]) for r in rows]
        y = [float(r["effect_over_headroom"]) for r in rows]
        ax.plot(x, y, "o-", lw=2.0, color=color, ms=7, label=label)

    ax.axhline(0.0, color="#999", lw=0.8, ls="--")
    ax.set_title("Short-Task Mirror: Per-Pair Effect on Local Key Match")
    ax.set_xlabel("RoPE pair index (0 = highest frequency)")
    ax.set_ylabel("Headroom-normalized effect")
    ax.legend(loc="best", framealpha=0.9)

    # Annotate Llama's sign reversal at pair 56
    llama = profiles.get("llama_local_key_match", [])
    if llama:
        p56 = [r for r in llama if int(r["pair_idx"]) == 56]
        if p56:
            val = float(p56[0]["effect_over_headroom"])
            ax.annotate(f"Llama pair 56: {val:+.3f}\n(sign reversal vs retrieval)",
                       xy=(56, val), textcoords="offset points", xytext=(-80, -25),
                       fontsize=8.5, color="#2563eb",
                       arrowprops=dict(arrowstyle="->", color="#2563eb", lw=1.2))

    fig.tight_layout()
    _save(fig, "fig6_pair_profiles_local_key_match.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 7 — Pair-index percentile mapping (Gemma comparability)
# ═══════════════════════════════════════════════════════════════════════════
def fig7_percentile_mapping(story: dict) -> None:
    cmp = story.get("gemma_comparability", {})
    llama_pairs = int(cmp.get("llama_pairs", 64))
    gemma_pairs = int(cmp.get("gemma_pairs", 128))
    pct_llama = float(cmp.get("percentile_examples", {}).get("pair56_in_llama_olmo", 0.889))
    pct_gemma = float(cmp.get("percentile_examples", {}).get("pair56_in_gemma", 0.441))
    mapped = int(cmp.get("percentile_examples", {}).get("gemma_pair_at_llama56_percentile", 113))

    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    labels = [f"Llama/OLMo\npair 56\n({llama_pairs} total pairs)",
              f"Gemma\npair 56\n({gemma_pairs} total pairs)",
              f"Gemma mapped\npair {mapped}\n(matched percentile)"]
    vals = [pct_llama, pct_gemma, pct_llama]
    colors = ["#2563eb", "#dc2626", "#16a34a"]
    bars = ax.bar(labels, vals, color=colors, width=0.55, edgecolor="white", linewidth=1.5)

    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("Frequency percentile within model")
    ax.set_title("Cross-Model Pair-Index Comparability")
    ax.yaxis.set_major_formatter(mticker.PercentFormatter(xmax=1.0))

    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width()/2, v + 0.02, f"{v:.1%}", ha="center", fontsize=11, fontweight="bold")

    # Draw arrow showing the mismatch
    ax.annotate("", xy=(1, pct_gemma + 0.02), xytext=(0, pct_llama - 0.02),
               arrowprops=dict(arrowstyle="<->", color="#dc2626", lw=1.5))
    ax.text(0.5, (pct_llama + pct_gemma)/2, "44.8% gap!", ha="center", fontsize=9, color="#dc2626", fontweight="bold")

    fig.tight_layout()
    _save(fig, "fig7_pair_index_percentile_mapping.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 8 — Fast-check: difficulty decomposition
# ═══════════════════════════════════════════════════════════════════════════
def fig8_difficulty_decomp(df: pd.DataFrame) -> None:
    df = df.sort_values(["task", "span"]).copy()
    x_labels = [f"{r.task}\n(span {int(r.span)})" for r in df.itertuples(index=False)]
    x = np.arange(len(df))
    w = 0.25

    fig, ax = plt.subplots(figsize=(8.5, 4.5))
    ax.bar(x - w, df["structured_first"], width=w, color="#2563eb", label="Structured-first (default)")
    ax.bar(x, df["structured_only"], width=w, color="#f59e0b", label="Structured-only", alpha=0.8)
    ax.bar(x + w, df["random_only"], width=w, color="#16a34a", label="Random-only")

    ax.set_xticks(x)
    ax.set_xticklabels(x_labels, fontsize=9)
    ax.set_ylabel("Baseline accuracy (no intervention)")
    ax.set_title("Candidate-Policy Difficulty Decomposition")
    ax.legend(loc="upper right", framealpha=0.9)

    # Annotate the delta
    for i, row in enumerate(df.itertuples(index=False)):
        delta = row.random_only - row.structured_first
        ax.annotate(f"+{delta:.3f}", (i + w, row.random_only), textcoords="offset points",
                   xytext=(0, 5), fontsize=8, ha="center", color="#16a34a")

    ax.text(0.01, 0.01, "structured_only = structured_first (path equivalence, not independent test)\nMean random_only delta: +0.075",
            transform=ax.transAxes, fontsize=8, color="#888")
    fig.tight_layout()
    _save(fig, "fig8_fastcheck_difficulty_decomp.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 9 — Fast-check: headroom audit
# ═══════════════════════════════════════════════════════════════════════════
def fig9_headroom_audit(df: pd.DataFrame) -> None:
    df = df.sort_values(["task_class", "task", "span"]).copy()
    labels = [f"{r.task}\n(span {int(r.span)})" for r in df.itertuples(index=False)]
    x = np.arange(len(df))
    colors = ["#16a34a" if t == "short" else "#dc2626" for t in df["task_class"]]

    fig, ax = plt.subplots(figsize=(8, 4.5))
    bars = ax.bar(x, df["baseline_headroom_mean"], color=colors, width=0.55, edgecolor="white", linewidth=1.5)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_ylabel("Baseline headroom (accuracy - chance)")
    ax.set_title("Headroom Audit: Available Signal for Detecting Ablation Effects")
    ax.axhline(0.0, color="#999", lw=0.8, ls="--")

    for xi, v in zip(x, df["baseline_headroom_mean"]):
        ax.text(xi, float(v) + 0.008, f"{float(v):.3f}", ha="center", fontsize=9.5, fontweight="bold")

    # Legend for color
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color="#16a34a", label="Short-range tasks"),
                       Patch(color="#dc2626", label="Long-range tasks")],
             loc="upper right", framealpha=0.9)

    # Annotate the ratio
    short_mean = float(df[df["task_class"] == "short"]["baseline_headroom_mean"].mean())
    long_mean = float(df[df["task_class"] == "long"]["baseline_headroom_mean"].mean())
    ratio = long_mean / short_mean if short_mean > 0 else 0
    ax.text(0.01, 0.92, f"Long/short headroom ratio: {ratio:.3f}", transform=ax.transAxes,
            fontsize=9.5, fontweight="bold", color="#dc2626",
            bbox=dict(boxstyle="round,pad=0.3", facecolor="#fff5f5", edgecolor="#dc2626", alpha=0.8))

    fig.tight_layout()
    _save(fig, "fig9_fastcheck_headroom_audit.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 10 — Fast-check: semi-natural bridge
# ═══════════════════════════════════════════════════════════════════════════
def fig10_natural_bridge(summary: dict) -> None:
    rows = pd.DataFrame(summary["summary_rows"])
    interventions = ["none", "ablate_high_strong", "ablate_low_strong", "random_strong"]
    styles = {
        "none": ("#2563eb", "o", "Baseline (no ablation)"),
        "ablate_high_strong": ("#dc2626", "v", "High-band ablation"),
        "ablate_low_strong": ("#16a34a", "^", "Low-band ablation"),
        "random_strong": ("#7c3aed", "D", "Random ablation (control)"),
    }

    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for name in interventions:
        sub = rows[rows["intervention"] == name].sort_values("span")
        if sub.empty:
            continue
        color, marker, label = styles[name]
        ax.plot(sub["span"].astype(int).tolist(),
               sub["mean_accuracy_restricted"].astype(float).tolist(),
               marker=marker, lw=2.0, color=color, ms=8, label=label, zorder=5)

    ax.set_xlabel("Span (tokens)")
    ax.set_ylabel("Restricted accuracy (10-way)")
    ax.set_title("Semi-Natural Bridge: Band Ablation on Wiki Text")
    ax.set_ylim(0.72, 1.01)
    ax.legend(loc="lower left", framealpha=0.9)

    # Annotate the gap
    ax.annotate("High-band ablation\ncauses ~2x more damage\nthan low-band",
               xy=(48, 0.77), fontsize=8.5, color="#dc2626",
               bbox=dict(boxstyle="round,pad=0.3", facecolor="#fff5f5", edgecolor="#dc2626", alpha=0.8))

    fig.tight_layout()
    _save(fig, "fig10_fastcheck_natural_bridge.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 11 — Fast-check: tokenizer sensitivity
# ═══════════════════════════════════════════════════════════════════════════
def fig11_tokenizer(df: pd.DataFrame) -> None:
    sub = df[df["bin_type"] == "token_piece_bin"].copy()
    order = ["<=2", "3-4", "5-8", "9+"]
    sub["bin"] = pd.Categorical(sub["bin"], categories=order, ordered=True)
    agg = sub.groupby("bin", observed=True, as_index=False).agg(accuracy=("accuracy", "mean"), n=("n", "sum")).sort_values("bin")

    # Also get per-task breakdown
    task_agg = sub.groupby(["task", "bin"], observed=True, as_index=False).agg(accuracy=("accuracy", "mean"))

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

    # Left: overall
    bars = ax1.bar(agg["bin"].astype(str), agg["accuracy"], color="#2563eb", width=0.6, edgecolor="white", linewidth=1.5)
    ax1.set_ylabel("Mean baseline accuracy")
    ax1.set_xlabel("Token piece-length bin")
    ax1.set_title("Overall Tokenizer Sensitivity")
    for i, (_, row) in enumerate(agg.iterrows()):
        ax1.text(i, float(row["accuracy"]) + 0.01, f"{float(row['accuracy']):.3f}", ha="center", fontsize=9.5, fontweight="bold")
    ax1.set_ylim(0, max(0.55, float(agg["accuracy"].max()) + 0.08))

    # Right: per-task breakdown
    tasks = sorted(sub["task"].unique())
    task_colors = {"delayed_copy": "#dc2626", "local_copy_offset": "#f59e0b",
                   "local_key_match": "#16a34a", "long_range_retrieval": "#7c3aed"}
    x_pos = np.arange(len(order))
    w = 0.2
    for i, task in enumerate(tasks):
        tsub = task_agg[task_agg["task"] == task].set_index("bin").reindex(order)
        ax2.bar(x_pos + i * w - w * len(tasks)/2, tsub["accuracy"].fillna(0), width=w,
               color=task_colors.get(task, "#888"), label=task.replace("_", " "), alpha=0.85)
    ax2.set_xticks(x_pos)
    ax2.set_xticklabels(order)
    ax2.set_xlabel("Token piece-length bin")
    ax2.set_ylabel("Baseline accuracy")
    ax2.set_title("Per-Task Breakdown")
    ax2.legend(loc="upper right", fontsize=8, framealpha=0.9)

    fig.suptitle("Tokenizer Sensitivity: Shorter Tokens Are Easier", fontsize=13, fontweight="bold", y=1.02)
    fig.tight_layout()
    _save(fig, "fig11_fastcheck_tokenizer_sensitivity.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 12 — NEW: Option D ablation vs attenuation comparison
# ═══════════════════════════════════════════════════════════════════════════
def fig12_optiond_comparison() -> None:
    # Load both Option D results
    with open(OPTIOND_CROSS) as f:
        cross = json.load(f)

    # Extract dose data
    ab_block = cross.get("attenuation_confirmatory_block", {})
    dose = ab_block.get("dose_diagnostics", {}).get("raw", {})
    h1_dose = dose.get("h1", {})
    h2_dose = dose.get("h2", {})

    # Ablation (100%) from main block
    h1_abl = cross["h1"]
    h2_abl = cross["h2"]

    levels = ["25%", "50%", "75%", "100%\n(ablation)"]
    h1_vals = [float(h1_dose["25"]["effect"]), float(h1_dose["50"]["effect"]),
               float(h1_dose["75"]["effect"]), float(h1_abl["effect"])]
    h2_vals = [float(h2_dose["25"]["effect"]), float(h2_dose["50"]["effect"]),
               float(h2_dose["75"]["effect"]), float(h2_abl["effect"])]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

    # H1
    bars1 = ax1.bar(levels, h1_vals, color=["#93c5fd", "#60a5fa", "#2563eb", "#1d4ed8"],
                    width=0.55, edgecolor="white", linewidth=1.5)
    ax1.axhline(0.0, color="#999", lw=0.8, ls="--")
    ax1.set_title("H1: Short-Range Sensitivity")
    ax1.set_ylabel("Effect size (higher = more short-range damage)")
    ax1.set_xlabel("Attenuation level")
    for b, v in zip(bars1, h1_vals):
        ax1.text(b.get_x() + b.get_width()/2, v + 0.003, f"{v:+.3f}", ha="center", fontsize=9, fontweight="bold")
    ax1.text(0.5, 0.92, "PASS at all levels", transform=ax1.transAxes, ha="center",
            fontsize=10, color="#16a34a", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.3", facecolor="#f0fdf4", edgecolor="#16a34a"))

    # H2
    bars2 = ax2.bar(levels, h2_vals, color=["#fca5a5", "#f87171", "#dc2626", "#991b1b"],
                    width=0.55, edgecolor="white", linewidth=1.5)
    ax2.axhline(0.0, color="#999", lw=0.8, ls="--")
    ax2.set_title("H2: Long-Range Selectivity (Expected Positive)")
    ax2.set_ylabel("Effect size (positive = more long-range damage)")
    ax2.set_xlabel("Attenuation level")
    for b, v in zip(bars2, h2_vals):
        ax2.text(b.get_x() + b.get_width()/2, v - 0.012, f"{v:+.3f}", ha="center", fontsize=9, fontweight="bold")
    ax2.text(0.5, 0.08, "FAIL (reversed) at all levels", transform=ax2.transAxes, ha="center",
            fontsize=10, color="#dc2626", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.3", facecolor="#fef2f2", edgecolor="#dc2626"))

    fig.suptitle("Option D Cross-Model: Ablation vs Continuous Attenuation\n(3 models, 7 seeds, spans 32/48/64)",
                fontsize=13, fontweight="bold", y=1.06)
    fig.tight_layout()
    _save(fig, "fig12_optiond_ablation_vs_attenuation.png")


# ═══════════════════════════════════════════════════════════════════════════
# Fig 13 — NEW: Full experimental arc summary
# ═══════════════════════════════════════════════════════════════════════════
def fig13_experimental_arc() -> None:
    stages = [
        "1B Confirmatory\n(3 models)",
        "7-8B Phase 2A\n(overlap branch)",
        "Option D Pilot\n(Llama only)",
        "Option D Cross-Model\n(3 models)",
    ]
    h1_vals = [0.047, 0.112, 0.103, 0.101]
    h2_vals = [-0.155, -0.245, -0.294, -0.205]
    h1_labels = ["fail", "pass", "pass", "pass"]
    h2_labels = ["fail", "fail", "fail", "fail"]

    x = np.arange(len(stages))
    w = 0.35

    fig, ax = plt.subplots(figsize=(9.5, 5))
    bars1 = ax.bar(x - w/2, h1_vals, width=w, color="#2563eb", label="H1 (short-range sensitivity)", zorder=5)
    bars2 = ax.bar(x + w/2, h2_vals, width=w, color="#dc2626", label="H2 (long-range selectivity)", zorder=5)
    ax.axhline(0.0, color="#333", lw=1.0, zorder=1)

    # Labels
    for i, (b, lab) in enumerate(zip(bars1, h1_labels)):
        color = "#16a34a" if lab == "pass" else "#dc2626"
        ax.text(b.get_x() + b.get_width()/2, h1_vals[i] + 0.012,
               f"{h1_vals[i]:+.3f}\n{lab.upper()}", ha="center", fontsize=8.5,
               fontweight="bold", color=color)

    for i, (b, lab) in enumerate(zip(bars2, h2_labels)):
        ax.text(b.get_x() + b.get_width()/2, h2_vals[i] - 0.025,
               f"{h2_vals[i]:+.3f}\n{lab.upper()}", ha="center", fontsize=8.5,
               fontweight="bold", color="#dc2626")

    ax.set_xticks(x)
    ax.set_xticklabels(stages, fontsize=9.5)
    ax.set_ylabel("Effect size")
    ax.set_title("Full Experimental Arc: Band-Level H1/H2 Across All Analyses", fontsize=13, fontweight="bold")
    ax.legend(loc="upper right", framealpha=0.9)
    ax.set_ylim(-0.38, 0.22)

    ax.text(0.5, 0.02, "H1 is robust across scales and intervention types; H2 is consistently reversed",
           transform=ax.transAxes, ha="center", fontsize=9.5, style="italic", color="#555")

    fig.tight_layout()
    _save(fig, "fig13_experimental_arc_summary.png")


# ═══════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════
def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    _theme()

    print("Loading data...")
    story = json.loads(PAIR_STORY.read_text())
    planned = pd.read_parquet(PAIR_CONTRASTS)
    feas = json.loads(MISTRAL_FEAS.read_text())

    print("\nGenerating pair-sweep figures (1-7)...")
    fig1_llama_trend(story)
    fig2_heatmap(planned)
    fig3_floor_panel(story)
    fig4_mistral_feas(feas)
    fig5_retrieval_profiles(story)
    fig6_mirror_profiles(story)
    fig7_percentile_mapping(story)

    print("\nGenerating fast-check figures (8-11)...")
    fig8_difficulty_decomp(pd.read_parquet(FC_DIFF_PARQUET))
    fig9_headroom_audit(pd.read_parquet(FC_HEADROOM_PARQUET))
    fig10_natural_bridge(json.loads(FC_NATURAL_JSON.read_text()))
    fig11_tokenizer(pd.read_parquet(FC_TOKEN_PARQUET))

    print("\nGenerating Option D figures (12-13)...")
    fig12_optiond_comparison()
    fig13_experimental_arc()

    print(f"\nDone. {len(list(OUT_DIR.glob('fig*.png')))} figures in {OUT_DIR}/")


if __name__ == "__main__":
    main()
