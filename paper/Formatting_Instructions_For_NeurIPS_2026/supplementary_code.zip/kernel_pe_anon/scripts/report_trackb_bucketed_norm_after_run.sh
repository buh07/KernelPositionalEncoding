#!/usr/bin/env bash
set -euo pipefail

cd "/scratch2/anon/Kernel PE"
export PYTHONUNBUFFERED=1

LOG_DIR="logs/trackb"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/trackb_bucketed_report_waiter.log"
exec > >(tee -a "$LOG_FILE") 2>&1

TARGET_COUNT=36
SUMMARY_GLOB="results/track_b_bucketed_mean_v1/*/*/len_*/summary.parquet"

echo "Waiting for bucketed Track B completion (${TARGET_COUNT} summaries)..."
while true; do
  count=$(find results/track_b_bucketed_mean_v1 -name summary.parquet | wc -l)
  now=$(date -Iseconds)
  echo "[$now] current summaries: $count/$TARGET_COUNT"
  if [[ "$count" -ge "$TARGET_COUNT" ]]; then
    break
  fi
  # If both compute sessions are gone before completion, stop and surface failure.
  if ! tmux has-session -t trackb_bucketed_g2 2>/dev/null && ! tmux has-session -t trackb_bucketed_g5 2>/dev/null; then
    echo "Bucketed Track B sessions ended before full coverage ($count/$TARGET_COUNT)."
    exit 1
  fi
  sleep 120
done

echo "Running norm-aware granularity report..."
.venv/bin/python experiment1/report_trackb_granularity_norm.py
echo "Norm-aware granularity report complete."
