#!/usr/bin/env bash
set -euo pipefail

ROOT="/scratch2/anon/Kernel PE"
cd "$ROOT"

QUEUE_FILE="logs/trackb/trackb_bucketed_queue.tsv"
if [[ ! -f "$QUEUE_FILE" ]]; then
  bash scripts/trackb_bucketed_queue_build.sh "$QUEUE_FILE"
fi

GPUS=("$@")
if [[ ${#GPUS[@]} -eq 0 ]]; then
  GPUS=("5")
fi

for gpu in "${GPUS[@]}"; do
  session="trackb_bucketed_worker_g${gpu}"
  if tmux has-session -t "$session" 2>/dev/null; then
    echo "tmux session already exists: $session (skipping)"
    continue
  fi
  tmux new-session -d -s "$session" "cd \"$ROOT\" && bash scripts/trackb_bucketed_queue_worker.sh \"$gpu\" \"$QUEUE_FILE\""
  echo "started tmux session: $session"
done

echo "Workers active. Inspect with:"
echo "  tmux ls"
echo "  tmux capture-pane -pt trackb_bucketed_worker_g5 | tail -n 60"
