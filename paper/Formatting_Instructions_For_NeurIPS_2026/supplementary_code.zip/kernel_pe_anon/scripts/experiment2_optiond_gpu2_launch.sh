#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

RUN_TAG="${1:-optiond_pilot_$(date +%Y%m%d_%H%M%S)}"
RUN_ID="${RUN_TAG}_phase2b"
OUTPUT_ROOT="results/experiment2/quick/${RUN_TAG}"
LOG_ROOT="logs/experiment2/quick/${RUN_TAG}"
MANIFEST_DIR="${OUTPUT_ROOT}/manifests"

MANIFEST_PATH="${MANIFEST_DIR}/${RUN_ID}.jsonl"
SUMMARY_PATH="${MANIFEST_DIR}/${RUN_ID}.summary.json"

mkdir -p "${LOG_ROOT}" "${MANIFEST_DIR}"

for sess in exp2_optd_g2 exp2_optd_g2_report; do
  tmux kill-session -t "${sess}" 2>/dev/null || true
done

echo "[optiond] build pilot manifest run_id=${RUN_ID}" | tee "${LOG_ROOT}/launch.log"
.venv/bin/python scripts/experiment2_optiond_pilot_build_manifest.py \
  --output-manifest "${MANIFEST_PATH}" \
  --summary-json "${SUMMARY_PATH}" \
  --run-id "${RUN_ID}" \
  --phase phase2b \
  --model llama-3.1-8b \
  --seq-len 1024 \
  --seeds 0,1,2 \
  --retrieval-spans 32,48,64 | tee -a "${LOG_ROOT}/launch.log"

ROW_COUNT="$(( $(wc -l < "${MANIFEST_PATH}") ))"
if [[ "${ROW_COUNT}" -le 0 ]]; then
  echo "[optiond] manifest has zero rows; aborting." >&2
  exit 1
fi
if [[ "${ROW_COUNT}" -ne 252 ]]; then
  echo "[optiond] unexpected row count=${ROW_COUNT} (expected 252)." >&2
  exit 1
fi

echo "[optiond] launching execute on GPU 2" | tee -a "${LOG_ROOT}/launch.log"
tmux new-session -d -s exp2_optd_g2 \
  "cd '${ROOT_DIR}' && CUDA_VISIBLE_DEVICES=2 .venv/bin/python experiment2/run.py --mode execute --manifest '${MANIFEST_PATH}' --output-root '${OUTPUT_ROOT}' --device cuda:0 --kernel-engine optimized --centered-compute defer --synthetic-eval-mode restricted --candidate-size 10 --h12-endpoint-policy co_primary_raw_headroom --track-a-enabled false --intervention-profile full --synthetic-count 100 --batch-size-synth 12 --feasibility-task-only --print-summary |& tee '${LOG_ROOT}/exp2_optd_g2.log'"

echo "[optiond] launching follow-up report/reanalyze watcher" | tee -a "${LOG_ROOT}/launch.log"
tmux new-session -d -s exp2_optd_g2_report \
  "cd '${ROOT_DIR}' && while tmux has-session -t exp2_optd_g2 2>/dev/null; do sleep 30; done && .venv/bin/python experiment2/run.py --mode reanalyze --phase phase2b --run-id '${RUN_ID}' --output-root '${OUTPUT_ROOT}' --print-summary |& tee '${LOG_ROOT}/exp2_optd_g2_reanalyze.log' && .venv/bin/python - <<'PY'
from pathlib import Path
import json
phase_root = Path('${OUTPUT_ROOT}') / 'phase2b' / '${RUN_ID}'
gate_path = phase_root / 'gate_evaluation.json'
out = {
    'phase_root': str(phase_root),
    'gate_exists': gate_path.exists(),
}
if gate_path.exists():
    payload = json.loads(gate_path.read_text(encoding='utf-8'))
    out['confirmatory_success'] = payload.get('confirmatory_success')
    out['confirmatory_success_optiond'] = payload.get('confirmatory_success_optiond')
    out['attenuation_confirmatory_success'] = payload.get('confirmatory_success_attenuation')
print(json.dumps(out, indent=2, sort_keys=True))
PY |& tee '${LOG_ROOT}/exp2_optd_g2_summary.log'"

cat <<EOF
[optiond] launched
  run_tag: ${RUN_TAG}
  run_id: ${RUN_ID}
  manifest: ${MANIFEST_PATH}
  sessions:
    - exp2_optd_g2
    - exp2_optd_g2_report
  logs: ${LOG_ROOT}
EOF
