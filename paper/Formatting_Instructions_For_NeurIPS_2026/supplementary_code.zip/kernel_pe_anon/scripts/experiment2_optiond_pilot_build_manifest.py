#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path


def _parse_int_list(raw: str) -> list[int]:
    out: list[int] = []
    seen: set[int] = set()
    for part in str(raw).split(","):
        token = part.strip()
        if not token:
            continue
        value = int(token)
        if value not in seen:
            out.append(value)
            seen.add(value)
    if not out:
        raise SystemExit("expected at least one integer value")
    return out


def _build_rows(
    *,
    run_id: str,
    phase: str,
    model: str,
    seq_len: int,
    seeds: list[int],
    retrieval_spans: list[int],
) -> list[dict[str, object]]:
    legacy_conditions: list[tuple[str, int | None]] = [
        ("none", None),
        ("ablate_high_strong", None),
        ("ablate_low_strong", None),
    ]
    legacy_conditions.extend(("random_strong", draw) for draw in (0, 1, 2))

    attenuation_conditions: list[tuple[str, int | None]] = []
    for pct in (25, 50, 75):
        attenuation_conditions.append((f"attenuate_high_{pct}", None))
        attenuation_conditions.append((f"attenuate_low_{pct}", None))
        attenuation_conditions.extend((f"attenuate_random_{pct}", draw) for draw in (0, 1, 2))

    all_conditions = legacy_conditions + attenuation_conditions

    rows: list[dict[str, object]] = []

    def add_family(task: str, span: int | None) -> None:
        for seed in seeds:
            for intervention, random_draw in all_conditions:
                row: dict[str, object] = {
                    "phase": phase,
                    "split": "synthetic",
                    "model": model,
                    "task": task,
                    "seq_len": int(seq_len),
                    "intervention": intervention,
                    "seed": int(seed),
                    "span": (int(span) if span is not None else None),
                    "random_draw": random_draw,
                    "device": "cuda",
                    "run_id": run_id,
                    "notes": "optiond_continuous_attenuation_pilot|llama_only|retrieval_mirror",
                }
                rows.append(row)

    for span in retrieval_spans:
        add_family("long_range_retrieval", int(span))
    add_family("local_key_match", None)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Build Option D llama-only pilot manifest (continuous attenuation + legacy strong block).")
    parser.add_argument("--output-manifest", required=True)
    parser.add_argument("--summary-json", required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--phase", default="phase2b")
    parser.add_argument("--model", default="llama-3.1-8b")
    parser.add_argument("--seq-len", type=int, default=1024)
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--retrieval-spans", default="32,48,64")
    args = parser.parse_args()

    seeds = _parse_int_list(args.seeds)
    spans = _parse_int_list(args.retrieval_spans)
    rows = _build_rows(
        run_id=str(args.run_id),
        phase=str(args.phase),
        model=str(args.model),
        seq_len=int(args.seq_len),
        seeds=seeds,
        retrieval_spans=spans,
    )

    expected_rows = (len(spans) + 1) * len(seeds) * 21
    if len(rows) != expected_rows:
        raise RuntimeError(f"unexpected row count: got={len(rows)} expected={expected_rows}")

    manifest_path = Path(args.output_manifest)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with manifest_path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")

    phase_counts = Counter(str(r["phase"]) for r in rows)
    task_counts = Counter(str(r["task"]) for r in rows)
    intervention_counts = Counter(str(r["intervention"]) for r in rows)

    payload = {
        "run_id": str(args.run_id),
        "phase": str(args.phase),
        "model": str(args.model),
        "seq_len": int(args.seq_len),
        "seeds": seeds,
        "retrieval_spans": spans,
        "total_rows": len(rows),
        "expected_rows": int(expected_rows),
        "phase_counts": dict(sorted(phase_counts.items())),
        "task_counts": dict(sorted(task_counts.items())),
        "intervention_counts": dict(sorted(intervention_counts.items())),
        "optiond_policy": "continuous_attenuation_parallel_block_v1",
        "attenuation_levels": [25, 50, 75],
        "attenuation_primary_level": 75,
        "legacy_ablation_block_unchanged": True,
    }
    summary_path = Path(args.summary_json)
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
