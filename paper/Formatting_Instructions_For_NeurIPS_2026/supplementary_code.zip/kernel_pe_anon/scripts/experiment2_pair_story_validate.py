#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def _check_contains(text: str, needle: str, label: str, failures: list[str]) -> None:
    if needle not in text:
        failures.append(f"Missing {label}: {needle}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate doc/presentation text against story_snapshot.json")
    parser.add_argument("--story", required=True)
    parser.add_argument("--overview", required=True)
    parser.add_argument("--presentation", required=True)
    args = parser.parse_args()

    story = json.loads(Path(args.story).read_text(encoding="utf-8"))
    overview = Path(args.overview).read_text(encoding="utf-8")
    presentation = Path(args.presentation).read_text(encoding="utf-8")

    run_tag = story["run"]["run_tag"]
    llama32 = story["outcome_board"]["llama"]["evidence"]["retrieval_pair0_vs_pair56"][0]
    llama64 = story["outcome_board"]["llama"]["evidence"]["retrieval_pair0_vs_pair56"][2]
    olmo32 = story["outcome_board"]["olmo"]["evidence"]["retrieval_pair0_vs_pair56"][1]
    mistral_eval = story["outcome_board"]["mistral"]["evidence"]["retrieval_evaluable"]

    failures: list[str] = []

    # Overview expectations.
    _check_contains(overview, run_tag, "run tag in overview", failures)
    _check_contains(overview, "exploratory-only", "exploratory boundary in overview", failures)
    _check_contains(overview, "non-retroactive", "non-retroactive boundary in overview", failures)
    _check_contains(overview, "Chronological Results Narrative", "chronological section in overview", failures)
    _check_contains(overview, "Why H2 Failed", "H2 interpretation section in overview", failures)
    _check_contains(overview, "Gemma Pair-Index Confound", "Gemma confound section in overview", failures)
    _check_contains(overview, "Final Results Summary", "final summary table section in overview", failures)
    _check_contains(overview, "Interpretation and Conclusions", "conclusions section in overview", failures)
    _check_contains(overview, f"{llama32['effect_raw']:.3f}", "llama span32 raw effect in overview", failures)
    _check_contains(overview, f"{llama64['effect_over_headroom']:.3f}", "llama span64 headroom effect in overview", failures)
    _check_contains(overview, f"{olmo32['effect_raw']:.3f}", "olmo span32 raw effect in overview", failures)
    _check_contains(overview, "non-evaluable" if not mistral_eval else "evaluable", "mistral evaluability mention in overview", failures)
    if "## Exploratory Extension (Fully Preregistered)" in overview:
        failures.append("Overview still contains active Exploratory Extension deep-dive section.")
    if "Phase 2C Deep Dive" in overview or "Phase 2D Deep Dive" in overview:
        failures.append("Overview still contains active Phase 2C/2D deep-dive wording.")
    if ".venv/bin/python experiment2/run.py" in overview:
        failures.append("Overview still includes operational command templates.")

    # Presentation expectations.
    _check_contains(presentation, run_tag, "run tag in presentation", failures)
    _check_contains(presentation, "fig1_llama_retrieval_pair0_vs_pair56_trend.png", "figure 1 reference", failures)
    _check_contains(presentation, "fig2_cross_model_planned_contrast_heatmap.png", "figure 2 reference", failures)
    _check_contains(presentation, "fig3_baseline_floor_evaluability_panel.png", "figure 3 reference", failures)
    _check_contains(presentation, "fig4_mistral_retrieval_feasibility.png", "figure 4 reference", failures)
    _check_contains(presentation, "fig5_pair_profiles_retrieval.png", "figure 5 reference", failures)
    _check_contains(presentation, "fig6_pair_profiles_local_key_match.png", "figure 6 reference", failures)
    _check_contains(presentation, "fig7_pair_index_percentile_mapping.png", "figure 7 reference", failures)
    _check_contains(presentation, "exploratory-only", "exploratory boundary in presentation", failures)
    _check_contains(presentation, "no mediation claim", "mediation boundary in presentation", failures)
    _check_contains(presentation, "no training-run generalization", "training variance boundary in presentation", failures)
    _check_contains(presentation, "1B Confirmatory Results", "1B transition slide in presentation", failures)
    _check_contains(presentation, "Why We Scaled Up", "scale-up transition slide in presentation", failures)
    _check_contains(presentation, "Why Pair-Level Analysis", "pair-pivot slide in presentation", failures)
    _check_contains(presentation, "Gemma Pair-Index Comparability", "Gemma confound slide in presentation", failures)
    _check_contains(presentation, "Full Experimental Arc", "closing arc slide in presentation", failures)

    if failures:
        print("VALIDATION_FAILED")
        for f in failures:
            print("-", f)
        raise SystemExit(1)

    print("VALIDATION_OK")


if __name__ == "__main__":
    main()
