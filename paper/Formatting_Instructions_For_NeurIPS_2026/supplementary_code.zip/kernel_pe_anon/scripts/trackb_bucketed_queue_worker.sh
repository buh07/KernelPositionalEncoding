#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <gpu_id> [queue_file]"
  exit 1
fi

GPU_ID="$1"
QUEUE_FILE="${2:-logs/trackb/trackb_bucketed_queue.tsv}"
STATE_FILE="${QUEUE_FILE%.tsv}.state"
LOCK_FILE="${QUEUE_FILE%.tsv}.lock"
FAIL_FILE="${QUEUE_FILE%.tsv}.failures.tsv"

ROOT="/scratch2/anon/Kernel PE"
cd "$ROOT"
mkdir -p "$(dirname "$QUEUE_FILE")" "logs/trackb"

if [[ ! -f "$QUEUE_FILE" ]]; then
  bash scripts/trackb_bucketed_queue_build.sh "$QUEUE_FILE"
fi
touch "$LOCK_FILE"
if [[ ! -s "$STATE_FILE" ]] || ! grep -Eq '^[0-9]+$' "$STATE_FILE"; then
  echo "1" > "$STATE_FILE"
fi

export CUDA_VISIBLE_DEVICES="$GPU_ID"
export PYTHONUNBUFFERED=1

LOG_FILE="logs/trackb/trackb_bucketed_worker_g${GPU_ID}.log"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "[$(date '+%Y-%m-%d %H:%M:%S %Z')] worker start gpu=$GPU_ID queue=$QUEUE_FILE"

claim_next_line() {
  local line_no total line
  exec 9>>"$LOCK_FILE"
  flock -x 9
  line_no="$(cat "$STATE_FILE" 2>/dev/null || echo 1)"
  total="$(wc -l < "$QUEUE_FILE")"
  if (( line_no > total )); then
    flock -u 9
    exec 9>&-
    return 1
  fi
  line="$(sed -n "${line_no}p" "$QUEUE_FILE")"
  echo $((line_no + 1)) > "$STATE_FILE"
  flock -u 9
  exec 9>&-
  printf "%s" "$line"
}

START_TS="$(date +%s)"
RAN=0
SKIPPED=0
FAILED=0

while true; do
  LINE="$(claim_next_line || true)"
  if [[ -z "$LINE" ]]; then
    break
  fi

  IFS=$'\t' read -r OUTPUT_GROUP BUCKET_SIZE MODEL DATASET SEQ_LEN <<< "$LINE"
  OUT_PATH="results/${OUTPUT_GROUP}/${MODEL}/${DATASET}/len_${SEQ_LEN}/summary.parquet"

  if [[ -f "$OUT_PATH" ]]; then
    SKIPPED=$((SKIPPED + 1))
    echo "SKIP existing ${OUTPUT_GROUP} model=${MODEL} dataset=${DATASET} len=${SEQ_LEN}"
    continue
  fi

  echo "START ${OUTPUT_GROUP} model=${MODEL} dataset=${DATASET} len=${SEQ_LEN} bucket=${BUCKET_SIZE}"
  if .venv/bin/python experiment1/run.py track-b \
      --model "$MODEL" \
      --dataset "$DATASET" \
      --seq-len "$SEQ_LEN" \
      --device cuda \
      --track-b-centering-mode bucketed_mean \
      --track-b-bucket-size "$BUCKET_SIZE" \
      --track-b-output-group "$OUTPUT_GROUP" \
      --track-b-artifact-level compact; then
    RAN=$((RAN + 1))
    echo "DONE  ${OUTPUT_GROUP} model=${MODEL} dataset=${DATASET} len=${SEQ_LEN}"
  else
    FAILED=$((FAILED + 1))
    printf "%s\n" "$LINE" >> "$FAIL_FILE"
    echo "FAIL  ${OUTPUT_GROUP} model=${MODEL} dataset=${DATASET} len=${SEQ_LEN} (recorded in $FAIL_FILE)"
  fi
done

END_TS="$(date +%s)"
ELAPSED=$((END_TS - START_TS))

echo "[$(date '+%Y-%m-%d %H:%M:%S %Z')] worker end gpu=$GPU_ID ran=$RAN skipped=$SKIPPED failed=$FAILED elapsed_sec=$ELAPSED"
if (( FAILED > 0 )); then
  exit 1
fi
