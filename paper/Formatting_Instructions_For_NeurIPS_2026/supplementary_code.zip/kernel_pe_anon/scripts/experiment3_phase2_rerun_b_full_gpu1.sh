#!/usr/bin/env bash
set -euo pipefail

ROOT="/path/to/kernel-pe"
cd "$ROOT"

export CUDA_VISIBLE_DEVICES=1
export PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True"

PY="$ROOT/.venv/bin/python"
MODEL="olmo-2-7b"
TS="$(date +%Y%m%d_%H%M%S)"
LOG_DIR="$ROOT/logs/experiment3_phase2_rerun/${MODEL}_3p2b_full_${TS}"
mkdir -p "$LOG_DIR"

run_step() {
  local name="$1"
  shift
  echo "[$(date)] START $name" | tee -a "$LOG_DIR/_session.log"
  "$PY" -u "$@" 2>&1 | tee "$LOG_DIR/${name}.log"
  echo "[$(date)] END $name" | tee -a "$LOG_DIR/_session.log"
}

echo "[$(date)] MODEL=$MODEL GPU=$CUDA_VISIBLE_DEVICES" | tee "$LOG_DIR/_session.log"
run_step 3p2b_full \
  experiment3/phase2/exp3p2b_trivial_feature_control.py \
  --model "$MODEL" \
  --mode full \
  --device cuda:0 \
  --num-sequences 16 \
  --seq-len 512 \
  --top-k-dims 16 \
  --synthetic-target-per-cell 300 \
  --seed 0

echo "[$(date)] COMPLETE $MODEL 3P2-B full" | tee -a "$LOG_DIR/_session.log"
