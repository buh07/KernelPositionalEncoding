#!/usr/bin/env python3
"""
Experiment 3 Theory 7: Induction circuit tracing — do feeder heads have high SI?
=================================================================================

Hypothesis
----------
The anti-correlation between induction score and R² (rho = -0.69 in Llama) appears
to contradict the theory that position-relative circuits need shift-invariance.
But induction heads don't work alone — they read from earlier "previous-token" or
"copy" heads.  Perhaps SI lives in the *feeder* heads (L0-L2), not in the induction
heads themselves (L8-L28).

Protocol
--------
Phase 1 — Load existing data:  R², induction scores
Phase 2 — Previous-token scoring (Approach A):  Run ~50 wiki sequences, compute
           per-head previous-token attention scores
Phase 3 — Cross-reference (Approach A):  Correlate previous-token score with R²,
           especially in early layers
Phase 4 — Knockout analysis (Approach B):  For top-10 induction heads, knock out
           candidate early feeders and measure induction score change
Phase 5 — Unified analysis and report

Usage
-----
    python scripts/experiment3_theory7_induction_feeders.py --model llama-3.1-8b --device cuda:0
    python scripts/experiment3_theory7_induction_feeders.py --model olmo-2-7b --device cuda:1
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch
import numpy as np
import pandas as pd

# ── project imports ──────────────────────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from experiment1.shift_kernels import RoPEEstimator, KernelFit
from experiment1.norm_utils import normalize_logits_for_norm
from shared.attention.adapters import get_adapter
from shared.specs import ModelSpec

# ── constants ────────────────────────────────────────────────────────────────
NUM_WIKI_SEQUENCES = 50          # for previous-token scoring (same as R² profiling)
WIKI_SEQ_LEN = 512
NUM_KNOCKOUT_SEQUENCES = 20      # repeated random sequences per knockout test
KNOCKOUT_PERIOD = 32
KNOCKOUT_SEQ_LEN = 128           # 4 repeats of period
TOP_INDUCTION_HEADS = 20         # loaded from existing data
TOP_INDUCTION_FOR_KNOCKOUT = 10  # only knock out feeders for top-10
MAX_FEEDER_LAYER = 7             # only test feeder heads up to this layer
TOP_FEEDERS_PER_HEAD = 5         # report top-5 most impactful feeders

MODELS: dict[str, ModelSpec] = {
    "llama-3.1-8b": ModelSpec(
        name="llama-3.1-8b",
        hf_id="meta-llama/Meta-Llama-3.1-8B",
        norm="RMSNorm",
        pe_scheme="RoPE",
        notes="Llama 3.1 8B (GQA: 32Q/8KV heads).",
    ),
    "olmo-2-7b": ModelSpec(
        name="olmo-2-7b",
        hf_id="allenai/OLMo-2-1124-7B",
        norm="LayerNorm",
        pe_scheme="RoPE",
        notes="OLMo 2 7B.",
        download_kwargs=(("torch_dtype", "bfloat16"),),
    ),
    "mistral-7b-v0.1": ModelSpec(
        name="mistral-7b-v0.1",
        hf_id="mistralai/Mistral-7B-v0.1",
        norm="RMSNorm",
        pe_scheme="RoPE",
        notes="Mistral 7B v0.1 (GQA).",
    ),
}


# ── data structures ──────────────────────────────────────────────────────────
@dataclass
class HeadID:
    layer: int
    head: int

    def __hash__(self):
        return hash((self.layer, self.head))

    def __eq__(self, other):
        return isinstance(other, HeadID) and self.layer == other.layer and self.head == other.head

    def __repr__(self):
        return f"L{self.layer}H{self.head}"


# ═══════════════════════════════════════════════════════════════════════════════
# HEAD-OUTPUT ABLATION (reused from theory1)
# ═══════════════════════════════════════════════════════════════════════════════

@contextmanager
def head_output_ablation(model, heads_to_zero: list[HeadID]):
    """
    Context manager that zeros the attention output of specified heads by
    hooking into each attention layer's o_proj input.

    The o_proj input has shape [batch, seq, num_query_heads * head_dim].
    We reshape to [batch, seq, num_query_heads, head_dim], zero targeted heads,
    and reshape back.
    """
    if not heads_to_zero:
        yield
        return

    # Build per-layer head sets
    heads_by_layer: dict[int, set[int]] = {}
    for h in heads_to_zero:
        heads_by_layer.setdefault(h.layer, set()).add(h.head)

    handles: list[torch.utils.hooks.RemovableHandle] = []
    config = model.config
    num_query_heads = int(getattr(config, "num_attention_heads"))
    hidden_size = int(getattr(config, "hidden_size"))
    head_dim = hidden_size // num_query_heads

    layers = getattr(getattr(model, "model"), "layers")

    for layer_idx, layer in enumerate(layers):
        if layer_idx not in heads_by_layer:
            continue
        target_heads = heads_by_layer[layer_idx]
        o_proj = layer.self_attn.o_proj

        def make_hook(target_set: set[int], n_heads: int, h_dim: int):
            def hook(module, args):
                x = args[0]  # [batch, seq, hidden]
                batch, seq, hidden = x.shape
                view = x.view(batch, seq, n_heads, h_dim).clone()
                for h_idx in target_set:
                    if h_idx < n_heads:
                        view[:, :, h_idx, :] = 0.0
                return (view.reshape(batch, seq, hidden),) + args[1:]
            return hook

        handle = o_proj.register_forward_pre_hook(
            make_hook(target_heads, num_query_heads, head_dim),
            with_kwargs=False,
        )
        handles.append(handle)

    try:
        yield
    finally:
        for h in handles:
            h.remove()


# ═══════════════════════════════════════════════════════════════════════════════
# INDUCTION SEQUENCE GENERATION (reused from 3.2a)
# ═══════════════════════════════════════════════════════════════════════════════

def generate_repeated_random_sequence(
    vocab_size: int,
    period: int,
    total_len: int,
    seed: int,
    special_ids: set[int],
) -> list[int]:
    """Generate a token sequence [A1..Ap A1..Ap ...] with random tokens."""
    rng = np.random.RandomState(seed)
    pool = [t for t in range(vocab_size) if t not in special_ids]
    base = rng.choice(pool, size=period, replace=True).tolist()
    n_repeats = (total_len // period) + 1
    full = (base * n_repeats)[:total_len]
    return full


# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 1: LOAD EXISTING DATA
# ═══════════════════════════════════════════════════════════════════════════════

def load_induction_scores(model_name: str) -> pd.DataFrame:
    """Load induction scores from Experiment 3.2a."""
    path = Path("results/experiment3/induction_r2_crossref") / model_name / "induction_scores.parquet"
    if not path.exists():
        raise FileNotFoundError(
            f"Induction scores not found at {path}. "
            f"Run experiment3_induction_r2_crossref.py first."
        )
    df = pd.read_parquet(path)
    print(f"  Loaded induction scores: {len(df)} heads from {path}")
    return df


def load_r2_data(model_name: str) -> pd.DataFrame:
    """Load per-sequence R² data from Experiment 3.1."""
    path = Path("results/experiment3/theory1_si_circuits") / model_name / "per_sequence_r2.parquet"
    if not path.exists():
        raise FileNotFoundError(
            f"R² data not found at {path}. "
            f"Run experiment3_theory1_si_circuits.py first."
        )
    df = pd.read_parquet(path)
    mean_r2 = df.groupby(["layer", "head"])["r2"].mean().reset_index()
    mean_r2.columns = ["layer", "head", "mean_r2"]
    print(f"  Loaded R² data: {len(mean_r2)} heads from {path}")
    return mean_r2


def get_top_induction_heads(induction_df: pd.DataFrame, n: int) -> list[HeadID]:
    """Return the top-n induction heads sorted by induction score (descending)."""
    top = induction_df.sort_values("induction_score", ascending=False).head(n)
    heads = [HeadID(int(r.layer), int(r.head)) for r in top.itertuples()]
    return heads


# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 2: PREVIOUS-TOKEN SCORING (Approach A)
# ═══════════════════════════════════════════════════════════════════════════════

def load_wiki_sequences(model_name: str, num_sequences: int, seq_len: int) -> list[list[int]]:
    """Load tokenized wiki sequences for previous-token scoring."""
    data_dir = Path("data/experiment1/wiki40b_en_pre2019") / model_name
    candidates = sorted(data_dir.rglob("*.jsonl"))
    if not candidates:
        raise FileNotFoundError(f"No tokenized JSONL found in {data_dir}")

    sequences: list[list[int]] = []
    for jsonl_path in candidates:
        with open(jsonl_path) as f:
            for line in f:
                row = json.loads(line)
                tokens = row.get("tokens", row.get("input_ids", []))
                if len(tokens) >= seq_len:
                    sequences.append(tokens[:seq_len])
                if len(sequences) >= num_sequences:
                    break
        if len(sequences) >= num_sequences:
            break

    if len(sequences) < num_sequences:
        print(f"  WARNING: Only found {len(sequences)} sequences (wanted {num_sequences})")
    return sequences


def compute_previous_token_scores(
    model,
    adapter,
    model_spec: ModelSpec,
    device: str,
    sequences: list[list[int]],
) -> pd.DataFrame:
    """Compute per-(layer, head) previous-token attention score on wiki sequences.

    The previous-token score measures how much each head attends to position (i-1),
    the token immediately preceding the query position.  A head with a high
    previous-token score is likely performing a "copy previous token" or
    "shift-by-one" operation, which is a key component of induction circuits.

    For each head, the score is:
        mean over positions i in [1, seq_len) of attn[i, i-1]
    averaged across all sequences.
    """
    all_scores: dict[tuple[int, int], list[float]] = {}
    n_seq = len(sequences)

    for seq_idx, tokens in enumerate(sequences):
        t0 = time.time()
        input_ids = torch.tensor([tokens], dtype=torch.long, device=device)

        capture = adapter.capture(
            model,
            input_ids=input_ids,
            include_logits=True,
            return_token_logits=False,
            capture_attention=True,
            output_device="cpu",
        )

        if capture.logits is None:
            print(f"  Seq {seq_idx}: no logits captured, skipping")
            continue

        # capture.logits: [layers, heads, seq, seq]
        n_layers, n_heads, seq_len, _ = capture.logits.shape

        # Apply causal mask and softmax to get attention weights
        causal_mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()
        logits_masked = capture.logits.clone()
        logits_masked[:, :, :, :][..., causal_mask] = float('-inf')
        attn_weights = torch.softmax(logits_masked, dim=-1)  # [layers, heads, seq, seq]

        # Compute previous-token score: mean attn[i, i-1] for i in [1, seq_len)
        for layer_idx in range(n_layers):
            for head_idx in range(n_heads):
                attn = attn_weights[layer_idx, head_idx]  # [seq, seq]
                # Gather attention at offset=-1: attn[i, i-1] for i=1..seq_len-1
                query_positions = torch.arange(1, seq_len)
                key_positions = query_positions - 1
                prev_token_attn = attn[query_positions, key_positions]
                score = prev_token_attn.mean().item()
                all_scores.setdefault((layer_idx, head_idx), []).append(score)

        elapsed = time.time() - t0
        if (seq_idx + 1) % 5 == 0 or seq_idx == 0:
            print(f"  Previous-token scoring: {seq_idx + 1}/{n_seq} sequences ({elapsed:.1f}s)")

        del capture, input_ids, logits_masked, attn_weights
        torch.cuda.empty_cache()

    # Average across sequences
    rows = []
    for (layer, head), scores in all_scores.items():
        rows.append({
            "layer": layer,
            "head": head,
            "prev_token_score": np.mean(scores),
            "prev_token_std": np.std(scores),
            "n_sequences": len(scores),
        })

    return pd.DataFrame(rows)


# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 3: CROSS-REFERENCE (Approach A)
# ═══════════════════════════════════════════════════════════════════════════════

def cross_reference_prev_token_r2(
    prev_token_df: pd.DataFrame,
    r2_df: pd.DataFrame,
    model_name: str,
) -> tuple[dict[str, Any], pd.DataFrame]:
    """Correlate previous-token scores with R², focusing on early layers."""
    from scipy.stats import pearsonr, spearmanr

    merged = pd.merge(
        prev_token_df[["layer", "head", "prev_token_score", "prev_token_std"]],
        r2_df[["layer", "head", "mean_r2"]],
        on=["layer", "head"],
        how="inner",
    )

    # ── Global correlation ──
    r_pearson, p_pearson = pearsonr(merged["mean_r2"], merged["prev_token_score"])
    r_spearman, p_spearman = spearmanr(merged["mean_r2"], merged["prev_token_score"])

    # ── Early-layer analysis (L0-L3) ──
    early = merged[merged["layer"] <= 3].copy()
    if len(early) >= 3:
        r_early_pearson, p_early_pearson = pearsonr(early["mean_r2"], early["prev_token_score"])
        r_early_spearman, p_early_spearman = spearmanr(early["mean_r2"], early["prev_token_score"])
    else:
        r_early_pearson, p_early_pearson = float('nan'), float('nan')
        r_early_spearman, p_early_spearman = float('nan'), float('nan')

    # ── Identify strong previous-token heads ──
    pt_p90 = merged["prev_token_score"].quantile(0.90)
    strong_pt = merged[merged["prev_token_score"] >= pt_p90].copy()

    # ── Identify strong previous-token heads in early layers ──
    early_strong_pt = early[early["prev_token_score"] >= pt_p90].copy() if len(early) > 0 else pd.DataFrame()

    # ── Top previous-token heads by score (all layers) ──
    top_pt_heads = merged.sort_values("prev_token_score", ascending=False).head(20)

    # ── R² quartile analysis for previous-token heads ──
    r2_p75 = merged["mean_r2"].quantile(0.75)
    r2_p25 = merged["mean_r2"].quantile(0.25)
    high_r2_heads = merged[merged["mean_r2"] >= r2_p75]
    low_r2_heads = merged[merged["mean_r2"] <= r2_p25]

    analysis = {
        "model": model_name,
        "n_heads_total": len(merged),
        "global_correlation": {
            "pearson_r": float(r_pearson),
            "pearson_p": float(p_pearson),
            "spearman_r": float(r_spearman),
            "spearman_p": float(p_spearman),
        },
        "early_layer_correlation": {
            "layers": "0-3",
            "n_heads": len(early),
            "pearson_r": float(r_early_pearson),
            "pearson_p": float(p_early_pearson),
            "spearman_r": float(r_early_spearman),
            "spearman_p": float(p_early_spearman),
        },
        "strong_prev_token_heads": {
            "threshold_p90": float(pt_p90),
            "count": len(strong_pt),
            "mean_r2": float(strong_pt["mean_r2"].mean()) if len(strong_pt) > 0 else 0.0,
            "std_r2": float(strong_pt["mean_r2"].std()) if len(strong_pt) > 0 else 0.0,
            "mean_layer": float(strong_pt["layer"].mean()) if len(strong_pt) > 0 else 0.0,
            "heads": [
                {"layer": int(r.layer), "head": int(r.head),
                 "prev_token_score": float(r.prev_token_score),
                 "r2": float(r.mean_r2)}
                for r in strong_pt.sort_values("prev_token_score", ascending=False).itertuples()
            ],
        },
        "early_layer_strong_pt": {
            "count": len(early_strong_pt),
            "mean_r2": float(early_strong_pt["mean_r2"].mean()) if len(early_strong_pt) > 0 else 0.0,
            "heads": [
                {"layer": int(r.layer), "head": int(r.head),
                 "prev_token_score": float(r.prev_token_score),
                 "r2": float(r.mean_r2)}
                for r in early_strong_pt.sort_values("prev_token_score", ascending=False).itertuples()
            ] if len(early_strong_pt) > 0 else [],
        },
        "high_r2_heads_prev_token": {
            "r2_threshold_p75": float(r2_p75),
            "count": len(high_r2_heads),
            "mean_prev_token_score": float(high_r2_heads["prev_token_score"].mean()),
            "std_prev_token_score": float(high_r2_heads["prev_token_score"].std()),
        },
        "low_r2_heads_prev_token": {
            "r2_threshold_p25": float(r2_p25),
            "count": len(low_r2_heads),
            "mean_prev_token_score": float(low_r2_heads["prev_token_score"].mean()),
            "std_prev_token_score": float(low_r2_heads["prev_token_score"].std()),
        },
        "top_20_prev_token_heads": [
            {"layer": int(r.layer), "head": int(r.head),
             "prev_token_score": float(r.prev_token_score),
             "r2": float(r.mean_r2)}
            for r in top_pt_heads.itertuples()
        ],
    }

    return analysis, merged


# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 4: KNOCKOUT ANALYSIS (Approach B)
# ═══════════════════════════════════════════════════════════════════════════════

def compute_induction_score_single(
    attn_weights: torch.Tensor,
    layer_idx: int,
    head_idx: int,
    period: int,
) -> float:
    """Compute induction score for a single (layer, head) from attention weights.

    attn_weights: [layers, heads, seq, seq] — already softmaxed.
    Returns mean attention at offset=period in the repeated portion.
    """
    attn = attn_weights[layer_idx, head_idx]  # [seq, seq]
    seq_len = attn.shape[0]
    scores = []
    for i in range(period, min(seq_len, 2 * period)):
        target_pos = i - period + 1
        if 0 <= target_pos < seq_len:
            scores.append(attn[i, target_pos].item())
    if not scores:
        return 0.0
    return float(np.mean(scores))


def run_knockout_analysis(
    model,
    adapter,
    tokenizer,
    model_spec: ModelSpec,
    device: str,
    induction_heads: list[HeadID],
    r2_df: pd.DataFrame,
    num_sequences: int,
    period: int,
    total_len: int,
) -> tuple[dict[str, Any], pd.DataFrame]:
    """For each top induction head, ablate candidate early-layer feeders and
    measure the change in induction score.

    Returns analysis dict and a DataFrame of per-knockout results.
    """
    vocab_size = tokenizer.vocab_size
    special_ids = set()
    for attr in ("bos_token_id", "eos_token_id", "pad_token_id", "unk_token_id"):
        sid = getattr(tokenizer, attr, None)
        if sid is not None:
            special_ids.add(sid)

    config = model.config
    num_query_heads = int(getattr(config, "num_attention_heads"))

    # Build lookup for R² values
    r2_lookup: dict[tuple[int, int], float] = {}
    for r in r2_df.itertuples():
        r2_lookup[(int(r.layer), int(r.head))] = float(r.mean_r2)

    # Pre-generate all repeated random sequences
    all_tokens: list[list[int]] = []
    for seq_idx in range(num_sequences):
        tokens = generate_repeated_random_sequence(
            vocab_size=vocab_size,
            period=period,
            total_len=total_len,
            seed=seq_idx * 13 + 777,
            special_ids=special_ids,
        )
        all_tokens.append(tokens)

    knockout_rows: list[dict[str, Any]] = []
    all_feeder_results: list[dict[str, Any]] = []

    for ind_idx, ind_head in enumerate(induction_heads):
        t0 = time.time()
        max_feeder_layer = min(ind_head.layer - 1, MAX_FEEDER_LAYER)
        if max_feeder_layer < 0:
            print(f"  Induction head {ind_head}: layer 0, no feeders to test. Skipping.")
            continue

        # Build list of candidate feeder heads
        candidate_feeders: list[HeadID] = []
        for l in range(max_feeder_layer + 1):
            for h in range(num_query_heads):
                candidate_feeders.append(HeadID(l, h))

        print(f"\n  Knockout {ind_idx + 1}/{len(induction_heads)}: "
              f"induction head {ind_head}, testing {len(candidate_feeders)} candidate feeders "
              f"(layers 0-{max_feeder_layer})...")

        # Step 1: Compute baseline induction score (no ablation)
        baseline_scores: list[float] = []
        for seq_idx, tokens in enumerate(all_tokens):
            input_ids = torch.tensor([tokens], dtype=torch.long, device=device)
            with torch.no_grad():
                capture = adapter.capture(
                    model,
                    input_ids=input_ids,
                    include_logits=True,
                    return_token_logits=False,
                    capture_attention=True,
                    output_device="cpu",
                )
            if capture.logits is None:
                continue
            n_layers, n_heads, seq_len, _ = capture.logits.shape
            causal_mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()
            logits_masked = capture.logits.clone()
            logits_masked[:, :, :, :][..., causal_mask] = float('-inf')
            attn_weights = torch.softmax(logits_masked, dim=-1)

            score = compute_induction_score_single(
                attn_weights, ind_head.layer, ind_head.head, period
            )
            baseline_scores.append(score)
            del capture, input_ids, logits_masked, attn_weights
            torch.cuda.empty_cache()

        baseline_mean = float(np.mean(baseline_scores))
        baseline_std = float(np.std(baseline_scores))
        print(f"    Baseline induction score: {baseline_mean:.4f} +/- {baseline_std:.4f}")

        # Step 2: For each candidate feeder, ablate and re-measure
        feeder_deltas: list[dict[str, Any]] = []

        for feeder in candidate_feeders:
            ablated_scores: list[float] = []
            for seq_idx, tokens in enumerate(all_tokens):
                input_ids = torch.tensor([tokens], dtype=torch.long, device=device)
                with head_output_ablation(model, [feeder]):
                    with torch.no_grad():
                        capture = adapter.capture(
                            model,
                            input_ids=input_ids,
                            include_logits=True,
                            return_token_logits=False,
                            capture_attention=True,
                            output_device="cpu",
                        )
                if capture.logits is None:
                    continue
                n_layers, n_heads, seq_len, _ = capture.logits.shape
                causal_mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()
                logits_masked = capture.logits.clone()
                logits_masked[:, :, :, :][..., causal_mask] = float('-inf')
                attn_weights = torch.softmax(logits_masked, dim=-1)

                score = compute_induction_score_single(
                    attn_weights, ind_head.layer, ind_head.head, period
                )
                ablated_scores.append(score)
                del capture, input_ids, logits_masked, attn_weights
                torch.cuda.empty_cache()

            if not ablated_scores:
                continue

            ablated_mean = float(np.mean(ablated_scores))
            delta = baseline_mean - ablated_mean  # positive = feeder helped induction
            feeder_r2 = r2_lookup.get((feeder.layer, feeder.head), float('nan'))

            feeder_entry = {
                "induction_layer": ind_head.layer,
                "induction_head": ind_head.head,
                "feeder_layer": feeder.layer,
                "feeder_head": feeder.head,
                "baseline_induction_score": baseline_mean,
                "ablated_induction_score": ablated_mean,
                "delta_induction_score": delta,
                "feeder_r2": feeder_r2,
            }
            feeder_deltas.append(feeder_entry)
            knockout_rows.append(feeder_entry)

        # Sort feeders by delta (descending) and report top-5
        feeder_deltas.sort(key=lambda x: x["delta_induction_score"], reverse=True)
        top_feeders = feeder_deltas[:TOP_FEEDERS_PER_HEAD]

        elapsed = time.time() - t0
        print(f"    Top-{TOP_FEEDERS_PER_HEAD} feeders (by induction score drop when ablated):")
        for f in top_feeders:
            print(f"      L{f['feeder_layer']:2d} H{f['feeder_head']:2d}  "
                  f"delta={f['delta_induction_score']:+.4f}  "
                  f"R²={f['feeder_r2']:.4f}")
        print(f"    Knockout for {ind_head} complete in {elapsed:.0f}s")

        all_feeder_results.append({
            "induction_head": repr(ind_head),
            "induction_layer": ind_head.layer,
            "induction_head_idx": ind_head.head,
            "baseline_induction_score": baseline_mean,
            "baseline_induction_std": baseline_std,
            "n_candidate_feeders": len(candidate_feeders),
            "top_feeders": top_feeders,
        })

    knockout_df = pd.DataFrame(knockout_rows)

    # Aggregate: are the strongest feeders high-R² heads?
    analysis = build_knockout_analysis(knockout_df, all_feeder_results, r2_df)
    return analysis, knockout_df


def build_knockout_analysis(
    knockout_df: pd.DataFrame,
    feeder_results: list[dict[str, Any]],
    r2_df: pd.DataFrame,
) -> dict[str, Any]:
    """Build summary analysis of knockout results."""
    from scipy.stats import pearsonr, spearmanr

    if knockout_df.empty:
        return {"error": "No knockout data produced"}

    # Overall correlation: feeder delta vs feeder R²
    valid = knockout_df.dropna(subset=["feeder_r2"])
    if len(valid) >= 3:
        r_pearson, p_pearson = pearsonr(valid["feeder_r2"], valid["delta_induction_score"])
        r_spearman, p_spearman = spearmanr(valid["feeder_r2"], valid["delta_induction_score"])
    else:
        r_pearson, p_pearson = float('nan'), float('nan')
        r_spearman, p_spearman = float('nan'), float('nan')

    # Top feeders analysis: for each induction head, look at top-5 feeders' R²
    top_feeder_r2s: list[float] = []
    for result in feeder_results:
        for f in result["top_feeders"]:
            if not np.isnan(f["feeder_r2"]):
                top_feeder_r2s.append(f["feeder_r2"])

    # Compare top-feeder R² to overall R² distribution
    all_r2 = r2_df["mean_r2"].values
    overall_r2_mean = float(np.mean(all_r2))
    overall_r2_median = float(np.median(all_r2))

    top_feeder_r2_mean = float(np.mean(top_feeder_r2s)) if top_feeder_r2s else float('nan')
    top_feeder_r2_median = float(np.median(top_feeder_r2s)) if top_feeder_r2s else float('nan')

    # Fraction of top feeders above R² median
    n_above_median = sum(1 for r in top_feeder_r2s if r >= overall_r2_median)
    frac_above_median = n_above_median / len(top_feeder_r2s) if top_feeder_r2s else float('nan')

    # R² quartile distribution of top feeders
    r2_p25 = float(np.percentile(all_r2, 25))
    r2_p50 = float(np.percentile(all_r2, 50))
    r2_p75 = float(np.percentile(all_r2, 75))

    n_q1 = sum(1 for r in top_feeder_r2s if r < r2_p25)
    n_q2 = sum(1 for r in top_feeder_r2s if r2_p25 <= r < r2_p50)
    n_q3 = sum(1 for r in top_feeder_r2s if r2_p50 <= r < r2_p75)
    n_q4 = sum(1 for r in top_feeder_r2s if r >= r2_p75)
    n_total = len(top_feeder_r2s)

    # Layer distribution of top feeders
    top_feeder_layers: list[int] = []
    for result in feeder_results:
        for f in result["top_feeders"]:
            top_feeder_layers.append(f["feeder_layer"])

    analysis = {
        "delta_vs_r2_correlation": {
            "description": "Correlation between feeder ablation delta and feeder R²",
            "n_knockouts": len(valid),
            "pearson_r": float(r_pearson),
            "pearson_p": float(p_pearson),
            "spearman_r": float(r_spearman),
            "spearman_p": float(p_spearman),
        },
        "top_feeder_r2_distribution": {
            "description": "R² distribution of top-5 feeders per induction head",
            "n_top_feeders": n_total,
            "mean_r2": top_feeder_r2_mean,
            "median_r2": top_feeder_r2_median,
            "overall_mean_r2": overall_r2_mean,
            "overall_median_r2": overall_r2_median,
            "fraction_above_overall_median": float(frac_above_median),
            "r2_quartile_distribution": {
                "Q1_below_p25": n_q1,
                "Q2_p25_to_p50": n_q2,
                "Q3_p50_to_p75": n_q3,
                "Q4_above_p75": n_q4,
            },
            "feeders_concentrated_in_high_si": bool(frac_above_median > 0.5) if not np.isnan(frac_above_median) else False,
        },
        "top_feeder_layer_distribution": {
            "mean_layer": float(np.mean(top_feeder_layers)) if top_feeder_layers else float('nan'),
            "median_layer": float(np.median(top_feeder_layers)) if top_feeder_layers else float('nan'),
            "layer_counts": {
                int(l): int(c) for l, c in
                zip(*np.unique(top_feeder_layers, return_counts=True))
            } if top_feeder_layers else {},
        },
        "per_induction_head_results": feeder_results,
    }

    return analysis


# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 5: UNIFIED ANALYSIS AND REPORT
# ═══════════════════════════════════════════════════════════════════════════════

def build_unified_analysis(
    approach_a_analysis: dict[str, Any],
    approach_b_analysis: dict[str, Any],
    induction_df: pd.DataFrame,
    r2_df: pd.DataFrame,
    model_name: str,
) -> dict[str, Any]:
    """Combine Approach A and Approach B into a unified conclusion."""
    from scipy.stats import spearmanr

    # Merge induction scores with R² for context
    merged = pd.merge(
        induction_df[["layer", "head", "induction_score"]],
        r2_df[["layer", "head", "mean_r2"]],
        on=["layer", "head"],
        how="inner",
    )

    # Induction-R² anti-correlation (for reference)
    r_ind_r2, p_ind_r2 = spearmanr(merged["mean_r2"], merged["induction_score"])

    # Approach A verdict
    a_global = approach_a_analysis.get("global_correlation", {})
    a_early = approach_a_analysis.get("early_layer_correlation", {})
    a_strong = approach_a_analysis.get("strong_prev_token_heads", {})
    a_high_r2 = approach_a_analysis.get("high_r2_heads_prev_token", {})

    # Approach B verdict
    b_delta_corr = approach_b_analysis.get("delta_vs_r2_correlation", {})
    b_top_feeder = approach_b_analysis.get("top_feeder_r2_distribution", {})

    # Determine overall verdict
    feeder_si_support_a = (
        a_strong.get("mean_r2", 0.0) > r2_df["mean_r2"].median()
        if a_strong.get("count", 0) > 0 else False
    )
    feeder_si_support_b = b_top_feeder.get("feeders_concentrated_in_high_si", False)

    unified = {
        "model": model_name,
        "reference_induction_r2_anticorrelation": {
            "spearman_r": float(r_ind_r2),
            "spearman_p": float(p_ind_r2),
        },
        "approach_a_verdict": {
            "description": "Do previous-token heads (key feeder type) have high R²?",
            "prev_token_r2_correlation_global": a_global,
            "prev_token_r2_correlation_early_layers": a_early,
            "strong_prev_token_heads_have_high_r2": feeder_si_support_a,
            "strong_pt_mean_r2": a_strong.get("mean_r2", float('nan')),
            "overall_median_r2": float(r2_df["mean_r2"].median()),
            "high_r2_heads_mean_pt_score": a_high_r2.get("mean_prev_token_score", float('nan')),
        },
        "approach_b_verdict": {
            "description": "Are causally identified feeder heads concentrated among high-SI heads?",
            "delta_r2_correlation": b_delta_corr,
            "top_feeders_have_high_r2": feeder_si_support_b,
            "top_feeder_mean_r2": b_top_feeder.get("mean_r2", float('nan')),
            "top_feeder_frac_above_median": b_top_feeder.get("fraction_above_overall_median", float('nan')),
        },
        "overall_conclusion": {
            "feeder_heads_support_si_hypothesis": feeder_si_support_a or feeder_si_support_b,
            "approach_a_supports": feeder_si_support_a,
            "approach_b_supports": feeder_si_support_b,
            "interpretation": (
                "The feeder-head hypothesis is SUPPORTED: induction circuit feeders "
                "tend to be high-SI heads, resolving the apparent anti-correlation "
                "between induction score and R²."
                if (feeder_si_support_a or feeder_si_support_b)
                else
                "The feeder-head hypothesis is NOT SUPPORTED: induction circuit feeders "
                "do not show a clear concentration among high-SI heads. The anti-correlation "
                "between induction score and R² remains unexplained by this mechanism."
            ),
        },
    }

    return unified


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Experiment 3 Theory 7: Induction circuit tracing — do feeder heads have high SI?"
    )
    parser.add_argument("--model", required=True, choices=list(MODELS.keys()))
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output-dir", default="results/experiment3/theory7_induction_feeders")
    parser.add_argument("--num-wiki-sequences", type=int, default=NUM_WIKI_SEQUENCES)
    parser.add_argument("--num-knockout-sequences", type=int, default=NUM_KNOCKOUT_SEQUENCES)
    parser.add_argument("--skip-approach-a", action="store_true",
                        help="Skip Approach A (previous-token scoring); load saved data")
    parser.add_argument("--skip-approach-b", action="store_true",
                        help="Skip Approach B (knockout analysis); load saved data")
    args = parser.parse_args()

    output_dir = Path(args.output_dir) / args.model
    output_dir.mkdir(parents=True, exist_ok=True)
    model_spec = MODELS[args.model]

    print(f"{'=' * 72}")
    print(f"Experiment 3 Theory 7: Induction Feeder Analysis — {args.model}")
    print(f"Device: {args.device}")
    print(f"Output: {output_dir}")
    print(f"{'=' * 72}")

    # ── Load model ───────────────────────────────────────────────────────────
    print("\n[1/7] Loading model and tokenizer...")
    from shared.models.loading import load_model, load_tokenizer

    loader = load_model(model_spec)
    model = loader.model.to(args.device)
    model.eval()
    tokenizer = load_tokenizer(model_spec)
    adapter = get_adapter(model_spec)
    adapter.register(model)
    print(f"  Model loaded: {model_spec.hf_id}")
    print(f"  Config: {model.config.num_hidden_layers} layers, "
          f"{model.config.num_attention_heads} query heads, "
          f"head_dim={model.config.hidden_size // model.config.num_attention_heads}")

    # ═════════════════════════════════════════════════════════════════════════
    # PHASE 1: Load existing data
    # ═════════════════════════════════════════════════════════════════════════
    print(f"\n[2/7] Phase 1: Loading existing data (induction scores + R²)...")

    induction_df = load_induction_scores(args.model)
    r2_df = load_r2_data(args.model)

    # Get top induction heads
    top_induction = get_top_induction_heads(induction_df, TOP_INDUCTION_HEADS)
    print(f"\n  Top {TOP_INDUCTION_HEADS} induction heads:")
    for i, h in enumerate(top_induction):
        ind_score = induction_df[
            (induction_df["layer"] == h.layer) & (induction_df["head"] == h.head)
        ]["induction_score"].values[0]
        r2_val = r2_df[
            (r2_df["layer"] == h.layer) & (r2_df["head"] == h.head)
        ]["mean_r2"].values
        r2_str = f"{r2_val[0]:.4f}" if len(r2_val) > 0 else "N/A"
        print(f"    {i + 1:2d}. {h}  induction={ind_score:.4f}  R²={r2_str}")

    # ═════════════════════════════════════════════════════════════════════════
    # PHASE 2: Previous-token scoring (Approach A)
    # ═════════════════════════════════════════════════════════════════════════
    prev_token_parquet = output_dir / "prev_token_scores.parquet"
    if args.skip_approach_a and prev_token_parquet.exists():
        print(f"\n[3/7] Phase 2: SKIPPED (loading saved data from {prev_token_parquet})")
        prev_token_df = pd.read_parquet(prev_token_parquet)
        print(f"  Loaded {len(prev_token_df)} per-head previous-token scores")
    else:
        print(f"\n[3/7] Phase 2: Computing previous-token scores "
              f"({args.num_wiki_sequences} wiki sequences)...")
        t0 = time.time()
        wiki_sequences = load_wiki_sequences(args.model, args.num_wiki_sequences, WIKI_SEQ_LEN)
        prev_token_df = compute_previous_token_scores(
            model=model,
            adapter=adapter,
            model_spec=model_spec,
            device=args.device,
            sequences=wiki_sequences,
        )
        elapsed = time.time() - t0
        prev_token_df.to_parquet(prev_token_parquet, index=False)
        print(f"  Previous-token scoring complete: {len(prev_token_df)} heads in {elapsed:.1f}s")
        print(f"  Saved to {prev_token_parquet}")

    # ═════════════════════════════════════════════════════════════════════════
    # PHASE 3: Cross-reference (Approach A)
    # ═════════════════════════════════════════════════════════════════════════
    print(f"\n[4/7] Phase 3: Cross-referencing previous-token scores with R²...")
    approach_a_analysis, merged_a_df = cross_reference_prev_token_r2(
        prev_token_df, r2_df, args.model
    )
    merged_a_df.to_parquet(output_dir / "merged_prev_token_r2.parquet", index=False)

    print(f"\n  Approach A Results:")
    gc = approach_a_analysis["global_correlation"]
    print(f"    Global correlation (prev_token vs R²):")
    print(f"      Pearson:  r={gc['pearson_r']:+.4f}  p={gc['pearson_p']:.2e}")
    print(f"      Spearman: r={gc['spearman_r']:+.4f}  p={gc['spearman_p']:.2e}")

    ec = approach_a_analysis["early_layer_correlation"]
    print(f"    Early-layer correlation (L0-L3, n={ec['n_heads']}):")
    print(f"      Pearson:  r={ec['pearson_r']:+.4f}  p={ec['pearson_p']:.2e}")
    print(f"      Spearman: r={ec['spearman_r']:+.4f}  p={ec['spearman_p']:.2e}")

    spt = approach_a_analysis["strong_prev_token_heads"]
    print(f"    Strong previous-token heads (top 10%, n={spt['count']}):")
    print(f"      Mean R²={spt['mean_r2']:.4f} +/- {spt['std_r2']:.4f}, "
          f"mean layer={spt['mean_layer']:.1f}")
    for h in spt["heads"][:10]:
        print(f"        L{h['layer']:2d} H{h['head']:2d}  "
              f"prev_token={h['prev_token_score']:.4f}  R²={h['r2']:.4f}")

    hr2 = approach_a_analysis["high_r2_heads_prev_token"]
    lr2 = approach_a_analysis["low_r2_heads_prev_token"]
    print(f"    High-R² heads (top 25%): mean prev_token_score={hr2['mean_prev_token_score']:.4f}")
    print(f"    Low-R²  heads (bot 25%): mean prev_token_score={lr2['mean_prev_token_score']:.4f}")

    # ═════════════════════════════════════════════════════════════════════════
    # PHASE 4: Knockout analysis (Approach B)
    # ═════════════════════════════════════════════════════════════════════════
    knockout_parquet = output_dir / "knockout_results.parquet"
    knockout_analysis_path = output_dir / "approach_b_analysis.json"
    if args.skip_approach_b:
        if knockout_parquet.exists():
            print(f"\n[5/7] Phase 4: SKIPPED (loading saved data from {knockout_parquet})")
            knockout_df = pd.read_parquet(knockout_parquet)
            # Reload analysis from JSON if available; otherwise emit a structured skipped payload.
            if knockout_analysis_path.exists():
                approach_b_analysis = json.loads(knockout_analysis_path.read_text(encoding="utf-8"))
            else:
                approach_b_analysis = {
                    "status": "skipped_loaded_cached_rows_no_cached_analysis_json",
                    "delta_vs_r2_correlation": {},
                    "top_feeder_r2_distribution": {
                        "feeders_concentrated_in_high_si": False,
                        "note": "cached knockout rows were loaded but cached analysis json was missing",
                    },
                    "top_feeder_layer_distribution": {},
                    "per_induction_head_results": [],
                    "n_knockout_rows": int(len(knockout_df)),
                }
            print(f"  Loaded {len(knockout_df)} knockout result rows")
        else:
            print("\n[5/7] Phase 4: SKIPPED by --skip-approach-b (no cached knockout rows found)")
            knockout_df = pd.DataFrame(
                columns=[
                    "induction_layer",
                    "induction_head",
                    "feeder_layer",
                    "feeder_head",
                    "baseline_induction_score",
                    "ablated_induction_score",
                    "delta_induction_score",
                    "feeder_r2",
                ]
            )
            approach_b_analysis = {
                "status": "skipped_by_flag_no_cached_knockout",
                "delta_vs_r2_correlation": {},
                "top_feeder_r2_distribution": {
                    "feeders_concentrated_in_high_si": False,
                    "note": "Approach B was not executed because --skip-approach-b was set and no cached rows were found.",
                },
                "top_feeder_layer_distribution": {},
                "per_induction_head_results": [],
                "n_knockout_rows": 0,
            }
            knockout_analysis_path.write_text(
                json.dumps(approach_b_analysis, indent=2, default=str), encoding="utf-8"
            )
    else:
        print(f"\n[5/7] Phase 4: Knockout analysis (Approach B) — "
              f"{TOP_INDUCTION_FOR_KNOCKOUT} induction heads, "
              f"{args.num_knockout_sequences} sequences each...")
        t0 = time.time()
        top_for_knockout = top_induction[:TOP_INDUCTION_FOR_KNOCKOUT]
        approach_b_analysis, knockout_df = run_knockout_analysis(
            model=model,
            adapter=adapter,
            tokenizer=tokenizer,
            model_spec=model_spec,
            device=args.device,
            induction_heads=top_for_knockout,
            r2_df=r2_df,
            num_sequences=args.num_knockout_sequences,
            period=KNOCKOUT_PERIOD,
            total_len=KNOCKOUT_SEQ_LEN,
        )
        elapsed = time.time() - t0
        knockout_df.to_parquet(knockout_parquet, index=False)
        knockout_analysis_path.write_text(
            json.dumps(approach_b_analysis, indent=2, default=str), encoding="utf-8"
        )
        print(f"\n  Knockout analysis complete in {elapsed:.0f}s")
        print(f"  Saved {len(knockout_df)} knockout rows to {knockout_parquet}")

    # Print Approach B summary
    print(f"\n  Approach B Results:")
    dc = approach_b_analysis.get("delta_vs_r2_correlation", {})
    if dc:
        print(f"    Delta vs R² correlation (all knockouts):")
        print(f"      Pearson:  r={dc.get('pearson_r', 'N/A')}  p={dc.get('pearson_p', 'N/A')}")
        print(f"      Spearman: r={dc.get('spearman_r', 'N/A')}  p={dc.get('spearman_p', 'N/A')}")

    tf = approach_b_analysis.get("top_feeder_r2_distribution", {})
    if tf:
        print(f"    Top-feeder R² distribution (n={tf.get('n_top_feeders', 0)}):")
        print(f"      Mean R²:     {tf.get('mean_r2', 'N/A')}")
        print(f"      Median R²:   {tf.get('median_r2', 'N/A')}")
        print(f"      Overall median R²: {tf.get('overall_median_r2', 'N/A')}")
        print(f"      Frac above median: {tf.get('fraction_above_overall_median', 'N/A')}")
        qd = tf.get("r2_quartile_distribution", {})
        if qd:
            print(f"      R² quartile distribution: "
                  f"Q1={qd.get('Q1_below_p25', 0)} "
                  f"Q2={qd.get('Q2_p25_to_p50', 0)} "
                  f"Q3={qd.get('Q3_p50_to_p75', 0)} "
                  f"Q4={qd.get('Q4_above_p75', 0)}")
        print(f"      Feeders concentrated in high SI: "
              f"{tf.get('feeders_concentrated_in_high_si', 'N/A')}")

    tl = approach_b_analysis.get("top_feeder_layer_distribution", {})
    if tl:
        print(f"    Top-feeder layer distribution:")
        print(f"      Mean layer: {tl.get('mean_layer', 'N/A')}")
        lc = tl.get("layer_counts", {})
        if lc:
            for layer_idx in sorted(lc.keys(), key=int):
                print(f"        Layer {int(layer_idx):2d}: {lc[layer_idx]} feeders")

    # ═════════════════════════════════════════════════════════════════════════
    # PHASE 5: Unified analysis and report
    # ═════════════════════════════════════════════════════════════════════════
    print(f"\n[6/7] Phase 5: Building unified analysis...")
    unified = build_unified_analysis(
        approach_a_analysis=approach_a_analysis,
        approach_b_analysis=approach_b_analysis,
        induction_df=induction_df,
        r2_df=r2_df,
        model_name=args.model,
    )
    (output_dir / "unified_analysis.json").write_text(
        json.dumps(unified, indent=2, default=str), encoding="utf-8"
    )

    # ── Print final summary ──────────────────────────────────────────────────
    print(f"\n{'=' * 72}")
    print(f"RESULTS SUMMARY — {args.model}")
    print(f"{'=' * 72}")

    ref = unified["reference_induction_r2_anticorrelation"]
    print(f"\n  Reference: induction-R² anti-correlation:")
    print(f"    Spearman rho = {ref['spearman_r']:+.4f}  (p = {ref['spearman_p']:.2e})")

    av = unified["approach_a_verdict"]
    print(f"\n  Approach A (previous-token heads):")
    print(f"    Strong prev-token heads have high R²: {av['strong_prev_token_heads_have_high_r2']}")
    print(f"    Strong PT mean R² = {av['strong_pt_mean_r2']:.4f}  "
          f"(overall median R² = {av['overall_median_r2']:.4f})")
    print(f"    High-R² heads mean PT score = {av['high_r2_heads_mean_pt_score']:.4f}")

    bv = unified["approach_b_verdict"]
    print(f"\n  Approach B (knockout-identified feeders):")
    print(f"    Top feeders have high R²: {bv['top_feeders_have_high_r2']}")
    print(f"    Top feeder mean R² = {bv['top_feeder_mean_r2']}")
    print(f"    Frac above median = {bv['top_feeder_frac_above_median']}")

    oc = unified["overall_conclusion"]
    print(f"\n  OVERALL CONCLUSION:")
    print(f"    Approach A supports: {oc['approach_a_supports']}")
    print(f"    Approach B supports: {oc['approach_b_supports']}")
    print(f"    {oc['interpretation']}")

    # ── Save final report ────────────────────────────────────────────────────
    print(f"\n[7/7] Writing final report...")
    report = {
        "experiment": "3_theory7_induction_feeders",
        "model": args.model,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "config": {
            "num_wiki_sequences": args.num_wiki_sequences,
            "wiki_seq_len": WIKI_SEQ_LEN,
            "num_knockout_sequences": args.num_knockout_sequences,
            "knockout_period": KNOCKOUT_PERIOD,
            "knockout_seq_len": KNOCKOUT_SEQ_LEN,
            "top_induction_heads": TOP_INDUCTION_HEADS,
            "top_induction_for_knockout": TOP_INDUCTION_FOR_KNOCKOUT,
            "max_feeder_layer": MAX_FEEDER_LAYER,
            "top_feeders_per_head": TOP_FEEDERS_PER_HEAD,
        },
        "approach_a_analysis": approach_a_analysis,
        "approach_b_analysis": approach_b_analysis,
        "unified_analysis": unified,
    }
    (output_dir / "report.json").write_text(
        json.dumps(report, indent=2, default=str), encoding="utf-8"
    )
    print(f"  Report saved to {output_dir / 'report.json'}")
    print(f"\nDone. All artifacts in: {output_dir}")


if __name__ == "__main__":
    main()
