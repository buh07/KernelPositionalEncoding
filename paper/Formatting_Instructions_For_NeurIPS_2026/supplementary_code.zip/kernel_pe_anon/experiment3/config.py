from __future__ import annotations

"""Experiment 3 shared configuration.

All theory scripts share the same two 7-8B RoPE models and a common set of
constants.  This module centralises those definitions so individual scripts
can ``from experiment3.config import ...`` instead of duplicating them.
"""

from pathlib import Path

from shared.specs import ModelSpec

# ── Models ────────────────────────────────────────────────────────────────────
MODELS: dict[str, ModelSpec] = {
    "llama-3.1-8b": ModelSpec(
        name="llama-3.1-8b",
        hf_id="meta-llama/Meta-Llama-3.1-8B",
        norm="RMSNorm",
        pe_scheme="RoPE",
        notes="Llama 3.1 8B (GQA: 32Q/8KV heads).",
    ),
    "olmo-2-7b": ModelSpec(
        name="olmo-2-7b",
        hf_id="allenai/OLMo-2-1124-7B",
        norm="LayerNorm",
        pe_scheme="RoPE",
        notes="OLMo 2 7B.",
        download_kwargs=(("torch_dtype", "bfloat16"),),
    ),
}

# ── Paths ─────────────────────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_ROOT = PROJECT_ROOT / "results" / "experiment3"

# ── R² profiling defaults (shared across Theory 1, 3, 5, 5b, 8, crossref) ──
NUM_PROFILE_SEQUENCES = 50
PROFILE_SEQ_LEN = 512
QUARTILE = 0.25  # top/bottom 25 % for head classification

# ── Induction detection defaults (shared across Theory 7, 7b, 10, crossref) ─
NUM_INDUCTION_SEQUENCES = 100
INDUCTION_PERIOD = 32
INDUCTION_SEQ_LEN = 128
TOP_INDUCTION_HEADS = 10

# ── Task battery defaults (Theory 1) ─────────────────────────────────────────
TASK_SEQ_LEN = 512
SYNTHETIC_COUNT = 100
CANDIDATE_SIZE = 10
NUM_SEEDS = 7

# ── Resample patching defaults (Theory 7b, 10) ───────────────────────────────
NUM_SEQUENCE_PAIRS = 30
KNOCKOUT_PERIOD = 32
KNOCKOUT_SEQ_LEN = 128
MAX_SOURCE_LAYER = 7

# ── Bootstrap defaults ────────────────────────────────────────────────────────
BOOTSTRAP_N = 10000
BOOTSTRAP_SEED = 42

# ── Random draws for ablation baselines ───────────────────────────────────────
RANDOM_DRAWS = 3
