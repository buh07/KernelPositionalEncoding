#!/usr/bin/env python3
"""
Experiment 3 Theory 9: Frequency-Band Decomposition of Feeder Effect
=====================================================================

Motivation
----------
Theory 7b (activation patching) found a weak but significant Spearman
rho=+0.206 between source head R^2 and disruption to induction heads.
However, the partial correlation controlling for previous-token score was
near zero (r=0.041), suggesting the feeder effect might be mediated by
previous-token behaviour rather than shift-invariance per se.

Experiment 3.2c showed R^2 correlates with HF fraction at rho=+0.81.
This raises the question: does the high-frequency component of R^2 predict
feeder disruption better than the low-frequency component?

If high-frequency RoPE pairs (local/subword patterns) drive the feeder
effect, that would suggest feeders provide local positional information.
If low-frequency pairs (global position) drive it, the mechanism is
different.

What this script does
---------------------
1. Load existing data (no GPU needed):
   - Theory 7b patching results (per-source-head disruption)
   - Theory 1 R^2 data (per-head shift-invariance)
   - RoPE frequency profiles (per-head HF/LF fractions)
   - Theory 7 previous-token scores

2. For each early-layer head (layers 0-7):
   - Get its mean R^2, HF fraction, LF fraction, disruption, prev-token score

3. Analysis:
   - Correlate disruption with R^2_total, hf_fraction, lf_fraction
   - Partial correlations controlling for confounds
   - Multiple regression: disruption ~ hf_fraction + lf_fraction + prev_token_score
   - Bootstrap CIs for all correlations

4. Output report.json with all results and interpretation.

Usage
-----
    python scripts/experiment3_theory9_freq_band_feeder.py --model olmo-2-7b
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr

# ── project root ────────────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# ── constants ───────────────────────────────────────────────────────────────
MAX_SOURCE_LAYER = 7          # only early-layer heads (layers 0-7)
BOOTSTRAP_N = 10000
BOOTSTRAP_SEED = 42
VALID_MODELS = ["llama-3.1-8b", "olmo-2-7b"]


# =============================================================================
# DATA LOADING
# =============================================================================

def load_patching_results(model_name: str) -> pd.DataFrame:
    """Load Theory 7b activation patching results.

    Returns per-source-head aggregated disruption (mean across target
    induction heads).
    """
    path = PROJECT_ROOT / "results" / "experiment3" / "theory7b_activation_patching" / model_name / "patching_results.parquet"
    if not path.exists():
        raise FileNotFoundError(
            f"Patching results not found: {path}\n"
            f"Run experiment3_theory7b_activation_patching.py --model {model_name} first."
        )
    df = pd.read_parquet(path)
    # Aggregate disruption per source head (mean across target induction heads)
    source_agg = df.groupby(["source_layer", "source_head"]).agg(
        mean_disruption=("mean_disruption", "mean"),
        max_disruption=("mean_disruption", "max"),
        mean_recovery=("mean_recovery", "mean"),
    ).reset_index()
    return source_agg


def load_r2_data(model_name: str) -> pd.DataFrame:
    """Load per-head mean R^2 from Theory 1 SI circuits."""
    path = PROJECT_ROOT / "results" / "experiment3" / "theory1_si_circuits" / model_name / "per_sequence_r2.parquet"
    if not path.exists():
        raise FileNotFoundError(f"R^2 data not found: {path}")
    df = pd.read_parquet(path)
    mean_r2 = df.groupby(["layer", "head"])["r2"].mean().reset_index()
    mean_r2.columns = ["layer", "head", "mean_r2"]
    return mean_r2


def load_freq_profile(model_name: str) -> pd.DataFrame:
    """Load per-head RoPE frequency profile from Experiment 3.2c."""
    path = PROJECT_ROOT / "results" / "experiment3" / "rope_freq_per_head" / model_name / "freq_profile.parquet"
    if not path.exists():
        raise FileNotFoundError(f"Frequency profile not found: {path}")
    df = pd.read_parquet(path)
    return df[["layer", "head", "hf_fraction_top25", "lf_fraction_bottom25",
               "ultra_hf_fraction_top4", "mean_freq_index", "energy_entropy"]]


def load_prev_token_scores(model_name: str) -> pd.DataFrame | None:
    """Load previous-token scores from Theory 7 (Approach A)."""
    path = PROJECT_ROOT / "results" / "experiment3" / "theory7_induction_feeders" / model_name / "prev_token_scores.parquet"
    if not path.exists():
        print(f"  [WARN] Previous-token scores not found: {path}")
        return None
    df = pd.read_parquet(path)
    return df[["layer", "head", "prev_token_score"]]


# =============================================================================
# STATISTICS UTILITIES
# =============================================================================

def partial_correlation(x: np.ndarray, y: np.ndarray, z: np.ndarray,
                        method: str = "spearman") -> tuple[float, float]:
    """Compute partial correlation of x and y controlling for z.

    Uses the standard formula:
        r_xy.z = (r_xy - r_xz * r_yz) / sqrt((1 - r_xz^2) * (1 - r_yz^2))
    """
    corr_fn = spearmanr if method == "spearman" else pearsonr
    r_xy, _ = corr_fn(x, y)
    r_xz, _ = corr_fn(x, z)
    r_yz, _ = corr_fn(y, z)

    denom = np.sqrt((1 - r_xz**2) * (1 - r_yz**2))
    if denom < 1e-12:
        return float("nan"), float("nan")
    r_partial = (r_xy - r_xz * r_yz) / denom

    # Approximate p-value using t-test: t = r * sqrt((n-3)/(1-r^2))
    n = len(x)
    if abs(r_partial) >= 1.0 - 1e-12:
        p_val = 0.0
    else:
        from scipy.stats import t as tdist
        t_stat = r_partial * np.sqrt((n - 3) / (1 - r_partial**2))
        p_val = 2 * tdist.sf(abs(t_stat), df=n - 3)
    return float(r_partial), float(p_val)


def partial_correlation_2controls(
    x: np.ndarray, y: np.ndarray,
    z1: np.ndarray, z2: np.ndarray,
    method: str = "spearman",
) -> tuple[float, float]:
    """Partial correlation of x and y controlling for z1 AND z2.

    Uses OLS residualization approach: regress x and y on [z1, z2],
    then correlate residuals.
    """
    Z = np.column_stack([z1, z2, np.ones(len(z1))])
    # Residualize x
    beta_x, _, _, _ = np.linalg.lstsq(Z, x, rcond=None)
    resid_x = x - Z @ beta_x
    # Residualize y
    beta_y, _, _, _ = np.linalg.lstsq(Z, y, rcond=None)
    resid_y = y - Z @ beta_y

    corr_fn = spearmanr if method == "spearman" else pearsonr
    r, p = corr_fn(resid_x, resid_y)
    return float(r), float(p)


def bootstrap_ci(x: np.ndarray, y: np.ndarray, method: str = "spearman",
                 n_boot: int = BOOTSTRAP_N, seed: int = BOOTSTRAP_SEED,
                 ci: float = 0.95) -> tuple[float, float]:
    """Bootstrap confidence interval for a correlation."""
    rng = np.random.RandomState(seed)
    n = len(x)
    corr_fn = spearmanr if method == "spearman" else pearsonr
    boot_corrs = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.randint(0, n, size=n)
        r, _ = corr_fn(x[idx], y[idx])
        boot_corrs[i] = r
    alpha = (1 - ci) / 2
    lo = float(np.nanpercentile(boot_corrs, 100 * alpha))
    hi = float(np.nanpercentile(boot_corrs, 100 * (1 - alpha)))
    return lo, hi


def multiple_regression(
    y: np.ndarray,
    X_dict: dict[str, np.ndarray],
) -> dict[str, Any]:
    """Run OLS multiple regression: y ~ X_dict columns.

    Returns coefficients, standard errors, t-stats, p-values, R^2.
    """
    from scipy.stats import t as tdist

    names = list(X_dict.keys())
    X = np.column_stack([X_dict[k] for k in names])
    # Add intercept
    X_full = np.column_stack([np.ones(len(y)), X])
    all_names = ["intercept"] + names

    # OLS
    beta, residuals, rank, sv = np.linalg.lstsq(X_full, y, rcond=None)
    y_hat = X_full @ beta
    resid = y - y_hat
    n, k = X_full.shape

    # R^2
    ss_res = np.sum(resid**2)
    ss_tot = np.sum((y - y.mean())**2)
    r_squared = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")

    # Adjusted R^2
    adj_r_squared = 1 - (1 - r_squared) * (n - 1) / (n - k) if n > k else float("nan")

    # Standard errors
    if n > k and ss_res > 0:
        mse = ss_res / (n - k)
        try:
            cov_beta = mse * np.linalg.inv(X_full.T @ X_full)
            se = np.sqrt(np.diag(cov_beta))
        except np.linalg.LinAlgError:
            se = np.full(k, float("nan"))
    else:
        se = np.full(k, float("nan"))

    # t-stats and p-values
    t_stats = beta / se
    p_values = np.array([
        2 * tdist.sf(abs(t), df=n - k) if n > k else float("nan")
        for t in t_stats
    ])

    coefficients = {}
    for i, name in enumerate(all_names):
        coefficients[name] = {
            "beta": float(beta[i]),
            "se": float(se[i]),
            "t": float(t_stats[i]),
            "p": float(p_values[i]),
        }

    return {
        "coefficients": coefficients,
        "r_squared": float(r_squared),
        "adj_r_squared": float(adj_r_squared),
        "n": int(n),
        "k_predictors": int(k - 1),
        "residual_se": float(np.sqrt(ss_res / (n - k))) if n > k else float("nan"),
    }


# =============================================================================
# MAIN ANALYSIS
# =============================================================================

def run_analysis(model_name: str) -> dict[str, Any]:
    """Run the full frequency-band feeder analysis."""
    print(f"\n{'='*72}")
    print(f"Theory 9: Frequency-Band Feeder Analysis -- {model_name}")
    print(f"{'='*72}")

    # ── Load data ──────────────────────────────────────────────────────────
    print(f"\n[1/3] Loading data...")

    patching_df = load_patching_results(model_name)
    print(f"  Patching results: {len(patching_df)} source heads")

    r2_df = load_r2_data(model_name)
    print(f"  R^2 data: {len(r2_df)} heads")

    freq_df = load_freq_profile(model_name)
    print(f"  Frequency profiles: {len(freq_df)} heads")

    prev_token_df = load_prev_token_scores(model_name)
    if prev_token_df is not None:
        print(f"  Previous-token scores: {len(prev_token_df)} heads")
    else:
        print(f"  Previous-token scores: NOT AVAILABLE")

    # ── Merge datasets ────────────────────────────────────────────────────
    print(f"\n[2/3] Merging and filtering to early-layer heads (L0-{MAX_SOURCE_LAYER})...")

    # Rename patching columns for merge
    merged = patching_df.rename(columns={
        "source_layer": "layer",
        "source_head": "head",
    })

    # Merge with R^2
    merged = pd.merge(merged, r2_df, on=["layer", "head"], how="inner")

    # Merge with frequency profile
    merged = pd.merge(merged, freq_df, on=["layer", "head"], how="inner")

    # Merge with previous-token scores if available
    has_prev_token = False
    if prev_token_df is not None:
        merged = pd.merge(merged, prev_token_df, on=["layer", "head"], how="inner")
        has_prev_token = bool("prev_token_score" in merged.columns and merged["prev_token_score"].notna().all())

    # Filter to early layers
    merged = merged[merged["layer"] <= MAX_SOURCE_LAYER].copy()
    n_heads = len(merged)
    print(f"  Merged dataset: {n_heads} early-layer heads")

    if n_heads < 10:
        raise ValueError(f"Too few heads ({n_heads}) after merging. Check data availability.")

    # ── Extract arrays ────────────────────────────────────────────────────
    disruption = merged["mean_disruption"].values
    r2_total = merged["mean_r2"].values
    hf_frac = merged["hf_fraction_top25"].values
    lf_frac = merged["lf_fraction_bottom25"].values
    ultra_hf = merged["ultra_hf_fraction_top4"].values
    mean_freq_idx = merged["mean_freq_index"].values
    prev_token = merged["prev_token_score"].values if has_prev_token else None

    # ── Analysis ──────────────────────────────────────────────────────────
    print(f"\n[3/3] Running statistical analysis...")

    results: dict[str, Any] = {
        "experiment": "3_theory9_freq_band_feeder",
        "model": model_name,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "config": {
            "max_source_layer": MAX_SOURCE_LAYER,
            "n_heads_analyzed": n_heads,
            "bootstrap_n": BOOTSTRAP_N,
            "has_prev_token_scores": has_prev_token,
        },
    }

    # ── 1. Bivariate correlations ────────────────────────────────────────
    print(f"\n  --- Bivariate Correlations (disruption vs ...) ---")
    bivariate = {}
    corr_pairs = {
        "disruption_vs_r2": (disruption, r2_total, "R^2 (total)"),
        "disruption_vs_hf_fraction": (disruption, hf_frac, "HF fraction (top 25%)"),
        "disruption_vs_lf_fraction": (disruption, lf_frac, "LF fraction (bottom 25%)"),
        "disruption_vs_ultra_hf": (disruption, ultra_hf, "Ultra-HF fraction (top 4)"),
        "disruption_vs_mean_freq_idx": (disruption, mean_freq_idx, "Mean freq index"),
    }
    if has_prev_token:
        corr_pairs["disruption_vs_prev_token"] = (disruption, prev_token, "Prev-token score")

    for key, (x, y, label) in corr_pairs.items():
        r_p, p_p = pearsonr(x, y)
        r_s, p_s = spearmanr(x, y)
        ci_s = bootstrap_ci(x, y, method="spearman")
        ci_p = bootstrap_ci(x, y, method="pearson")
        bivariate[key] = {
            "label": label,
            "pearson_r": float(r_p),
            "pearson_p": float(p_p),
            "pearson_ci_95": list(ci_p),
            "spearman_rho": float(r_s),
            "spearman_p": float(p_s),
            "spearman_ci_95": list(ci_s),
        }
        sig_p = "***" if p_p < 0.001 else ("**" if p_p < 0.01 else ("*" if p_p < 0.05 else "ns"))
        sig_s = "***" if p_s < 0.001 else ("**" if p_s < 0.01 else ("*" if p_s < 0.05 else "ns"))
        print(f"    {label:<25s}  Pearson r={r_p:+.4f} ({sig_p})  Spearman rho={r_s:+.4f} ({sig_s})")

    results["bivariate_correlations"] = bivariate

    # ── 2. Correlations among predictors ─────────────────────────────────
    print(f"\n  --- Predictor Inter-correlations ---")
    predictor_corrs = {}
    pred_pairs = {
        "r2_vs_hf_fraction": (r2_total, hf_frac),
        "r2_vs_lf_fraction": (r2_total, lf_frac),
        "hf_vs_lf_fraction": (hf_frac, lf_frac),
    }
    if has_prev_token:
        pred_pairs["r2_vs_prev_token"] = (r2_total, prev_token)
        pred_pairs["hf_vs_prev_token"] = (hf_frac, prev_token)
        pred_pairs["lf_vs_prev_token"] = (lf_frac, prev_token)

    for key, (x, y) in pred_pairs.items():
        r_s, p_s = spearmanr(x, y)
        predictor_corrs[key] = {
            "spearman_rho": float(r_s),
            "spearman_p": float(p_s),
        }
        print(f"    {key:<30s}  rho={r_s:+.4f}  p={p_s:.2e}")

    results["predictor_intercorrelations"] = predictor_corrs

    # ── 3. Partial correlations ──────────────────────────────────────────
    print(f"\n  --- Partial Correlations ---")
    partials = {}

    # disruption vs hf_frac controlling for lf_frac
    for method in ["spearman", "pearson"]:
        r, p = partial_correlation(disruption, hf_frac, lf_frac, method=method)
        key = f"disruption_vs_hf_ctrl_lf_{method}"
        partials[key] = {"r": float(r), "p": float(p), "note": f"disruption vs HF controlling for LF ({method})"}
        print(f"    disruption vs HF | LF  ({method:>8s}): r={r:+.4f}  p={p:.4f}")

    # disruption vs lf_frac controlling for hf_frac
    for method in ["spearman", "pearson"]:
        r, p = partial_correlation(disruption, lf_frac, hf_frac, method=method)
        key = f"disruption_vs_lf_ctrl_hf_{method}"
        partials[key] = {"r": float(r), "p": float(p), "note": f"disruption vs LF controlling for HF ({method})"}
        print(f"    disruption vs LF | HF  ({method:>8s}): r={r:+.4f}  p={p:.4f}")

    # disruption vs R^2 controlling for hf_frac
    for method in ["spearman", "pearson"]:
        r, p = partial_correlation(disruption, r2_total, hf_frac, method=method)
        key = f"disruption_vs_r2_ctrl_hf_{method}"
        partials[key] = {"r": float(r), "p": float(p), "note": f"disruption vs R^2 controlling for HF ({method})"}
        print(f"    disruption vs R2 | HF  ({method:>8s}): r={r:+.4f}  p={p:.4f}")

    # disruption vs hf_frac controlling for R^2
    for method in ["spearman", "pearson"]:
        r, p = partial_correlation(disruption, hf_frac, r2_total, method=method)
        key = f"disruption_vs_hf_ctrl_r2_{method}"
        partials[key] = {"r": float(r), "p": float(p), "note": f"disruption vs HF controlling for R^2 ({method})"}
        print(f"    disruption vs HF | R2  ({method:>8s}): r={r:+.4f}  p={p:.4f}")

    if has_prev_token:
        # disruption vs hf_frac controlling for prev_token
        for method in ["spearman", "pearson"]:
            r, p = partial_correlation(disruption, hf_frac, prev_token, method=method)
            key = f"disruption_vs_hf_ctrl_pt_{method}"
            partials[key] = {"r": float(r), "p": float(p), "note": f"disruption vs HF controlling for prev_token ({method})"}
            print(f"    disruption vs HF | PT  ({method:>8s}): r={r:+.4f}  p={p:.4f}")

        # disruption vs R^2 controlling for prev_token (replicates theory 7b finding)
        for method in ["spearman", "pearson"]:
            r, p = partial_correlation(disruption, r2_total, prev_token, method=method)
            key = f"disruption_vs_r2_ctrl_pt_{method}"
            partials[key] = {"r": float(r), "p": float(p), "note": f"disruption vs R^2 controlling for prev_token ({method})"}
            print(f"    disruption vs R2 | PT  ({method:>8s}): r={r:+.4f}  p={p:.4f}")

        # disruption vs hf_frac controlling for BOTH lf_frac and prev_token
        r, p = partial_correlation_2controls(disruption, hf_frac, lf_frac, prev_token, method="pearson")
        partials["disruption_vs_hf_ctrl_lf_pt_pearson"] = {
            "r": float(r), "p": float(p),
            "note": "disruption vs HF controlling for LF + prev_token (pearson on residuals)",
        }
        print(f"    disruption vs HF | LF+PT (pearson): r={r:+.4f}  p={p:.4f}")

    results["partial_correlations"] = partials

    # ── 4. Bootstrap CIs for key correlations ────────────────────────────
    print(f"\n  --- Bootstrap CIs for Key Correlations ---")
    bootstrap_results = {}

    rng = np.random.RandomState(BOOTSTRAP_SEED)
    boot_keys = [
        ("disruption_vs_hf", disruption, hf_frac),
        ("disruption_vs_lf", disruption, lf_frac),
        ("disruption_vs_r2", disruption, r2_total),
    ]
    if has_prev_token:
        boot_keys.append(("disruption_vs_pt", disruption, prev_token))

    for label, x, y in boot_keys:
        boot_spearman = np.empty(BOOTSTRAP_N)
        boot_pearson = np.empty(BOOTSTRAP_N)
        n = len(x)
        for i in range(BOOTSTRAP_N):
            idx = rng.randint(0, n, size=n)
            boot_spearman[i], _ = spearmanr(x[idx], y[idx])
            boot_pearson[i], _ = pearsonr(x[idx], y[idx])
        ci_s = (float(np.nanpercentile(boot_spearman, 2.5)),
                float(np.nanpercentile(boot_spearman, 97.5)))
        ci_p = (float(np.nanpercentile(boot_pearson, 2.5)),
                float(np.nanpercentile(boot_pearson, 97.5)))
        bootstrap_results[label] = {
            "spearman_ci_95": list(ci_s),
            "pearson_ci_95": list(ci_p),
            "spearman_median": float(np.nanmedian(boot_spearman)),
            "pearson_median": float(np.nanmedian(boot_pearson)),
        }
        print(f"    {label:<25s}  Spearman 95% CI: [{ci_s[0]:+.4f}, {ci_s[1]:+.4f}]  "
              f"Pearson 95% CI: [{ci_p[0]:+.4f}, {ci_p[1]:+.4f}]")

    results["bootstrap_cis"] = bootstrap_results

    # ── 5. Multiple regression ───────────────────────────────────────────
    print(f"\n  --- Multiple Regression ---")

    # Model 1: disruption ~ hf_fraction + lf_fraction
    reg1_predictors = {"hf_fraction": hf_frac, "lf_fraction": lf_frac}
    reg1 = multiple_regression(disruption, reg1_predictors)
    print(f"\n  Model 1: disruption ~ hf_fraction + lf_fraction")
    print(f"    R^2 = {reg1['r_squared']:.4f}  (adj = {reg1['adj_r_squared']:.4f})")
    for name, c in reg1["coefficients"].items():
        sig = "***" if c["p"] < 0.001 else ("**" if c["p"] < 0.01 else ("*" if c["p"] < 0.05 else "ns"))
        print(f"    {name:<15s}  beta={c['beta']:+.6f}  se={c['se']:.6f}  t={c['t']:+.3f}  p={c['p']:.4f} {sig}")

    regression_results = {"model1_hf_lf": reg1}

    if has_prev_token:
        # Model 2: disruption ~ hf_fraction + lf_fraction + prev_token_score
        reg2_predictors = {
            "hf_fraction": hf_frac,
            "lf_fraction": lf_frac,
            "prev_token_score": prev_token,
        }
        reg2 = multiple_regression(disruption, reg2_predictors)
        print(f"\n  Model 2: disruption ~ hf_fraction + lf_fraction + prev_token_score")
        print(f"    R^2 = {reg2['r_squared']:.4f}  (adj = {reg2['adj_r_squared']:.4f})")
        for name, c in reg2["coefficients"].items():
            sig = "***" if c["p"] < 0.001 else ("**" if c["p"] < 0.01 else ("*" if c["p"] < 0.05 else "ns"))
            print(f"    {name:<20s}  beta={c['beta']:+.6f}  se={c['se']:.6f}  t={c['t']:+.3f}  p={c['p']:.4f} {sig}")
        regression_results["model2_hf_lf_pt"] = reg2

        # Model 3: disruption ~ r2 + prev_token_score (for comparison with theory 7b)
        reg3_predictors = {"r2": r2_total, "prev_token_score": prev_token}
        reg3 = multiple_regression(disruption, reg3_predictors)
        print(f"\n  Model 3: disruption ~ r2 + prev_token_score")
        print(f"    R^2 = {reg3['r_squared']:.4f}  (adj = {reg3['adj_r_squared']:.4f})")
        for name, c in reg3["coefficients"].items():
            sig = "***" if c["p"] < 0.001 else ("**" if c["p"] < 0.01 else ("*" if c["p"] < 0.05 else "ns"))
            print(f"    {name:<20s}  beta={c['beta']:+.6f}  se={c['se']:.6f}  t={c['t']:+.3f}  p={c['p']:.4f} {sig}")
        regression_results["model3_r2_pt"] = reg3

    # Model 4: disruption ~ hf_fraction only
    reg4 = multiple_regression(disruption, {"hf_fraction": hf_frac})
    print(f"\n  Model 4: disruption ~ hf_fraction")
    print(f"    R^2 = {reg4['r_squared']:.4f}  (adj = {reg4['adj_r_squared']:.4f})")
    for name, c in reg4["coefficients"].items():
        sig = "***" if c["p"] < 0.001 else ("**" if c["p"] < 0.01 else ("*" if c["p"] < 0.05 else "ns"))
        print(f"    {name:<15s}  beta={c['beta']:+.6f}  se={c['se']:.6f}  t={c['t']:+.3f}  p={c['p']:.4f} {sig}")
    regression_results["model4_hf_only"] = reg4

    # Model 5: disruption ~ lf_fraction only
    reg5 = multiple_regression(disruption, {"lf_fraction": lf_frac})
    print(f"\n  Model 5: disruption ~ lf_fraction")
    print(f"    R^2 = {reg5['r_squared']:.4f}  (adj = {reg5['adj_r_squared']:.4f})")
    for name, c in reg5["coefficients"].items():
        sig = "***" if c["p"] < 0.001 else ("**" if c["p"] < 0.01 else ("*" if c["p"] < 0.05 else "ns"))
        print(f"    {name:<15s}  beta={c['beta']:+.6f}  se={c['se']:.6f}  t={c['t']:+.3f}  p={c['p']:.4f} {sig}")
    regression_results["model5_lf_only"] = reg5

    results["regression"] = regression_results

    # ── 6. Descriptive statistics ────────────────────────────────────────
    desc = {
        "disruption": {
            "mean": float(disruption.mean()),
            "std": float(disruption.std()),
            "median": float(np.median(disruption)),
            "min": float(disruption.min()),
            "max": float(disruption.max()),
        },
        "r2": {
            "mean": float(r2_total.mean()),
            "std": float(r2_total.std()),
            "median": float(np.median(r2_total)),
        },
        "hf_fraction": {
            "mean": float(hf_frac.mean()),
            "std": float(hf_frac.std()),
            "median": float(np.median(hf_frac)),
        },
        "lf_fraction": {
            "mean": float(lf_frac.mean()),
            "std": float(lf_frac.std()),
            "median": float(np.median(lf_frac)),
        },
    }
    if has_prev_token:
        desc["prev_token_score"] = {
            "mean": float(prev_token.mean()),
            "std": float(prev_token.std()),
            "median": float(np.median(prev_token)),
        }
    results["descriptive_stats"] = desc

    # ── 7. Top disruptive heads with frequency breakdown ─────────────────
    merged_sorted = merged.sort_values("mean_disruption", ascending=False)
    top_heads = []
    for _, r in merged_sorted.head(20).iterrows():
        entry = {
            "layer": int(r["layer"]),
            "head": int(r["head"]),
            "mean_disruption": float(r["mean_disruption"]),
            "mean_r2": float(r["mean_r2"]),
            "hf_fraction": float(r["hf_fraction_top25"]),
            "lf_fraction": float(r["lf_fraction_bottom25"]),
            "ultra_hf_fraction": float(r["ultra_hf_fraction_top4"]),
            "mean_freq_idx": float(r["mean_freq_index"]),
        }
        if has_prev_token:
            entry["prev_token_score"] = float(r["prev_token_score"])
        top_heads.append(entry)
    results["top_20_disruptive_heads"] = top_heads

    # ── 8. Interpretation ────────────────────────────────────────────────
    print(f"\n  --- Interpretation ---")

    # Compare HF vs LF correlation strengths
    rho_hf = bivariate["disruption_vs_hf_fraction"]["spearman_rho"]
    rho_lf = bivariate["disruption_vs_lf_fraction"]["spearman_rho"]
    rho_r2 = bivariate["disruption_vs_r2"]["spearman_rho"]

    p_hf_ctrl_lf = partials.get("disruption_vs_hf_ctrl_lf_spearman", {}).get("r", float("nan"))
    p_lf_ctrl_hf = partials.get("disruption_vs_lf_ctrl_hf_spearman", {}).get("r", float("nan"))

    hf_dominates = abs(rho_hf) > abs(rho_lf) and abs(p_hf_ctrl_lf) > abs(p_lf_ctrl_hf)
    lf_dominates = abs(rho_lf) > abs(rho_hf) and abs(p_lf_ctrl_hf) > abs(p_hf_ctrl_lf)

    if hf_dominates:
        freq_verdict = (
            f"HF fraction is a STRONGER predictor of feeder disruption than LF fraction. "
            f"Spearman rho(disruption, HF)={rho_hf:+.4f} vs rho(disruption, LF)={rho_lf:+.4f}. "
            f"Partial r(disruption, HF | LF)={p_hf_ctrl_lf:+.4f} vs "
            f"partial r(disruption, LF | HF)={p_lf_ctrl_hf:+.4f}. "
            f"This suggests the feeder effect is driven by HIGH-frequency (local/subword) RoPE pairs."
        )
    elif lf_dominates:
        freq_verdict = (
            f"LF fraction is a STRONGER predictor of feeder disruption than HF fraction. "
            f"Spearman rho(disruption, LF)={rho_lf:+.4f} vs rho(disruption, HF)={rho_hf:+.4f}. "
            f"Partial r(disruption, LF | HF)={p_lf_ctrl_hf:+.4f} vs "
            f"partial r(disruption, HF | LF)={p_hf_ctrl_lf:+.4f}. "
            f"This suggests the feeder effect is driven by LOW-frequency (global position) RoPE pairs."
        )
    else:
        freq_verdict = (
            f"Neither HF nor LF fraction clearly dominates as a predictor of feeder disruption. "
            f"Spearman rho(disruption, HF)={rho_hf:+.4f}, rho(disruption, LF)={rho_lf:+.4f}. "
            f"Partial r(disruption, HF | LF)={p_hf_ctrl_lf:+.4f}, "
            f"partial r(disruption, LF | HF)={p_lf_ctrl_hf:+.4f}. "
            f"The feeder effect may not be frequency-band-specific."
        )

    # Does HF explain R^2 -> disruption link?
    r2_ctrl_hf = partials.get("disruption_vs_r2_ctrl_hf_spearman", {}).get("r", float("nan"))
    hf_mediates = abs(r2_ctrl_hf) < abs(rho_r2) * 0.5  # if >50% reduction

    if hf_mediates:
        mediation_verdict = (
            f"HF fraction MEDIATES the R^2-disruption link: controlling for HF reduces "
            f"the disruption-R^2 correlation from rho={rho_r2:+.4f} to partial r={r2_ctrl_hf:+.4f} "
            f"(>50% reduction). The feeder effect of high-SI heads may operate via their "
            f"high-frequency RoPE content."
        )
    else:
        mediation_verdict = (
            f"HF fraction does NOT fully mediate the R^2-disruption link: controlling for HF, "
            f"the disruption-R^2 partial r={r2_ctrl_hf:+.4f} (original rho={rho_r2:+.4f}). "
            f"R^2 carries independent predictive value beyond frequency composition."
        )

    interpretation = {
        "frequency_band_verdict": freq_verdict,
        "mediation_verdict": mediation_verdict,
        "rho_disruption_hf": float(rho_hf),
        "rho_disruption_lf": float(rho_lf),
        "rho_disruption_r2": float(rho_r2),
        "partial_hf_ctrl_lf": float(p_hf_ctrl_lf),
        "partial_lf_ctrl_hf": float(p_lf_ctrl_hf),
        "partial_r2_ctrl_hf": float(r2_ctrl_hf),
    }
    results["interpretation"] = interpretation

    print(f"\n  Frequency-band verdict:")
    print(f"    {freq_verdict}")
    print(f"\n  Mediation verdict:")
    print(f"    {mediation_verdict}")

    return results


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Theory 9: Frequency-band decomposition of the feeder effect"
    )
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        choices=VALID_MODELS,
        help="Model to analyze",
    )
    args = parser.parse_args()

    # Run analysis
    results = run_analysis(args.model)

    # Save report
    output_dir = PROJECT_ROOT / "results" / "experiment3" / "theory9_freq_band_feeder" / args.model
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "report.json"
    class NumpyEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, (np.integer,)):
                return int(obj)
            if isinstance(obj, (np.floating,)):
                return float(obj)
            if isinstance(obj, (np.bool_,)):
                return bool(obj)
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            return super().default(obj)

    with open(report_path, "w") as f:
        json.dump(results, f, indent=2, cls=NumpyEncoder)
    print(f"\n  Report saved to: {report_path}")

    print(f"\n{'='*72}")
    print(f"DONE -- Theory 9 analysis for {args.model}")
    print(f"{'='*72}")


if __name__ == "__main__":
    main()
