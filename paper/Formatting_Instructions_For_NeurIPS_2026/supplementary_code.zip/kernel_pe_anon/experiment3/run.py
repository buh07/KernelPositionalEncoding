#!/usr/bin/env python3
"""Experiment 3 dispatcher.

Usage
-----
    # Run a single theory on one model
    python -m experiment3.run theory1 --model llama-3.1-8b --device cuda:0

    # Run all theories sequentially for one model
    python -m experiment3.run all --model llama-3.1-8b --device cuda:0

    # List available theories
    python -m experiment3.run --list
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

EXPERIMENT3_DIR = Path(__file__).resolve().parent

# Map short names → script filenames
THEORIES: dict[str, str] = {
    "theory1":          "theory1_si_circuits.py",
    "theory3":          "theory3_crossterm_correlation.py",
    "theory5":          "theory5_subword_ablation.py",
    "theory5b":         "theory5b_boundary_detection.py",
    "theory7":          "theory7_induction_feeders.py",
    "theory7b":         "theory7b_activation_patching.py",
    "theory8":          "theory8_position_ablation.py",
    "theory9":          "theory9_freq_band_feeder.py",
    "theory10":         "theory10_feeder_specificity.py",
    "crossref":         "induction_r2_crossref.py",
    "rope_freq":        "rope_freq_per_head.py",
    "boundary_attn":    "subword_boundary_attention.py",
}

# Theories that need a GPU
GPU_THEORIES = {
    "theory1", "theory3", "theory5", "theory5b",
    "theory7", "theory7b", "theory8", "theory10",
    "crossref", "rope_freq", "boundary_attn",
}

# Theories that are pure analysis (no GPU)
ANALYSIS_ONLY = {"theory9"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run Experiment 3 theory scripts",
    )
    parser.add_argument(
        "theory",
        nargs="?",
        choices=list(THEORIES.keys()) + ["all"],
        help="Theory to run, or 'all' for sequential execution",
    )
    parser.add_argument("--model", default="llama-3.1-8b",
                        choices=["llama-3.1-8b", "olmo-2-7b"],
                        help="Model to evaluate")
    parser.add_argument("--device", default="cuda:0", help="Device for GPU theories")
    parser.add_argument("--list", action="store_true", help="List available theories")
    return parser.parse_args()


def run_theory(name: str, model: str, device: str) -> int:
    script = EXPERIMENT3_DIR / THEORIES[name]
    cmd = [sys.executable, str(script), "--model", model]
    if name not in ANALYSIS_ONLY:
        cmd += ["--device", device]
    print(f"\n{'='*72}")
    print(f"  Running {name} ({model}) on {device}")
    print(f"{'='*72}\n")
    return subprocess.call(cmd)


def main() -> None:
    args = parse_args()

    if args.list or args.theory is None:
        print("Available theories:")
        for name, script in THEORIES.items():
            gpu = "GPU" if name in GPU_THEORIES else "CPU"
            print(f"  {name:<18s}  {script:<45s}  [{gpu}]")
        return

    if args.theory == "all":
        for name in THEORIES:
            rc = run_theory(name, args.model, args.device)
            if rc != 0:
                print(f"\n*** {name} exited with code {rc}, stopping ***")
                sys.exit(rc)
    else:
        sys.exit(run_theory(args.theory, args.model, args.device))


if __name__ == "__main__":
    main()
