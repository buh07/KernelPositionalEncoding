# Experiment 3: Mechanistic Interpretability of Shift-Invariant Positional Kernels

## Document Status and Snapshot Context

Evidence snapshot: **2026-03-31**.

This document describes the protocol for Experiment 3, which investigates the mechanistic role of shift-invariant (SI) heads in transformer language models. Experiment 3 builds directly on the descriptive measurements of Experiments 1–2 and converts correlational findings into causal and mechanistic claims.

### Hard-Refresh Status (2026-03-31)

- Superseded run logs were hard-deleted from:
  - `logs/experiment3_repair/*`
  - `logs/experiment3_repair_t5b/*`
  - `logs/experiment3_*.log`
  - `results/experiment3/*.log`
- Active rerun namespaces:
  - `logs/experiment3_refresh/llama-3.1-8b_20260331_140354/`
  - `logs/experiment3_refresh/olmo-2-7b_20260331_140354/`

| Theory | llama-3.1-8b | olmo-2-7b | Notes |
|---|---|---|---|
| T1 | IN PROGRESS | IN PROGRESS | Full rerun chain in tmux (`exp3_refresh_llama`, `exp3_refresh_olmo`) |
| T3 | PENDING | PENDING | Will run with `--force-recompute-gap-kernels --force-recompute-total-energy` |
| T5 | PENDING | PENDING | Depends on refreshed T1 head groups |
| T5b | PENDING | PENDING | Depends on refreshed T1 artifacts |
| T7b | PENDING | PENDING | Sequential in refresh chain |
| T10 | PENDING | PENDING | Sequential in refresh chain |

## Motivation

Experiments 1 and 2 established that:
1. Attention logits in RoPE-equipped models are partially well-approximated by a shift-invariant kernel g(Δ), with R² varying across layers and heads (Experiment 1).
2. Ablating specific RoPE frequency pairs produces heterogeneous, head-dependent effects on downstream task performance (Experiment 2).

Experiment 3 asks: **what are high-SI heads actually doing?** It tests specific mechanistic hypotheses about their functional roles (subword composition, boundary detection, induction circuit feeding) and the causal importance of the positional kernel itself.

---

## Scope

### Models

Experiment 3 scales up from the 1B models of Experiments 1–2 to two 7–8B parameter models:

| Model | Parameters | Norm | PE | HF ID |
|---|---|---|---|---|
| Llama 3.1 8B | 8B | RMSNorm | RoPE | `meta-llama/Meta-Llama-3.1-8B` |
| OLMo 2 7B | 7B | LayerNorm | RoPE | `allenai/OLMo-2-1124-7B` |

Both use RoPE positional encoding with GQA (grouped query attention). The scale-up provides stronger signal and tests whether patterns found at 1B generalise.

### Data

All experiments use Wikipedia text (`wiki40b_en_pre2019`) tokenised per-model, with sequence lengths of 512 (profiling) or 1024 (evaluation). Induction detection experiments use synthetic repeated random sequences following Olsson et al. (2022).

---

## Theory Scripts and Hypotheses

### Theory 1: Shift-Invariance Circuits (`theory1_si_circuits.py`)

**Hypothesis:** Heads with high shift-invariance R² are disproportionately responsible for position-relative operations (copy, retrieval, induction-like pattern matching).

**Protocol:**
- Phase 1: R² profiling (50 sequences, len=512)
- Phase 2: Head classification (top/bottom 25% by R²)
- Phase 3: Head-output ablation (zero `o_proj` weights)
- Phase 4: Task battery (retrieval + local_key_match) under each ablation condition
- Phase 5: Comparative analysis across conditions (none, ablate_high_si, ablate_low_si, ablate_random ×3)

**Outputs:** `per_sequence_r2.parquet`, `head_r2_summary.parquet`, `head_groups.json`, `task_results.parquet`, `analysis.json`, `report.json`

---

### Theory 3: Cross-term Correlation (`theory3_crossterm_correlation.py`)

**Hypothesis:** The functionally important RoPE pairs are those with the strongest content-position coupling (cross-term), not those with the "right" frequency for a given positional range.

**Protocol:**
- Phase 1: Compute per-head raw and double-centered diagonal kernels
- Phase 2: Project gap signal (g_raw − g_centered) onto each RoPE pair's frequency
- Phase 3: Load pair ablation effects from Experiment 2
- Phase 4: Pearson, Spearman, and partial correlation analysis

**Key methodological note:** The original version called `normalize_logits_for_norm()` on raw logits, which pre-centers RMSNorm logits and zeros the cross-term being measured. This was fixed by using raw logits directly; `double_center()` handles the centered path only.

**Depends on:** Experiment 2 pair ablation effects (`pair_effects_merged.parquet`)

---

### Theory 5: Subword Ablation (`theory5_subword_ablation.py`)

**Hypothesis:** If high-SI heads specialise in assembling multi-token words, ablating them should disproportionately hurt continuation tokens (within-word) more than word-initial tokens.

**Protocol:**
- Phase 1: Construct evaluation sets (~500 continuation, ~500 word-initial positions) using word-boundary detection (Ġ/▁ prefix heuristics)
- Phase 2: Load head classification from Theory 1
- Phase 3: Ablation evaluation under 5 conditions
- Phase 4: Interaction analysis with paired t-test, Wilcoxon, Cohen's d, bootstrap CIs
- Robustness: Perplexity-matched subsample analysis

**Depends on:** Theory 1 `head_groups.json`

---

### Theory 5b: Boundary Detection (`theory5b_boundary_detection.py`)

**Hypothesis:** High-SI heads serve as word-boundary detectors — they attend more to positions at subword boundaries and their ablation disrupts boundary-sensitive processing.

**Three approaches:**
- A: Attention flow at word boundaries (do high-SI heads attend more to boundary positions?)
- B: 4-way position taxonomy (ablation damage × position type interaction)
- C: Boundary attention score vs R² correlation across all heads

---

### Theory 7: Induction Feeders (`theory7_induction_feeders.py`)

**Hypothesis:** Shift-invariance lives in early-layer "feeder" heads that provide positional signal to downstream induction heads, rather than in the induction heads themselves.

**Two approaches:**
- A: Previous-token scoring — do high-SI heads disproportionately attend to the previous token?
- B: Knockout analysis — does removing high-SI heads disrupt induction behaviour?

**Known limitation:** Approach B (knockout) has a critical flaw — zeroing head output destroys the residual stream, causing catastrophic disruption regardless of circuit membership. This motivated Theory 7b.

---

### Theory 7b: Activation Patching (`theory7b_activation_patching.py`)

**Hypothesis:** Same as Theory 7, but tested with resample patching instead of knockout.

**Protocol:**
- Generate (clean, corrupt) repeated random sequence pairs
- Cache `o_proj` activations from both runs
- Patch: run clean input but replace one source head's activation with its corrupt version
- Measure induction score disruption and correlate with R²

**Constants:** 30 pairs, period=32, seq_len=128, source heads in layers 0–7

---

### Theory 8: Positional Kernel Ablation (`theory8_position_ablation.py`)

**Hypothesis:** The estimated shift-invariant kernel g(Δ) carries functionally important positional information. Subtracting it from pre-softmax logits should degrade model performance, especially for high-SI heads.

**Protocol:**
- Phase 1: Estimate per-head kernel from 50 sequences
- Phase 2: Subtract kernel via attention mask hook (Toeplitz correction) on 100 eval sequences
- 4 conditions: baseline, subtract_kernel_high_si, subtract_kernel_low_si, subtract_kernel_all
- Statistical unit: per-SEQUENCE mean loss (not per-token, to avoid overstating significance)
- Forces eager attention for hook compatibility

---

### Theory 9: Frequency Band Feeders (`theory9_freq_band_feeder.py`)

**Hypothesis:** The high-frequency (local) component of RoPE drives the feeder effect, not the low-frequency (global) component.

**Protocol (CPU only — pure analysis):**
- Load existing R², induction scores, and RoPE frequency data
- Multiple regression: disruption ~ hf_fraction + lf_fraction + prev_token_score
- Partial correlations and bootstrap CIs
- Mediation analysis: does HF fraction mediate the R²–disruption link?

---

### Theory 10: Feeder Specificity (`theory10_feeder_specificity.py`)

**Hypothesis:** High-SI heads specifically feed induction circuits, not all downstream heads indiscriminately.

**Protocol:**
- Three target groups: induction (top 10), random mid-layer (L16–24), low-SI late (L24–31)
- Same resample patching protocol as Theory 7b
- Specificity test: is the disruption–R² correlation stronger for induction targets than for other targets?

---

### Supporting Analyses

#### Induction R² Cross-Reference (`induction_r2_crossref.py`)

Computes per-head induction scores using repeated random sequences (Olsson et al. 2022) and cross-references with R² to classify heads into 4 quadrants: high/low SI × high/low induction. Identifies "subword composition candidates" (high R², low induction).

#### RoPE Frequency per Head (`rope_freq_per_head.py`)

Decomposes each head's Q/K projections into per-RoPE-pair energy contributions. Computes metrics: `hf_fraction_top25`, `lf_fraction_bottom25`, `ultra_hf_fraction_top4`, `mean_freq_index`, `energy_entropy`.

#### Subword Boundary Attention (`subword_boundary_attention.py`)

Measures attention patterns relative to word boundaries: `mean_attn_distance`, `within_word_fraction`, `adjacent_subword_fraction`. Cross-references with R² to test whether high-SI heads attend locally within words.

---

## Output Structure

All theory artifacts are written to `results/experiment3/<theory_name>/<model_name>/`:

```
results/experiment3/
├── theory1_si_circuits/
│   ├── llama-3.1-8b/
│   │   ├── report.json
│   │   ├── per_sequence_r2.parquet
│   │   ├── head_r2_summary.parquet
│   │   ├── head_groups.json
│   │   ├── task_results.parquet
│   │   └── analysis.json
│   └── olmo-2-7b/
│       └── ...
├── theory3_crossterm/
│   └── ...
├── ...
```

Refresh run logs are written to `logs/experiment3_refresh/<model_run_id>/`.

## Execution

Dispatcher entrypoints:

```bash
python -m experiment3.run theory1 --model llama-3.1-8b --device cuda:0
python -m experiment3.run theory10 --model olmo-2-7b --device cuda:1
python -m experiment3.run --list
```

Direct script entrypoints:

```bash
python experiment3/theory1_si_circuits.py --model llama-3.1-8b --device cuda:0
python experiment3/theory3_crossterm_correlation.py --model llama-3.1-8b --device cuda:0 --force-recompute-gap-kernels --force-recompute-total-energy
python experiment3/theory5_subword_ablation.py --model olmo-2-7b --device cuda:1
```

Hard-refresh chain (tmux, GPU 0 + 1):

```bash
tmux new-session -d -s exp3_refresh_llama "cd '/path/to/scratch/Kernel PE' && ./scripts/experiment3_refresh_gpu0.sh"
tmux new-session -d -s exp3_refresh_olmo  "cd '/path/to/scratch/Kernel PE' && ./scripts/experiment3_refresh_gpu1.sh"
tmux ls
```
