# Experiment 3 Results

Generated: **2026-04-01 05:18:09**

Source policy: this file is generated strictly from artifact JSON files in `results/experiment3/`.

## Artifact Table

| Theory | Model | Artifact | Artifact Timestamp | Status | Key Metric |
|---|---|---|---|---|---|
| T1 | llama-3.1-8b | `results/experiment3/theory1_si_circuits/llama-3.1-8b/analysis.json` | 2026-03-31 20:28:34 | NOT SUPPORTED | paired Δdrop=-0.0149, p=0.9999933417907164 |
| T1 | olmo-2-7b | `results/experiment3/theory1_si_circuits/olmo-2-7b/analysis.json` | 2026-03-31 18:48:50 | NOT SUPPORTED | paired Δdrop=-0.0118, p=0.9747260050428849 |
| T3 | llama-3.1-8b | `results/experiment3/theory3_crossterm/llama-3.1-8b/analysis.json` | 2026-03-31 20:30:53 | DESCRIPTIVE | mean Spearman=-0.1101; n_task_span=4 |
| T3 | olmo-2-7b | `results/experiment3/theory3_crossterm/olmo-2-7b/analysis.json` | 2026-03-31 18:51:00 | DESCRIPTIVE | mean Spearman=+0.0496; n_task_span=3 |
| T5 | llama-3.1-8b | `results/experiment3/theory5_subword_ablation/llama-3.1-8b/analysis.json` | 2026-03-31 20:32:05 | NOT SUPPORTED | high-low interaction=-1.9623, high=-1.3066, low=+0.6557 |
| T5 | olmo-2-7b | `results/experiment3/theory5_subword_ablation/olmo-2-7b/analysis.json` | 2026-03-31 18:52:06 | NOT SUPPORTED | high-low interaction=-1.4382, high=-0.3893, low=+1.0489 |
| T5b | llama-3.1-8b | `results/experiment3/theory5b_boundary_detection/llama-3.1-8b/report.json` | 2026-03-31 21:40:39 | SUPPORTED | Boundary detection hypothesis: SUPPORTED. A=Y, B=Y, C=Y. |
| T5b | olmo-2-7b | `results/experiment3/theory5b_boundary_detection/olmo-2-7b/report.json` | 2026-03-31 19:55:32 | SUPPORTED | Boundary detection hypothesis: SUPPORTED. A=Y, B=N, C=Y. |
| T7 | llama-3.1-8b | `results/experiment3/theory7_induction_feeders/llama-3.1-8b/report.json` | 2026-03-17 11:44:02 | SUPPORTED | The feeder-head hypothesis is SUPPORTED: induction circuit feeders tend to be high-SI heads, resolving the apparent anti-correlation between induction score and R². |
| T7 | olmo-2-7b | `results/experiment3/theory7_induction_feeders/olmo-2-7b/report.json` | 2026-03-17 12:30:19 | SUPPORTED | The feeder-head hypothesis is SUPPORTED: induction circuit feeders tend to be high-SI heads, resolving the apparent anti-correlation between induction score and R². |
| T7b | llama-3.1-8b | `results/experiment3/theory7b_activation_patching/llama-3.1-8b/report.json` | 2026-04-01 02:12:11 | NOT SUPPORTED | Spearman=+0.0644, p=0.30497936108394413 |
| T7b | olmo-2-7b | `results/experiment3/theory7b_activation_patching/olmo-2-7b/report.json` | 2026-04-01 00:09:19 | SUPPORTED | Spearman=+0.2066, p=0.0008831316751208476 |
| T8 | llama-3.1-8b | `results/experiment3/theory8_position_ablation/llama-3.1-8b/report.json` | 2026-03-18 01:21:20 | SUPPORTED | VERDICT: The positional kernel IS functionally relevant. Removing it significantly increases loss. |
| T8 | olmo-2-7b | `results/experiment3/theory8_position_ablation/olmo-2-7b/report.json` | 2026-03-18 01:26:12 | SUPPORTED | VERDICT: The positional kernel IS functionally relevant. Removing it significantly increases loss. |
| T9 | llama-3.1-8b | `results/experiment3/theory9_freq_band_feeder/llama-3.1-8b/report.json` | 2026-03-17 22:56:28 | DESCRIPTIVE | rho_hf=+0.4375, rho_lf=-0.1390 |
| T9 | olmo-2-7b | `results/experiment3/theory9_freq_band_feeder/olmo-2-7b/report.json` | 2026-03-17 22:36:32 | DESCRIPTIVE | rho_hf=+0.2089, rho_lf=-0.1575 |
| T10 | llama-3.1-8b | `results/experiment3/theory10_feeder_specificity/llama-3.1-8b/report.json` | 2026-04-01 05:16:15 | NOT SUPPORTED | rho_ind=+0.0644, rho_rand=-0.0123, rho_low=+0.0802 |
| T10 | olmo-2-7b | `results/experiment3/theory10_feeder_specificity/olmo-2-7b/report.json` | 2026-04-01 04:40:29 | NOT SUPPORTED | rho_ind=+0.2066, rho_rand=+0.1888, rho_low=-0.0499 |

## Status Summary

| Theory | llama-3.1-8b | olmo-2-7b |
|---|---|---|
| T1 | NOT SUPPORTED | NOT SUPPORTED |
| T3 | DESCRIPTIVE | DESCRIPTIVE |
| T5 | NOT SUPPORTED | NOT SUPPORTED |
| T5b | SUPPORTED | SUPPORTED |
| T7 | SUPPORTED | SUPPORTED |
| T7b | NOT SUPPORTED | SUPPORTED |
| T8 | SUPPORTED | SUPPORTED |
| T9 | DESCRIPTIVE | DESCRIPTIVE |
| T10 | NOT SUPPORTED | NOT SUPPORTED |

## Notes

- `DESCRIPTIVE` means the theory output is correlation-oriented or lacks a binary support flag in artifacts.
- `MISSING` means the expected artifact file is not present or unreadable.
