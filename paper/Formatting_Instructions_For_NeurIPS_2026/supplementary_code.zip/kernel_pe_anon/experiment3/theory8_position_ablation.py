#!/usr/bin/env python3
"""
Experiment 3 Theory 8: Positional kernel ablation
==================================================

Motivation
----------
Theory 3 showed that the double-centered (pure positional) component of
attention logits accounts for only 1-4% of raw variance; the cross-term
(content x position) dominates at 96-99%.  Theory 7b showed that after
controlling for previous-token attention, R^2 (shift-invariance) adds zero
predictive power for causal disruption.

This experiment directly tests: if you surgically remove just the estimated
shift-invariant (positional) kernel from pre-softmax attention logits, does
the model actually get worse?

Protocol
--------
Phase 1 -- Kernel Estimation (50 wiki sequences, len=512):
    For each head, estimate the shift-invariant kernel g(delta) by averaging
    the diagonal means of pre-softmax attention logits across sequences.

Phase 2 -- Evaluation (100 different wiki sequences, len=512):
    Run 4 conditions:
      (a) baseline           -- unmodified model
      (b) subtract_kernel_high_si  -- subtract estimated kernel from high-SI heads
      (c) subtract_kernel_low_si   -- subtract estimated kernel from low-SI heads
      (d) subtract_kernel_all      -- subtract estimated kernel from all heads
    Measure per-token cross-entropy loss under each condition.

The kernel subtraction is achieved by folding the per-head Toeplitz correction
into the attention mask before softmax (via a forward pre-hook on each
decoder layer's self_attn module).  Since the eager attention path computes:

    attn_weights = Q @ K^T * scaling + attention_mask
    attn_weights = softmax(attn_weights)

adding -kernel to the mask is equivalent to subtracting the kernel from the
pre-softmax logits.

Usage
-----
    python scripts/experiment3_theory8_position_ablation.py --model llama-3.1-8b --device cuda:2
    python scripts/experiment3_theory8_position_ablation.py --model olmo-2-7b --device cuda:3
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from collections import defaultdict
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F
from scipy import stats

# -- project imports -----------------------------------------------------------
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from shared.attention.adapters import get_adapter
from shared.models.loading import load_model, load_tokenizer
from shared.specs import ModelSpec

# -- constants -----------------------------------------------------------------
ESTIMATION_SEQUENCES = 50
EVAL_SEQUENCES = 100
SEQ_LEN = 512
BOOTSTRAP_N = 10000
BOOTSTRAP_SEED = 42

MODELS: dict[str, ModelSpec] = {
    "llama-3.1-8b": ModelSpec(
        name="llama-3.1-8b",
        hf_id="meta-llama/Meta-Llama-3.1-8B",
        norm="RMSNorm",
        pe_scheme="RoPE",
        notes="Llama 3.1 8B (GQA: 32Q/8KV heads).",
    ),
    "olmo-2-7b": ModelSpec(
        name="olmo-2-7b",
        hf_id="allenai/OLMo-2-1124-7B",
        norm="LayerNorm",
        pe_scheme="RoPE",
        notes="OLMo 2 7B.",
        download_kwargs=(("torch_dtype", "bfloat16"),),
    ),
    "mistral-7b-v0.1": ModelSpec(
        name="mistral-7b-v0.1",
        hf_id="mistralai/Mistral-7B-v0.1",
        norm="RMSNorm",
        pe_scheme="RoPE",
        notes="Mistral 7B v0.1 (GQA).",
    ),
    "gpt2-medium": ModelSpec(
        name="gpt2-medium",
        hf_id="openai-community/gpt2-medium",
        norm="LayerNorm",
        pe_scheme="LearnedAbsolutePE",
        notes="GPT-2 medium non-RoPE anchor.",
    ),
    "gpt2-small": ModelSpec(
        name="gpt2-small",
        hf_id="openai-community/gpt2",
        norm="LayerNorm",
        pe_scheme="LearnedAbsolutePE",
        notes="GPT-2 small non-RoPE anchor.",
    ),
}


# ==============================================================================
# DATA LOADING
# ==============================================================================

def load_wiki_sequences(model_name: str, max_sequences: int, seq_len: int) -> list[list[int]]:
    """Load tokenized wiki sequences."""
    data_dir = Path("data/experiment1/wiki40b_en_pre2019") / model_name
    candidates = sorted(data_dir.rglob("*.jsonl"))
    if not candidates:
        raise FileNotFoundError(f"No tokenized JSONL found in {data_dir}")
    sequences: list[list[int]] = []
    for jsonl_path in candidates:
        with open(jsonl_path) as f:
            for line in f:
                row = json.loads(line)
                tokens = row.get("tokens", row.get("input_ids", []))
                if len(tokens) >= seq_len:
                    sequences.append(tokens[:seq_len])
                if len(sequences) >= max_sequences:
                    break
        if len(sequences) >= max_sequences:
            break
    return sequences


def load_head_groups(model_name: str) -> dict[str, list[tuple[int, int]]]:
    """Load head R^2 classification from theory1 results.

    Returns dict with 'high_si' and 'low_si' keys, each mapping to a list
    of (layer, head) tuples.
    """
    candidates = [
        Path("results/experiment3/theory1_si_circuits") / model_name / "head_groups.json",
        Path("results/experiment3_phase2/exp3p2k_non_rope_control") / model_name / "head_groups.json",
        Path("results/reinforce_exp/exp_r4_pe_scheme_contrast") / model_name / "head_groups.json",
    ]
    raw = None
    used = None
    for path in candidates:
        if not path.exists():
            continue
        with open(path) as f:
            raw = json.load(f)
        used = path
        break
    if raw is None:
        raise FileNotFoundError(f"No head_groups.json found for {model_name} in expected locations: {candidates}")
    result = {}
    for group_name in ("high_si", "low_si"):
        result[group_name] = [(d["layer"], d["head"]) for d in raw[group_name]]
    print(f"  Loaded head groups from {used}", flush=True)
    return result


# ==============================================================================
# MODEL INTERNALS
# ==============================================================================

def get_model_config(model) -> dict[str, Any]:
    """Extract key config values from a model."""
    config = model.config
    num_query_heads = int(getattr(config, "num_attention_heads"))
    num_kv_heads = int(getattr(config, "num_key_value_heads", num_query_heads))
    hidden_size = int(getattr(config, "hidden_size"))
    head_dim = hidden_size // num_query_heads
    num_layers_raw = getattr(config, "num_hidden_layers", None)
    if num_layers_raw is None:
        num_layers_raw = getattr(config, "n_layer", None)
    if num_layers_raw is None:
        raise RuntimeError("Unable to infer number of layers from model config")
    num_layers = int(num_layers_raw)
    return {
        "num_query_heads": num_query_heads,
        "num_kv_heads": num_kv_heads,
        "hidden_size": hidden_size,
        "head_dim": head_dim,
        "num_layers": num_layers,
    }


def get_attention_modules(model) -> dict[int, Any]:
    """Return a layer-indexed mapping of attention modules across model families."""
    if hasattr(model, "model") and hasattr(model.model, "layers"):
        return {int(i): layer.self_attn for i, layer in enumerate(model.model.layers)}
    if hasattr(model, "transformer") and hasattr(model.transformer, "h"):
        return {int(i): block.attn for i, block in enumerate(model.transformer.h)}
    raise RuntimeError("Unsupported architecture for Theory8 attention hooks")


# ==============================================================================
# PHASE 1: KERNEL ESTIMATION
# ==============================================================================

def estimate_kernels(
    model,
    adapter,
    sequences: list[list[int]],
    device: str,
    seq_len: int,
) -> dict[tuple[int, int], np.ndarray]:
    """Estimate the shift-invariant kernel g(delta) for each head.

    For each sequence, capture pre-softmax attention logits and compute the
    mean along each diagonal delta (where delta = j - i for the upper triangle,
    i.e. how far back the query at position i attends to key at position j
    with j <= i in causal attention, measured as |i - j|).

    Returns {(layer, head): np.array of shape [seq_len]} where entry[delta]
    is the estimated kernel value g(delta).
    """
    print(f"  Estimating kernels from {len(sequences)} sequences "
          f"(seq_len={seq_len})...", flush=True)

    # Accumulator: sum of diagonal means per (layer, head, delta)
    accum: dict[tuple[int, int], np.ndarray] = {}
    count = 0

    for seq_idx, tokens in enumerate(sequences):
        input_ids = torch.tensor([tokens[:seq_len]], dtype=torch.long, device=device)

        with torch.no_grad():
            capture = adapter.capture(
                model,
                input_ids=input_ids,
                include_logits=True,
                return_token_logits=False,
                capture_attention=True,
                output_device="cpu",
            )

        if capture.logits is None:
            print(f"    Sequence {seq_idx}: capture failed, skipping", flush=True)
            continue

        # logits shape: [layers, heads, seq, seq] (batch dim squeezed by adapter)
        logits = capture.logits.float().numpy()
        n_layers, n_heads, s, _ = logits.shape

        for layer in range(n_layers):
            for head in range(n_heads):
                mat = logits[layer, head]  # [s, s]
                diag_means = np.zeros(s)
                for delta in range(s):
                    # k=-delta gives the lower diagonal: mat[i, i-delta] for
                    # positions where the query at i attends back by delta tokens.
                    diag_vals = np.diag(mat, k=-delta)
                    if len(diag_vals) > 0:
                        diag_means[delta] = np.mean(diag_vals)

                key = (layer, head)
                if key not in accum:
                    accum[key] = np.zeros(s)
                accum[key] += diag_means

        count += 1
        del capture
        torch.cuda.empty_cache()

        if (seq_idx + 1) % 10 == 0 or seq_idx == 0:
            print(f"    {seq_idx + 1}/{len(sequences)} sequences processed",
                  flush=True)

    # Average across sequences
    kernels = {}
    for key in accum:
        kernels[key] = accum[key] / max(count, 1)

    print(f"  Estimated kernels for {len(kernels)} (layer, head) pairs "
          f"from {count} sequences", flush=True)
    return kernels


# ==============================================================================
# KERNEL SUBTRACTION HOOK
# ==============================================================================

def build_toeplitz_correction(
    kernels: dict[tuple[int, int], np.ndarray],
    target_heads: list[tuple[int, int]],
    num_query_heads: int,
    seq_len: int,
    device: torch.device,
    dtype: torch.dtype,
) -> dict[int, torch.Tensor]:
    """Build per-layer Toeplitz correction tensors.

    For each layer that has target heads, creates a tensor of shape
    [1, num_query_heads, seq_len, seq_len] where target heads contain
    -g(|i-j|) and non-target heads contain 0.

    This tensor is ADDED to the attention mask (which is itself added to
    logits before softmax), so the net effect is subtracting g(|i-j|) from
    the logits of the target heads.

    Returns {layer_idx: correction_tensor}.
    """
    heads_by_layer: dict[int, list[int]] = {}
    for (layer, head) in target_heads:
        heads_by_layer.setdefault(layer, []).append(head)

    corrections = {}
    for layer_idx, head_list in heads_by_layer.items():
        corr = torch.zeros(1, num_query_heads, seq_len, seq_len,
                           device=device, dtype=dtype)
        for h_idx in head_list:
            key = (layer_idx, h_idx)
            if key not in kernels:
                continue
            g = kernels[key]
            # Build Toeplitz correction: corr[i, j] = -g(|i - j|)
            # Vectorised per-diagonal fill
            for delta in range(min(len(g), seq_len)):
                val = -float(g[delta])
                if val == 0.0:
                    continue
                n_elem = seq_len - delta
                idx = torch.arange(n_elem, device=device)
                # Lower diagonal (i > j by delta): query i attends to key i-delta
                corr[0, h_idx, idx + delta, idx] = val
                # Upper diagonal (j > i by delta) -- present in the tensor but
                # masked by the causal mask; fill anyway for completeness.
                if delta > 0:
                    corr[0, h_idx, idx, idx + delta] = val

        corrections[layer_idx] = corr

    return corrections


@contextmanager
def subtract_positional_kernels(
    model,
    kernels: dict[tuple[int, int], np.ndarray],
    target_heads: list[tuple[int, int]],
    seq_len: int,
):
    """Context manager that hooks attention layers to subtract positional kernels.

    Modifies the ``attention_mask`` argument passed to ``self_attn.forward``
    via a ``register_forward_pre_hook`` with ``with_kwargs=True``.  Because
    the eager attention path performs::

        attn_weights = Q @ K^T * scaling + attention_mask
        attn_weights = softmax(attn_weights)

    adding ``-kernel`` to the mask is equivalent to subtracting the kernel
    from the pre-softmax logits.
    """
    if not target_heads:
        yield
        return

    cfg = get_model_config(model)
    num_query_heads = cfg["num_query_heads"]
    attn_modules = get_attention_modules(model)

    # Determine device and dtype from model parameters
    param = next(model.parameters())
    device = param.device
    # Attention mask operations happen in float32 inside eager_attention_forward
    mask_dtype = torch.float32

    corrections = build_toeplitz_correction(
        kernels, target_heads, num_query_heads, seq_len, device, mask_dtype,
    )

    handles: list[torch.utils.hooks.RemovableHandle] = []

    for layer_idx, correction in corrections.items():
        if layer_idx not in attn_modules:
            continue
        attn_module = attn_modules[layer_idx]

        def make_hook(corr: torch.Tensor):
            def hook(module, args, kwargs):
                mask = kwargs.get("attention_mask")
                if mask is None:
                    return

                # mask shape: [batch, 1, seq, seq] (causal mask from model)
                batch_size = mask.shape[0]
                actual_seq = mask.shape[-1]

                # Slice correction to actual sequence length
                c = corr[:, :, :actual_seq, :actual_seq]

                # Expand mask from [batch, 1, seq, seq] -> [batch, n_heads, seq, seq]
                if mask.shape[1] == 1:
                    expanded_mask = mask.expand(
                        batch_size, c.shape[1], -1, -1
                    ).clone()
                else:
                    expanded_mask = mask.clone()

                # Add the correction (contains -kernel for target heads, 0 elsewhere)
                expanded_mask = expanded_mask + c.to(expanded_mask.dtype)

                kwargs["attention_mask"] = expanded_mask
                return args, kwargs

            return hook

        handle = attn_module.register_forward_pre_hook(
            make_hook(correction),
            with_kwargs=True,
        )
        handles.append(handle)

    try:
        yield
    finally:
        for h in handles:
            h.remove()


# ==============================================================================
# LOSS COMPUTATION
# ==============================================================================

def compute_per_token_loss(
    model,
    input_ids: torch.Tensor,
) -> torch.Tensor:
    """Compute per-token cross-entropy loss (next-token prediction).

    Returns a 1-D tensor of shape [seq_len - 1] with per-position losses.
    """
    with torch.no_grad():
        outputs = model(
            input_ids=input_ids,
            use_cache=False,
            output_attentions=False,
            output_hidden_states=False,
        )
    logits = outputs.logits  # [batch, seq, vocab]
    # Shift: predict token t+1 from position t
    shift_logits = logits[:, :-1, :].contiguous()
    shift_labels = input_ids[:, 1:].contiguous()
    # Per-token cross-entropy (no reduction)
    loss = F.cross_entropy(
        shift_logits.view(-1, shift_logits.size(-1)),
        shift_labels.view(-1),
        reduction="none",
    )
    return loss.float().cpu()  # [batch * (seq_len - 1)]


# ==============================================================================
# PHASE 2: EVALUATION
# ==============================================================================

def run_evaluation(
    model,
    kernels: dict[tuple[int, int], np.ndarray],
    head_groups: dict[str, list[tuple[int, int]]],
    eval_sequences: list[list[int]],
    device: str,
    seq_len: int,
) -> dict[str, np.ndarray]:
    """Run evaluation under 4 conditions, returning per-token losses.

    Returns {condition_name: np.array of shape [n_sequences * (seq_len - 1)]}.
    """
    cfg = get_model_config(model)
    all_heads = [
        (l, h)
        for l in range(cfg["num_layers"])
        for h in range(cfg["num_query_heads"])
    ]

    conditions: dict[str, list[tuple[int, int]]] = {
        "baseline": [],
        "subtract_kernel_high_si": head_groups["high_si"],
        "subtract_kernel_low_si": head_groups["low_si"],
        "subtract_kernel_all": all_heads,
    }

    results: dict[str, list[np.ndarray]] = {name: [] for name in conditions}

    print(f"  Evaluating {len(eval_sequences)} sequences under "
          f"{len(conditions)} conditions...", flush=True)
    print(f"  Target head counts: "
          f"high_si={len(head_groups['high_si'])}, "
          f"low_si={len(head_groups['low_si'])}, "
          f"all={len(all_heads)}", flush=True)

    for seq_idx, tokens in enumerate(eval_sequences):
        input_ids = torch.tensor(
            [tokens[:seq_len]], dtype=torch.long, device=device,
        )

        for cond_name, target_heads in conditions.items():
            with subtract_positional_kernels(
                model, kernels, target_heads, seq_len,
            ):
                loss = compute_per_token_loss(model, input_ids)
            results[cond_name].append(loss.numpy())

            torch.cuda.empty_cache()

        if (seq_idx + 1) % 10 == 0 or seq_idx == 0:
            bl = np.mean(np.concatenate(results["baseline"]))
            hi = np.mean(np.concatenate(results["subtract_kernel_high_si"]))
            lo = np.mean(np.concatenate(results["subtract_kernel_low_si"]))
            al = np.mean(np.concatenate(results["subtract_kernel_all"]))
            print(
                f"    {seq_idx + 1}/{len(eval_sequences)}: "
                f"baseline={bl:.4f}  hi_si={hi:.4f}(+{hi - bl:.4f})  "
                f"lo_si={lo:.4f}(+{lo - bl:.4f})  "
                f"all={al:.4f}(+{al - bl:.4f})",
                flush=True,
            )

    # Concatenate all per-token losses
    final = {}
    for name, loss_list in results.items():
        final[name] = np.concatenate(loss_list)

    return final


# ==============================================================================
# STATISTICAL ANALYSIS
# ==============================================================================

def compute_statistics(
    losses: dict[str, np.ndarray],
    n_eval_sequences: int,
    seq_len: int,
) -> dict[str, Any]:
    """Compute per-condition statistics and comparisons.

    Uses per-SEQUENCE mean loss as the unit for paired tests (not per-token,
    which would overstate significance due to within-sequence correlation).
    """
    baseline = losses["baseline"]
    tokens_per_seq = seq_len - 1  # next-token prediction drops one token

    analysis: dict[str, Any] = {}

    # Per-condition summary
    for cond_name, loss_arr in losses.items():
        entry: dict[str, Any] = {
            "mean_loss": float(np.mean(loss_arr)),
            "median_loss": float(np.median(loss_arr)),
            "std_loss": float(np.std(loss_arr)),
            "n_tokens": int(len(loss_arr)),
        }
        if cond_name != "baseline":
            diff = loss_arr - baseline
            entry["mean_loss_increase"] = float(np.mean(diff))
            entry["median_loss_increase"] = float(np.median(diff))
            bl_mean = float(np.mean(baseline))
            if bl_mean > 0:
                entry["relative_increase_pct"] = float(
                    100.0 * np.mean(diff) / bl_mean
                )
        analysis[cond_name] = entry

    # Paired tests using per-sequence means
    comparisons: dict[str, Any] = {}
    for cond_name in (
        "subtract_kernel_high_si",
        "subtract_kernel_low_si",
        "subtract_kernel_all",
    ):
        cond_loss = losses[cond_name]

        bl_seq = baseline.reshape(n_eval_sequences, tokens_per_seq).mean(axis=1)
        cd_seq = cond_loss.reshape(n_eval_sequences, tokens_per_seq).mean(axis=1)
        diff_seq = cd_seq - bl_seq

        # Paired t-test
        t_stat, t_pval = stats.ttest_rel(cd_seq, bl_seq)

        # Wilcoxon signed-rank test
        try:
            w_stat, w_pval = stats.wilcoxon(diff_seq)
        except ValueError:
            w_stat, w_pval = float("nan"), float("nan")

        # Bootstrap CI for mean loss increase
        rng = np.random.RandomState(BOOTSTRAP_SEED)
        boot_means = np.empty(BOOTSTRAP_N)
        n = len(diff_seq)
        for i in range(BOOTSTRAP_N):
            idx = rng.randint(0, n, size=n)
            boot_means[i] = np.mean(diff_seq[idx])

        ci_lo = float(np.percentile(boot_means, 2.5))
        ci_hi = float(np.percentile(boot_means, 97.5))

        # Cohen's d
        d_mean = float(np.mean(diff_seq))
        d_std = float(np.std(diff_seq, ddof=1)) if len(diff_seq) > 1 else 1.0
        cohens_d = d_mean / d_std if d_std > 0 else float("nan")

        frac_increased = float(np.mean(diff_seq > 0))

        comparisons[cond_name] = {
            "mean_loss_increase": d_mean,
            "std_loss_increase": d_std,
            "bootstrap_ci_95": [ci_lo, ci_hi],
            "paired_t_stat": float(t_stat),
            "paired_t_pval": float(t_pval),
            "wilcoxon_stat": float(w_stat) if not np.isnan(w_stat) else None,
            "wilcoxon_pval": float(w_pval) if not np.isnan(w_pval) else None,
            "cohens_d": float(cohens_d),
            "fraction_sequences_increased": frac_increased,
            "n_sequences": n,
        }

    analysis["comparisons"] = comparisons

    # High-SI vs Low-SI direct comparison
    hi_seq = (
        losses["subtract_kernel_high_si"]
        .reshape(n_eval_sequences, tokens_per_seq)
        .mean(axis=1)
    )
    lo_seq = (
        losses["subtract_kernel_low_si"]
        .reshape(n_eval_sequences, tokens_per_seq)
        .mean(axis=1)
    )
    hi_vs_lo_diff = hi_seq - lo_seq
    t_hl, p_hl = stats.ttest_rel(hi_seq, lo_seq)

    analysis["high_vs_low_si"] = {
        "description": (
            "Direct comparison: does removing high-SI kernels cause more "
            "damage than low-SI?"
        ),
        "mean_diff": float(np.mean(hi_vs_lo_diff)),
        "paired_t_stat": float(t_hl),
        "paired_t_pval": float(p_hl),
        "high_si_worse": bool(np.mean(hi_vs_lo_diff) > 0 and p_hl < 0.05),
    }

    return analysis


def generate_verdict(analysis: dict[str, Any]) -> str:
    """Generate a textual verdict from the analysis."""
    parts: list[str] = []

    any_significant = False
    for cond_name in (
        "subtract_kernel_high_si",
        "subtract_kernel_low_si",
        "subtract_kernel_all",
    ):
        comp = analysis["comparisons"][cond_name]
        if comp["paired_t_pval"] < 0.05 and comp["mean_loss_increase"] > 0:
            any_significant = True
            break

    all_comp = analysis["comparisons"]["subtract_kernel_all"]
    hi_comp = analysis["comparisons"]["subtract_kernel_high_si"]
    lo_comp = analysis["comparisons"]["subtract_kernel_low_si"]

    if not any_significant:
        parts.append(
            "VERDICT: The positional kernel is NOT functionally relevant. "
            "Removing the estimated shift-invariant kernel from attention "
            "logits does not significantly increase loss under any condition."
        )
    else:
        parts.append(
            "VERDICT: The positional kernel IS functionally relevant. "
            "Removing it significantly increases loss."
        )

    for label, comp in [
        ("all heads", all_comp),
        ("high-SI", hi_comp),
        ("low-SI", lo_comp),
    ]:
        sig = "significant" if comp["paired_t_pval"] < 0.05 else "not significant"
        parts.append(
            f"  {label}: mean loss increase = {comp['mean_loss_increase']:.4f} "
            f"(d={comp['cohens_d']:.3f}, p={comp['paired_t_pval']:.2e}, {sig})"
        )

    hvl = analysis["high_vs_low_si"]
    if hvl["high_si_worse"]:
        parts.append(
            f"  High-SI heads contribute more positional kernel effect "
            f"(diff={hvl['mean_diff']:.4f}, p={hvl['paired_t_pval']:.2e})"
        )
    else:
        parts.append(
            f"  No significant difference between high-SI and low-SI kernel "
            f"effects (diff={hvl['mean_diff']:.4f}, "
            f"p={hvl['paired_t_pval']:.2e})"
        )

    return "\n".join(parts)


# ==============================================================================
# MAIN
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Experiment 3 Theory 8: Positional kernel ablation",
    )
    parser.add_argument("--model", required=True, choices=list(MODELS.keys()))
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument(
        "--output-dir",
        default="results/experiment3/theory8_position_ablation",
    )
    parser.add_argument(
        "--estimation-seqs", type=int, default=ESTIMATION_SEQUENCES,
    )
    parser.add_argument("--eval-seqs", type=int, default=EVAL_SEQUENCES)
    parser.add_argument("--seq-len", type=int, default=SEQ_LEN)
    args = parser.parse_args()

    output_dir = Path(args.output_dir) / args.model
    output_dir.mkdir(parents=True, exist_ok=True)
    model_spec = MODELS[args.model]

    print(f"{'=' * 72}")
    print(f"Experiment 3 Theory 8: Positional Kernel Ablation -- {args.model}")
    print(f"Device: {args.device}")
    print(f"Output: {output_dir}")
    print(
        f"Estimation sequences: {args.estimation_seqs}  "
        f"Eval sequences: {args.eval_seqs}  Seq len: {args.seq_len}"
    )
    print(f"{'=' * 72}", flush=True)

    # -- Load head groups ------------------------------------------------------
    print(f"\n[1/5] Loading head groups...", flush=True)
    head_groups = load_head_groups(args.model)
    print(f"  High-SI heads: {len(head_groups['high_si'])}", flush=True)
    print(f"  Low-SI heads:  {len(head_groups['low_si'])}", flush=True)

    # -- Load sequences --------------------------------------------------------
    print(f"\n[2/5] Loading wiki sequences...", flush=True)
    total_needed = args.estimation_seqs + args.eval_seqs
    all_sequences = load_wiki_sequences(args.model, total_needed, args.seq_len)
    if len(all_sequences) < total_needed:
        print(
            f"  WARNING: only {len(all_sequences)} sequences available, "
            f"need {total_needed}",
            flush=True,
        )
        n_est = min(args.estimation_seqs, len(all_sequences) // 2)
        n_eval = len(all_sequences) - n_est
    else:
        n_est = args.estimation_seqs
        n_eval = args.eval_seqs

    estimation_seqs = all_sequences[:n_est]
    eval_seqs = all_sequences[n_est : n_est + n_eval]
    print(f"  Estimation: {len(estimation_seqs)} sequences", flush=True)
    print(f"  Evaluation: {len(eval_seqs)} sequences", flush=True)

    # -- Load model ------------------------------------------------------------
    print(f"\n[3/5] Loading model...", flush=True)
    loaded = load_model(model_spec)
    model = loaded.model.to(args.device)
    model.eval()

    # Force eager attention so we get the explicit matmul + softmax path
    # (not flash-attention or SDPA), allowing us to fold the kernel
    # correction into the attention mask.
    model.config._attn_implementation = "eager"
    for attn_module in get_attention_modules(model).values():
        if hasattr(attn_module, "config"):
            attn_module.config._attn_implementation = "eager"

    adapter = get_adapter(model_spec)
    adapter.register(model)
    print(f"  Model loaded: {model_spec.hf_id}", flush=True)
    print(f"  Attention implementation: eager (forced)", flush=True)

    cfg = get_model_config(model)
    print(
        f"  Layers: {cfg['num_layers']}, "
        f"Query heads: {cfg['num_query_heads']}, "
        f"KV heads: {cfg['num_kv_heads']}, "
        f"Head dim: {cfg['head_dim']}",
        flush=True,
    )

    # -- Phase 1: Kernel estimation --------------------------------------------
    print(f"\n[4/5] Phase 1: Kernel estimation...", flush=True)
    t0 = time.time()
    kernels = estimate_kernels(
        model, adapter, estimation_seqs, args.device, args.seq_len,
    )
    t_est = time.time() - t0
    print(f"  Kernel estimation complete in {t_est:.0f}s", flush=True)

    # Print kernel statistics for a few representative heads
    print(f"\n  Kernel statistics (sample heads):", flush=True)
    sample_heads = head_groups["high_si"][:3] + head_groups["low_si"][:3]
    for (l, h) in sample_heads:
        g = kernels.get((l, h))
        if g is not None:
            group = "high_si" if (l, h) in head_groups["high_si"] else "low_si"
            print(
                f"    L{l}H{h} ({group}): "
                f"g(0)={g[0]:.3f}  g(1)={g[1]:.3f}  g(2)={g[2]:.3f}  "
                f"max|g|={np.max(np.abs(g)):.3f}  "
                f"mean|g|={np.mean(np.abs(g)):.4f}",
                flush=True,
            )

    # Save estimated kernels
    kernel_data = {}
    for (l, h), g in kernels.items():
        kernel_data[f"L{l}H{h}"] = g.tolist()
    (output_dir / "estimated_kernels.json").write_text(
        json.dumps(kernel_data, indent=None), encoding="utf-8",
    )
    print(
        f"  Kernels saved to {output_dir / 'estimated_kernels.json'}",
        flush=True,
    )

    # -- Phase 2: Evaluation ---------------------------------------------------
    print(f"\n[5/5] Phase 2: Evaluation with kernel subtraction...", flush=True)
    t0 = time.time()
    losses = run_evaluation(
        model, kernels, head_groups, eval_seqs, args.device, args.seq_len,
    )
    t_eval = time.time() - t0
    print(f"  Evaluation complete in {t_eval:.0f}s", flush=True)

    # -- Statistical analysis --------------------------------------------------
    print(f"\nAnalyzing results...", flush=True)
    analysis = compute_statistics(losses, len(eval_seqs), args.seq_len)
    verdict = generate_verdict(analysis)

    # -- Print summary ---------------------------------------------------------
    print(f"\n{'=' * 72}")
    print(f"RESULTS -- {args.model}")
    print(f"{'=' * 72}")

    for cond_name in (
        "baseline",
        "subtract_kernel_high_si",
        "subtract_kernel_low_si",
        "subtract_kernel_all",
    ):
        cond = analysis[cond_name]
        line = (
            f"  {cond_name:30s}: "
            f"mean={cond['mean_loss']:.4f}  "
            f"median={cond['median_loss']:.4f}"
        )
        if "mean_loss_increase" in cond:
            line += f"  increase={cond['mean_loss_increase']:+.4f}"
        if "relative_increase_pct" in cond:
            line += f"  ({cond['relative_increase_pct']:+.2f}%)"
        print(line, flush=True)

    print(
        f"\n  Statistical comparisons (per-sequence paired tests):",
        flush=True,
    )
    for cond_name, comp in analysis["comparisons"].items():
        if comp["paired_t_pval"] < 0.001:
            sig = "***"
        elif comp["paired_t_pval"] < 0.01:
            sig = "**"
        elif comp["paired_t_pval"] < 0.05:
            sig = "*"
        else:
            sig = "n.s."
        print(
            f"    {cond_name:30s}: "
            f"d={comp['cohens_d']:+.4f}  "
            f"t={comp['paired_t_stat']:+.3f}  "
            f"p={comp['paired_t_pval']:.2e} {sig}  "
            f"CI=[{comp['bootstrap_ci_95'][0]:+.4f}, "
            f"{comp['bootstrap_ci_95'][1]:+.4f}]  "
            f"frac_increased={comp['fraction_sequences_increased']:.0%}",
            flush=True,
        )

    hvl = analysis["high_vs_low_si"]
    print(
        f"\n  High-SI vs Low-SI: diff={hvl['mean_diff']:+.4f}  "
        f"t={hvl['paired_t_stat']:+.3f}  p={hvl['paired_t_pval']:.2e}  "
        f"high_worse={hvl['high_si_worse']}",
        flush=True,
    )

    print(f"\n{verdict}", flush=True)

    # -- Save report -----------------------------------------------------------
    report = {
        "experiment": "3_theory8_position_ablation",
        "model": args.model,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "config": {
            "estimation_sequences": len(estimation_seqs),
            "eval_sequences": len(eval_seqs),
            "seq_len": args.seq_len,
            "n_high_si_heads": len(head_groups["high_si"]),
            "n_low_si_heads": len(head_groups["low_si"]),
            "total_heads": cfg["num_layers"] * cfg["num_query_heads"],
            "bootstrap_n": BOOTSTRAP_N,
        },
        "analysis": analysis,
        "verdict": verdict,
        "runtime": {
            "kernel_estimation_s": round(t_est, 1),
            "evaluation_s": round(t_eval, 1),
            "total_s": round(t_est + t_eval, 1),
        },
    }
    (output_dir / "report.json").write_text(
        json.dumps(report, indent=2, default=str), encoding="utf-8",
    )
    print(f"\n  Report saved to {output_dir / 'report.json'}", flush=True)
    print(f"  Total runtime: {t_est + t_eval:.0f}s", flush=True)
    print(f"  Done.", flush=True)


if __name__ == "__main__":
    main()
