#!/usr/bin/env python3
"""
Experiment 3.2b: Sub-Word Boundary Attention Analysis
=====================================================

Tests the hypothesis that high shift-invariance R² heads are primarily
performing sub-word/token composition (merging BPE fragments like
"un" + "break" + "able" into word-level representations).

For each head, we measure:
  (a) Mean attention distance (in tokens)
  (b) Within-word attention fraction: what fraction of attention mass
      falls on tokens belonging to the SAME word as the query token?
  (c) Sub-word boundary preference: among within-word attention, how
      much goes to adjacent sub-word tokens vs. non-adjacent?
  (d) Cross-word attention fraction: attention to tokens in different words

Word boundaries are detected using the tokenizer's Ġ (space) prefix:
tokens starting with Ġ begin a new word, tokens without it continue
the current word.

Predictions if sub-word composition hypothesis is correct:
  - High-SI heads should have SHORT mean attention distances
  - High-SI heads should have HIGH within-word attention fractions
  - High-SI heads should show STRONG sub-word boundary preference
  - These patterns should be concentrated in early layers

Usage
-----
    python scripts/experiment3_subword_boundary_attention.py --model llama-3.1-8b --device cuda:0
    python scripts/experiment3_subword_boundary_attention.py --model olmo-2-7b --device cuda:1
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

import torch
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from shared.attention.adapters import get_adapter
from shared.specs import ModelSpec

# ── constants ────────────────────────────────────────────────────────────────
NUM_SEQUENCES = 100         # natural text sequences to analyze
SEQ_LEN = 512               # tokens per sequence
NUM_R2_SEQUENCES = 50

MODELS: dict[str, ModelSpec] = {
    "llama-3.1-8b": ModelSpec(
        name="llama-3.1-8b",
        hf_id="meta-llama/Meta-Llama-3.1-8B",
        norm="RMSNorm",
        pe_scheme="RoPE",
        notes="Llama 3.1 8B (GQA: 32Q/8KV heads).",
    ),
    "olmo-2-7b": ModelSpec(
        name="olmo-2-7b",
        hf_id="allenai/OLMo-2-1124-7B",
        norm="LayerNorm",
        pe_scheme="RoPE",
        notes="OLMo 2 7B.",
        download_kwargs=(("torch_dtype", "bfloat16"),),
    ),
}


def load_natural_text_sequences(
    tokenizer, model_name: str, num_sequences: int, seq_len: int
) -> list[list[int]]:
    """Load tokenized wiki sequences for attention analysis."""
    data_dir = Path("data/experiment1/wiki40b_en_pre2019") / model_name
    candidates = sorted(data_dir.rglob("*.jsonl"))
    if not candidates:
        raise FileNotFoundError(f"No tokenized JSONL found in {data_dir}")

    sequences = []
    for jsonl_path in candidates:
        with open(jsonl_path) as f:
            for line in f:
                row = json.loads(line)
                tokens = row.get("tokens", row.get("input_ids", []))
                if len(tokens) >= seq_len:
                    sequences.append(tokens[:seq_len])
                if len(sequences) >= num_sequences:
                    break
        if len(sequences) >= num_sequences:
            break

    return sequences


def compute_word_boundaries(tokenizer, token_ids: list[int]) -> list[int]:
    """Assign a word_id to each token position based on Ġ prefix.

    Returns a list where word_ids[i] is the word index for token i.
    Tokens with Ġ prefix start a new word; tokens without it continue
    the current word.
    """
    token_strings = tokenizer.convert_ids_to_tokens(token_ids)
    word_ids = []
    current_word = 0

    for i, ts in enumerate(token_strings):
        if ts is None:
            word_ids.append(current_word)
            continue
        # Ġ prefix = start of new word (space before this token)
        # Also handle the first token (no prefix but starts word 0)
        if i == 0:
            word_ids.append(current_word)
        elif ts.startswith("Ġ") or ts.startswith("▁"):
            current_word += 1
            word_ids.append(current_word)
        else:
            word_ids.append(current_word)

    return word_ids


def compute_word_token_counts(word_ids: list[int]) -> dict[int, int]:
    """Count how many tokens each word spans."""
    from collections import Counter
    return dict(Counter(word_ids))


def analyze_attention_patterns(
    model,
    adapter,
    tokenizer,
    model_spec: ModelSpec,
    device: str,
    sequences: list[list[int]],
) -> pd.DataFrame:
    """For each (layer, head), compute attention statistics on natural text.

    Metrics per head (averaged across sequences and query positions):
      - mean_attn_distance: weighted average |query_pos - key_pos|
      - within_word_fraction: fraction of attention mass on same-word tokens
      - adjacent_subword_fraction: fraction on immediately adjacent tokens
        within the same word (tokens at distance 1 that share word_id)
      - cross_word_fraction: 1 - within_word_fraction
      - multitoken_word_within_fraction: within-word fraction computed ONLY
        for query tokens that are part of multi-token words (the real test)
    """
    n_seq = len(sequences)

    # Accumulators: (layer, head) -> list of per-sequence metrics
    head_metrics: dict[tuple[int, int], dict[str, list[float]]] = {}

    for seq_idx, tokens in enumerate(sequences):
        input_ids = torch.tensor([tokens], dtype=torch.long, device=device)

        # Get word boundaries
        word_ids = compute_word_boundaries(tokenizer, tokens)
        word_ids_arr = np.array(word_ids)
        word_counts = compute_word_token_counts(word_ids)

        # Identify multi-token word positions (for focused analysis)
        is_multitoken = np.array([word_counts[wid] > 1 for wid in word_ids])

        # Capture attention
        capture = adapter.capture(
            model,
            input_ids=input_ids,
            include_logits=True,
            return_token_logits=False,
            capture_attention=True,
            output_device="cpu",
        )

        if capture.logits is None:
            continue

        n_layers, n_heads, seq_len, _ = capture.logits.shape

        # Apply causal mask and softmax to get attention weights
        causal_mask = torch.triu(torch.ones(seq_len, seq_len), diagonal=1).bool()
        logits = capture.logits.clone()
        logits[..., causal_mask] = float('-inf')
        attn_weights = torch.softmax(logits, dim=-1).numpy()  # [layers, heads, seq, seq]

        # Precompute distance matrix and same-word matrix
        positions = np.arange(seq_len)
        dist_matrix = np.abs(positions[:, None] - positions[None, :])  # [seq, seq]
        same_word_matrix = (word_ids_arr[:, None] == word_ids_arr[None, :])  # [seq, seq]

        # Adjacent sub-word: same word AND distance == 1
        adjacent_subword_matrix = same_word_matrix & (dist_matrix == 1)

        # Causal mask for metrics (only attend to past)
        causal_np = np.tril(np.ones((seq_len, seq_len), dtype=bool))

        for layer_idx in range(n_layers):
            for head_idx in range(n_heads):
                attn = attn_weights[layer_idx, head_idx]  # [seq, seq]

                # Mean attention distance (weighted by attention weights)
                # Only over causal positions
                weighted_dist = (attn * dist_matrix * causal_np).sum(axis=-1)
                # Normalize per query position (attn should sum to ~1 per row anyway)
                mean_dist = weighted_dist.mean()

                # Within-word fraction (all positions)
                within_word = (attn * same_word_matrix * causal_np).sum(axis=-1)
                within_word_frac = within_word.mean()

                # Adjacent sub-word fraction
                adj_subword = (attn * adjacent_subword_matrix * causal_np).sum(axis=-1)
                adj_subword_frac = adj_subword.mean()

                # Multi-token word analysis: within-word fraction ONLY for
                # query positions that are part of multi-token words
                if is_multitoken.any():
                    mt_within = within_word[is_multitoken].mean()
                    mt_adj = adj_subword[is_multitoken].mean()
                else:
                    mt_within = 0.0
                    mt_adj = 0.0

                key = (layer_idx, head_idx)
                entry = head_metrics.setdefault(key, {
                    "mean_attn_distance": [],
                    "within_word_fraction": [],
                    "adjacent_subword_fraction": [],
                    "multitoken_within_word_frac": [],
                    "multitoken_adj_subword_frac": [],
                })
                entry["mean_attn_distance"].append(float(mean_dist))
                entry["within_word_fraction"].append(float(within_word_frac))
                entry["adjacent_subword_fraction"].append(float(adj_subword_frac))
                entry["multitoken_within_word_frac"].append(float(mt_within))
                entry["multitoken_adj_subword_frac"].append(float(mt_adj))

        del capture, input_ids, logits, attn_weights
        torch.cuda.empty_cache()

        if (seq_idx + 1) % 10 == 0 or seq_idx == 0:
            # Print word statistics for first sequence
            if seq_idx == 0:
                n_words = len(set(word_ids))
                mt_count = sum(1 for wid, cnt in word_counts.items() if cnt > 1)
                print(f"  Seq 0 stats: {seq_len} tokens, {n_words} words, "
                      f"{mt_count} multi-token words ({100*is_multitoken.mean():.1f}% of positions)")
            print(f"  Attention analysis: {seq_idx + 1}/{n_seq} sequences")

    # Average across sequences
    rows = []
    for (layer, head), metrics in head_metrics.items():
        rows.append({
            "layer": layer,
            "head": head,
            "mean_attn_distance": np.mean(metrics["mean_attn_distance"]),
            "within_word_fraction": np.mean(metrics["within_word_fraction"]),
            "adjacent_subword_fraction": np.mean(metrics["adjacent_subword_fraction"]),
            "cross_word_fraction": 1.0 - np.mean(metrics["within_word_fraction"]),
            "multitoken_within_word_frac": np.mean(metrics["multitoken_within_word_frac"]),
            "multitoken_adj_subword_frac": np.mean(metrics["multitoken_adj_subword_frac"]),
            "mean_attn_distance_std": np.std(metrics["mean_attn_distance"]),
            "within_word_fraction_std": np.std(metrics["within_word_fraction"]),
        })

    return pd.DataFrame(rows)


def load_r2_data(model_name: str) -> pd.DataFrame:
    """Load R² data from Experiment 3.1."""
    cached = Path("results/experiment3/theory1_si_circuits") / model_name / "per_sequence_r2.parquet"
    if cached.exists():
        r2_df = pd.read_parquet(cached)
        mean_r2 = r2_df.groupby(["layer", "head"])["r2"].mean().reset_index()
        mean_r2.columns = ["layer", "head", "mean_r2"]
        return mean_r2
    raise FileNotFoundError(f"No R² data found at {cached}. Run experiment3_theory1 first.")


def cross_reference_analysis(
    attn_df: pd.DataFrame,
    r2_df: pd.DataFrame,
    model_name: str,
) -> dict[str, Any]:
    """Cross-reference attention patterns with R² scores."""
    merged = pd.merge(attn_df, r2_df, on=["layer", "head"], how="inner")

    # Correlations
    from scipy.stats import pearsonr, spearmanr

    correlations = {}
    for metric in ["mean_attn_distance", "within_word_fraction",
                    "adjacent_subword_fraction", "multitoken_within_word_frac"]:
        r_p, p_p = pearsonr(merged["mean_r2"], merged[metric])
        r_s, p_s = spearmanr(merged["mean_r2"], merged[metric])
        correlations[metric] = {
            "pearson_r": float(r_p), "pearson_p": float(p_p),
            "spearman_r": float(r_s), "spearman_p": float(p_s),
        }

    # Split by R² quartile
    r2_q75 = merged["mean_r2"].quantile(0.75)
    r2_q25 = merged["mean_r2"].quantile(0.25)

    high_si = merged[merged["mean_r2"] >= r2_q75]
    low_si = merged[merged["mean_r2"] <= r2_q25]
    mid_si = merged[(merged["mean_r2"] > r2_q25) & (merged["mean_r2"] < r2_q75)]

    group_stats = {}
    for name, group in [("high_si_top25", high_si), ("low_si_bottom25", low_si), ("mid_si", mid_si)]:
        group_stats[name] = {
            "count": len(group),
            "mean_r2": float(group["mean_r2"].mean()),
            "mean_attn_distance": float(group["mean_attn_distance"].mean()),
            "within_word_fraction": float(group["within_word_fraction"].mean()),
            "adjacent_subword_fraction": float(group["adjacent_subword_fraction"].mean()),
            "multitoken_within_word_frac": float(group["multitoken_within_word_frac"].mean()),
            "cross_word_fraction": float(group["cross_word_fraction"].mean()),
            "mean_layer": float(group["layer"].mean()),
        }

    # Layer-binned analysis (early vs late layers)
    n_layers = merged["layer"].max() + 1
    early = merged[merged["layer"] < n_layers // 4]
    late = merged[merged["layer"] >= 3 * n_layers // 4]

    layer_analysis = {}
    for name, group in [("early_layers", early), ("late_layers", late)]:
        if len(group) == 0:
            continue
        r_p, p_p = pearsonr(group["mean_r2"], group["within_word_fraction"])
        layer_analysis[name] = {
            "count": len(group),
            "mean_r2": float(group["mean_r2"].mean()),
            "mean_within_word": float(group["within_word_fraction"].mean()),
            "mean_attn_distance": float(group["mean_attn_distance"].mean()),
            "r2_within_word_pearson_r": float(r_p),
            "r2_within_word_pearson_p": float(p_p),
        }

    # Top 20 highest-R² heads: what are their attention patterns?
    top20 = merged.nlargest(20, "mean_r2")
    top20_details = []
    for _, row in top20.iterrows():
        top20_details.append({
            "layer": int(row["layer"]),
            "head": int(row["head"]),
            "r2": float(row["mean_r2"]),
            "mean_attn_distance": float(row["mean_attn_distance"]),
            "within_word_fraction": float(row["within_word_fraction"]),
            "adjacent_subword_fraction": float(row["adjacent_subword_fraction"]),
            "multitoken_within_word_frac": float(row["multitoken_within_word_frac"]),
        })

    analysis = {
        "model": model_name,
        "n_heads": len(merged),
        "correlations": correlations,
        "group_comparison": group_stats,
        "layer_analysis": layer_analysis,
        "top20_highest_r2": top20_details,
    }

    return analysis, merged


def main():
    parser = argparse.ArgumentParser(
        description="Experiment 3.2b: Sub-Word Boundary Attention Analysis"
    )
    parser.add_argument("--model", required=True, choices=list(MODELS.keys()))
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output-dir", default="results/experiment3/subword_boundary_attention")
    parser.add_argument("--num-sequences", type=int, default=NUM_SEQUENCES)
    args = parser.parse_args()

    output_dir = Path(args.output_dir) / args.model
    output_dir.mkdir(parents=True, exist_ok=True)
    model_spec = MODELS[args.model]

    print(f"{'=' * 72}")
    print(f"Experiment 3.2b: Sub-Word Boundary Attention Analysis — {args.model}")
    print(f"Device: {args.device}")
    print(f"Output: {output_dir}")
    print(f"{'=' * 72}")

    # ── Load model ───────────────────────────────────────────────────────────
    print("\n[1/5] Loading model and tokenizer...")
    from shared.models.loading import load_model, load_tokenizer
    loader = load_model(model_spec)
    model = loader.model.to(args.device)
    model.eval()
    tokenizer = load_tokenizer(model_spec)
    adapter = get_adapter(model_spec)
    adapter.register(model)
    print(f"  Model loaded: {model_spec.hf_id}")

    # ── Load sequences ───────────────────────────────────────────────────────
    print(f"\n[2/5] Loading natural text sequences...")
    sequences = load_natural_text_sequences(tokenizer, args.model, args.num_sequences, SEQ_LEN)
    print(f"  Loaded {len(sequences)} sequences of length {SEQ_LEN}")

    # ── Attention analysis ───────────────────────────────────────────────────
    print(f"\n[3/5] Computing attention patterns on natural text...")
    t0 = time.time()
    attn_df = analyze_attention_patterns(
        model=model, adapter=adapter, tokenizer=tokenizer,
        model_spec=model_spec, device=args.device,
        sequences=sequences,
    )
    elapsed = time.time() - t0
    print(f"  Attention analysis complete: {len(attn_df)} heads in {elapsed:.1f}s")
    attn_df.to_parquet(output_dir / "attention_patterns.parquet", index=False)

    # ── Load R² and cross-reference ──────────────────────────────────────────
    print(f"\n[4/5] Cross-referencing with R² data...")
    r2_df = load_r2_data(args.model)
    analysis, merged_df = cross_reference_analysis(attn_df, r2_df, args.model)
    merged_df.to_parquet(output_dir / "merged_attention_r2.parquet", index=False)

    # ── Print results ────────────────────────────────────────────────────────
    print(f"\n{'=' * 72}")
    print(f"RESULTS — {args.model}")
    print(f"{'=' * 72}")

    print(f"\n  Correlations (R² vs attention metrics):")
    for metric, corr in analysis["correlations"].items():
        direction = "+" if corr["pearson_r"] > 0 else "-"
        sig = "***" if corr["pearson_p"] < 0.001 else ("**" if corr["pearson_p"] < 0.01 else ("*" if corr["pearson_p"] < 0.05 else "ns"))
        print(f"    {metric:40s}: r={corr['pearson_r']:+.4f} {sig}")

    print(f"\n  Group comparison (high-SI top 25% vs low-SI bottom 25%):")
    gs = analysis["group_comparison"]
    print(f"    {'Metric':<35s} {'High-SI':>10s} {'Low-SI':>10s} {'Difference':>12s}")
    print(f"    {'-'*70}")
    for metric in ["mean_attn_distance", "within_word_fraction",
                    "adjacent_subword_fraction", "multitoken_within_word_frac", "cross_word_fraction"]:
        h = gs["high_si_top25"][metric]
        l = gs["low_si_bottom25"][metric]
        print(f"    {metric:<35s} {h:10.4f} {l:10.4f} {h-l:+12.4f}")

    print(f"\n  Top 20 highest-R² heads:")
    print(f"    {'L':>3s} {'H':>3s} {'R²':>7s} {'AttnDist':>10s} {'WithinWord':>12s} {'AdjSubword':>12s} {'MT_Within':>12s}")
    for h in analysis["top20_highest_r2"]:
        print(f"    L{h['layer']:2d} H{h['head']:2d} {h['r2']:7.4f} {h['mean_attn_distance']:10.2f} "
              f"{h['within_word_fraction']:12.4f} {h['adjacent_subword_fraction']:12.4f} "
              f"{h['multitoken_within_word_frac']:12.4f}")

    if "layer_analysis" in analysis:
        print(f"\n  Layer analysis (early vs late):")
        for name, la in analysis["layer_analysis"].items():
            print(f"    {name}: mean_R²={la['mean_r2']:.4f}  within_word={la['mean_within_word']:.4f}  "
                  f"attn_dist={la['mean_attn_distance']:.2f}  "
                  f"R²↔within_word r={la['r2_within_word_pearson_r']:+.4f} (p={la['r2_within_word_pearson_p']:.2e})")

    # ── Save report ──────────────────────────────────────────────────────────
    print(f"\n[5/5] Writing report...")
    report = {
        "experiment": "3.2b_subword_boundary_attention",
        "model": args.model,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "config": {
            "num_sequences": args.num_sequences,
            "seq_len": SEQ_LEN,
        },
        "analysis": analysis,
    }
    (output_dir / "report.json").write_text(
        json.dumps(report, indent=2, default=str), encoding="utf-8"
    )
    print(f"  Report saved to {output_dir / 'report.json'}")
    print(f"\nDone. All artifacts in: {output_dir}")


if __name__ == "__main__":
    main()
