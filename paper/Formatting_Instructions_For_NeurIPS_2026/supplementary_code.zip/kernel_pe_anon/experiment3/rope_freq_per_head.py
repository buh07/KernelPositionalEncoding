#!/usr/bin/env python3
"""
Experiment 3.2c: Per-Head RoPE Frequency Decomposition
=======================================================

Tests whether high-SI / sub-word composition heads preferentially use
high-frequency RoPE pairs (small pair index = fast rotation = local patterns).

For each attention head, the dot-product logit q·kᵀ decomposes as:
    logit(i,j) = Σ_{pair p} q_p(i) · k_p(j)

where each pair p contributes a 2D dot product from the rotated pair
dimensions [2p, 2p+1].  We compute the per-pair contribution to the
total attention logit and measure:

  (a) High-frequency energy fraction: what fraction of the total |logit|
      comes from the top-25% highest-frequency pairs (pairs 0-15)?
  (b) Mean frequency index: weighted average pair index (lower = higher freq)
  (c) Frequency concentration: entropy of the per-pair energy distribution

Cross-references with R² and sub-word attention metrics from 3.2a/b.

Usage
-----
    python scripts/experiment3_rope_freq_per_head.py --model llama-3.1-8b --device cuda:0
    python scripts/experiment3_rope_freq_per_head.py --model olmo-2-7b --device cuda:1
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

import torch
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from shared.attention.adapters import get_adapter
from shared.specs import ModelSpec

# ── constants ────────────────────────────────────────────────────────────────
NUM_SEQUENCES = 50
SEQ_LEN = 512

MODELS: dict[str, ModelSpec] = {
    "llama-3.1-8b": ModelSpec(
        name="llama-3.1-8b",
        hf_id="meta-llama/Meta-Llama-3.1-8B",
        norm="RMSNorm",
        pe_scheme="RoPE",
        notes="Llama 3.1 8B (GQA: 32Q/8KV heads).",
    ),
    "olmo-2-7b": ModelSpec(
        name="olmo-2-7b",
        hf_id="allenai/OLMo-2-1124-7B",
        norm="LayerNorm",
        pe_scheme="RoPE",
        notes="OLMo 2 7B.",
        download_kwargs=(("torch_dtype", "bfloat16"),),
    ),
}


def load_sequences(model_name: str, num_sequences: int, seq_len: int) -> list[list[int]]:
    """Load tokenized wiki sequences."""
    data_dir = Path("data/experiment1/wiki40b_en_pre2019") / model_name
    candidates = sorted(data_dir.rglob("*.jsonl"))
    sequences = []
    for jsonl_path in candidates:
        with open(jsonl_path) as f:
            for line in f:
                row = json.loads(line)
                tokens = row.get("tokens", row.get("input_ids", []))
                if len(tokens) >= seq_len:
                    sequences.append(tokens[:seq_len])
                if len(sequences) >= num_sequences:
                    break
        if len(sequences) >= num_sequences:
            break
    return sequences


def compute_per_pair_energy(
    model,
    adapter,
    device: str,
    sequences: list[list[int]],
) -> pd.DataFrame:
    """For each (layer, head), compute the energy contribution of each RoPE pair.

    The adapter captures post-RoPE Q and K with shape:
        capture.q: [layers, heads, seq, head_dim]
        capture.k: [layers, heads, seq, head_dim]

    For pair p, the contribution to the logit at (i,j) is:
        contrib_p(i,j) = q[i, 2p]*k[j, 2p] + q[i, 2p+1]*k[j, 2p+1]

    We measure the causal-masked energy: Σ_{i>j} contrib_p(i,j)² per pair,
    then normalize to get a fractional energy profile per head.
    """
    # Accumulators: (layer, head) -> [n_pairs] energy sums
    energy_accum: dict[tuple[int, int], np.ndarray] = {}
    n_seq_processed = 0

    for seq_idx, tokens in enumerate(sequences):
        input_ids = torch.tensor([tokens], dtype=torch.long, device=device)

        capture = adapter.capture(
            model,
            input_ids=input_ids,
            include_logits=False,  # We'll compute per-pair ourselves
            return_token_logits=False,
            capture_attention=True,
            output_device="cpu",
        )

        # capture.q: [layers, heads, seq, head_dim]
        q = capture.q.float()  # [L, H, S, D]
        k = capture.k.float()  # [L, H, S, D]

        n_layers, n_heads, seq_len, head_dim = q.shape
        n_pairs = head_dim // 2

        # Causal mask: lower triangular (including diagonal)
        causal = torch.tril(torch.ones(seq_len, seq_len, dtype=torch.bool))
        # Exclude diagonal (self-attention is trivially high)
        causal_strict = torch.tril(torch.ones(seq_len, seq_len, dtype=torch.bool), diagonal=-1)

        for layer_idx in range(n_layers):
            for head_idx in range(n_heads):
                q_h = q[layer_idx, head_idx]  # [S, D]
                k_h = k[layer_idx, head_idx]  # [S, D]

                pair_energies = np.zeros(n_pairs, dtype=np.float64)

                for p in range(n_pairs):
                    # Extract pair dimensions
                    q_pair = q_h[:, 2*p:2*p+2]  # [S, 2]
                    k_pair = k_h[:, 2*p:2*p+2]  # [S, 2]

                    # Per-pair logit contribution: [S, S]
                    contrib = torch.matmul(q_pair, k_pair.T)  # [S, S]

                    # Causal-masked squared energy
                    masked = contrib[causal_strict]
                    pair_energies[p] = (masked ** 2).sum().item()

                key = (layer_idx, head_idx)
                if key not in energy_accum:
                    energy_accum[key] = np.zeros(n_pairs, dtype=np.float64)
                energy_accum[key] += pair_energies

        n_seq_processed += 1
        del capture, input_ids, q, k
        torch.cuda.empty_cache()

        if (seq_idx + 1) % 10 == 0 or seq_idx == 0:
            print(f"  Frequency decomposition: {seq_idx + 1}/{len(sequences)} sequences")

    # Compute per-head frequency metrics
    rows = []
    for (layer, head), energies in energy_accum.items():
        total_energy = energies.sum()
        if total_energy == 0:
            continue

        frac = energies / total_energy  # normalized energy per pair
        n_pairs = len(frac)
        pair_indices = np.arange(n_pairs)

        # High-frequency fraction (top 25% = pairs 0 to n_pairs//4-1)
        hf_cutoff = n_pairs // 4  # pairs 0-15 for 64 pairs
        hf_fraction = frac[:hf_cutoff].sum()

        # Low-frequency fraction (bottom 25% = pairs 3*n_pairs//4 to end)
        lf_cutoff = 3 * n_pairs // 4  # pairs 48-63
        lf_fraction = frac[lf_cutoff:].sum()

        # Mean frequency index (lower = higher frequency)
        mean_freq_idx = (frac * pair_indices).sum()

        # Entropy of energy distribution (higher = more spread out)
        frac_nonzero = frac[frac > 0]
        entropy = -np.sum(frac_nonzero * np.log2(frac_nonzero))

        # Peak pair (most energy)
        peak_pair = int(np.argmax(frac))

        # Energy in pairs 0-3 (very highest frequency, ~adjacent token scale)
        ultra_hf_fraction = frac[:4].sum()

        rows.append({
            "layer": layer,
            "head": head,
            "hf_fraction_top25": float(hf_fraction),
            "lf_fraction_bottom25": float(lf_fraction),
            "ultra_hf_fraction_top4": float(ultra_hf_fraction),
            "mean_freq_index": float(mean_freq_idx),
            "energy_entropy": float(entropy),
            "peak_pair": peak_pair,
            "total_energy": float(total_energy),
        })

    return pd.DataFrame(rows)


def load_r2_data(model_name: str) -> pd.DataFrame:
    """Load R² data from Experiment 3.1."""
    cached = Path("results/experiment3/theory1_si_circuits") / model_name / "per_sequence_r2.parquet"
    if cached.exists():
        r2_df = pd.read_parquet(cached)
        mean_r2 = r2_df.groupby(["layer", "head"])["r2"].mean().reset_index()
        mean_r2.columns = ["layer", "head", "mean_r2"]
        return mean_r2
    raise FileNotFoundError(f"No R² data at {cached}")


def load_subword_data(model_name: str) -> pd.DataFrame:
    """Load sub-word attention metrics from 3.2b."""
    path = Path("results/experiment3/subword_boundary_attention") / model_name / "attention_patterns.parquet"
    if path.exists():
        return pd.read_parquet(path)
    raise FileNotFoundError(f"No sub-word data at {path}")


def load_induction_data(model_name: str) -> pd.DataFrame:
    """Load induction scores from 3.2a."""
    path = Path("results/experiment3/induction_r2_crossref") / model_name / "induction_scores.parquet"
    if path.exists():
        return pd.read_parquet(path)
    raise FileNotFoundError(f"No induction data at {path}")


def cross_reference_analysis(
    freq_df: pd.DataFrame,
    r2_df: pd.DataFrame,
    subword_df: pd.DataFrame,
    induction_df: pd.DataFrame,
    model_name: str,
) -> tuple[dict[str, Any], pd.DataFrame]:
    """Cross-reference frequency profiles with R², sub-word, and induction data."""
    from scipy.stats import pearsonr, spearmanr

    # Merge all data
    merged = freq_df.copy()
    merged = pd.merge(merged, r2_df, on=["layer", "head"], how="inner")
    merged = pd.merge(merged, subword_df[["layer", "head", "within_word_fraction",
                                            "adjacent_subword_fraction",
                                            "multitoken_within_word_frac",
                                            "mean_attn_distance"]], on=["layer", "head"], how="inner")
    merged = pd.merge(merged, induction_df[["layer", "head", "induction_score"]],
                       on=["layer", "head"], how="inner")

    # Key correlations
    corr_targets = {
        "r2_vs_hf_fraction": ("mean_r2", "hf_fraction_top25"),
        "r2_vs_ultra_hf": ("mean_r2", "ultra_hf_fraction_top4"),
        "r2_vs_mean_freq_idx": ("mean_r2", "mean_freq_index"),
        "r2_vs_lf_fraction": ("mean_r2", "lf_fraction_bottom25"),
        "subword_adj_vs_hf_fraction": ("adjacent_subword_fraction", "hf_fraction_top25"),
        "subword_adj_vs_ultra_hf": ("adjacent_subword_fraction", "ultra_hf_fraction_top4"),
        "within_word_vs_hf_fraction": ("within_word_fraction", "hf_fraction_top25"),
        "induction_vs_hf_fraction": ("induction_score", "hf_fraction_top25"),
        "induction_vs_lf_fraction": ("induction_score", "lf_fraction_bottom25"),
    }

    correlations = {}
    for name, (x_col, y_col) in corr_targets.items():
        r_p, p_p = pearsonr(merged[x_col], merged[y_col])
        r_s, p_s = spearmanr(merged[x_col], merged[y_col])
        correlations[name] = {
            "pearson_r": float(r_p), "pearson_p": float(p_p),
            "spearman_r": float(r_s), "spearman_p": float(p_s),
        }

    # Group comparison: high-SI vs low-SI
    r2_q75 = merged["mean_r2"].quantile(0.75)
    r2_q25 = merged["mean_r2"].quantile(0.25)
    high_si = merged[merged["mean_r2"] >= r2_q75]
    low_si = merged[merged["mean_r2"] <= r2_q25]

    group_stats = {}
    for name, group in [("high_si_top25", high_si), ("low_si_bottom25", low_si)]:
        group_stats[name] = {
            "count": len(group),
            "mean_r2": float(group["mean_r2"].mean()),
            "hf_fraction_top25": float(group["hf_fraction_top25"].mean()),
            "lf_fraction_bottom25": float(group["lf_fraction_bottom25"].mean()),
            "ultra_hf_fraction_top4": float(group["ultra_hf_fraction_top4"].mean()),
            "mean_freq_index": float(group["mean_freq_index"].mean()),
            "energy_entropy": float(group["energy_entropy"].mean()),
            "within_word_fraction": float(group["within_word_fraction"].mean()),
            "adjacent_subword_fraction": float(group["adjacent_subword_fraction"].mean()),
            "induction_score": float(group["induction_score"].mean()),
            "mean_layer": float(group["layer"].mean()),
        }

    # Top 20 highest-R² heads: full profile
    top20 = merged.nlargest(20, "mean_r2")
    top20_details = [
        {
            "layer": int(r.layer), "head": int(r.head),
            "r2": float(r.mean_r2),
            "hf_frac": float(r.hf_fraction_top25),
            "ultra_hf_frac": float(r.ultra_hf_fraction_top4),
            "lf_frac": float(r.lf_fraction_bottom25),
            "mean_freq_idx": float(r.mean_freq_index),
            "adj_subword": float(r.adjacent_subword_fraction),
            "within_word": float(r.within_word_fraction),
            "induction": float(r.induction_score),
            "peak_pair": int(r.peak_pair),
        }
        for r in top20.itertuples()
    ]

    # Strong induction heads: what frequency do they use?
    ind_p90 = merged["induction_score"].quantile(0.90)
    strong_ind = merged[merged["induction_score"] >= ind_p90]
    induction_freq_profile = {
        "count": len(strong_ind),
        "mean_hf_fraction": float(strong_ind["hf_fraction_top25"].mean()),
        "mean_lf_fraction": float(strong_ind["lf_fraction_bottom25"].mean()),
        "mean_freq_index": float(strong_ind["mean_freq_index"].mean()),
        "mean_r2": float(strong_ind["mean_r2"].mean()),
    }

    # Sub-word-heavy heads (high adj_subword): what frequency?
    adj_p90 = merged["adjacent_subword_fraction"].quantile(0.90)
    subword_heavy = merged[merged["adjacent_subword_fraction"] >= adj_p90]
    subword_freq_profile = {
        "count": len(subword_heavy),
        "mean_hf_fraction": float(subword_heavy["hf_fraction_top25"].mean()),
        "mean_lf_fraction": float(subword_heavy["lf_fraction_bottom25"].mean()),
        "mean_freq_index": float(subword_heavy["mean_freq_index"].mean()),
        "mean_r2": float(subword_heavy["mean_r2"].mean()),
    }

    analysis = {
        "model": model_name,
        "n_heads": len(merged),
        "correlations": correlations,
        "group_comparison": group_stats,
        "top20_highest_r2": top20_details,
        "induction_head_freq_profile": induction_freq_profile,
        "subword_head_freq_profile": subword_freq_profile,
    }

    return analysis, merged


def main():
    parser = argparse.ArgumentParser(
        description="Experiment 3.2c: Per-Head RoPE Frequency Decomposition"
    )
    parser.add_argument("--model", required=True, choices=list(MODELS.keys()))
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output-dir", default="results/experiment3/rope_freq_per_head")
    parser.add_argument("--num-sequences", type=int, default=NUM_SEQUENCES)
    args = parser.parse_args()

    output_dir = Path(args.output_dir) / args.model
    output_dir.mkdir(parents=True, exist_ok=True)
    model_spec = MODELS[args.model]

    print(f"{'=' * 72}")
    print(f"Experiment 3.2c: Per-Head RoPE Frequency Decomposition — {args.model}")
    print(f"Device: {args.device}")
    print(f"Output: {output_dir}")
    print(f"{'=' * 72}")

    # ── Load model ───────────────────────────────────────────────────────────
    print("\n[1/5] Loading model and tokenizer...")
    from shared.models.loading import load_model, load_tokenizer
    loader = load_model(model_spec)
    model = loader.model.to(args.device)
    model.eval()
    tokenizer = load_tokenizer(model_spec)
    adapter = get_adapter(model_spec)
    adapter.register(model)
    print(f"  Model loaded: {model_spec.hf_id}")

    # ── Load sequences ───────────────────────────────────────────────────────
    print(f"\n[2/5] Loading sequences...")
    sequences = load_sequences(args.model, args.num_sequences, SEQ_LEN)
    print(f"  Loaded {len(sequences)} sequences")

    # ── Compute per-pair energy ──────────────────────────────────────────────
    print(f"\n[3/5] Computing per-pair RoPE energy decomposition...")
    t0 = time.time()
    freq_df = compute_per_pair_energy(model, adapter, args.device, sequences)
    elapsed = time.time() - t0
    print(f"  Frequency decomposition complete: {len(freq_df)} heads in {elapsed:.1f}s")
    freq_df.to_parquet(output_dir / "freq_profile.parquet", index=False)

    # ── Cross-reference ──────────────────────────────────────────────────────
    print(f"\n[4/5] Cross-referencing with R², sub-word, and induction data...")
    r2_df = load_r2_data(args.model)
    subword_df = load_subword_data(args.model)
    induction_df = load_induction_data(args.model)
    analysis, merged_df = cross_reference_analysis(
        freq_df, r2_df, subword_df, induction_df, args.model
    )
    merged_df.to_parquet(output_dir / "merged_all.parquet", index=False)

    # ── Print results ────────────────────────────────────────────────────────
    print(f"\n{'=' * 72}")
    print(f"RESULTS — {args.model}")
    print(f"{'=' * 72}")

    print(f"\n  Key correlations:")
    for name, c in analysis["correlations"].items():
        sig = "***" if c["pearson_p"] < 0.001 else ("**" if c["pearson_p"] < 0.01 else ("*" if c["pearson_p"] < 0.05 else "ns"))
        print(f"    {name:45s}: r={c['pearson_r']:+.4f} {sig}")

    print(f"\n  Group comparison (high-SI top 25% vs low-SI bottom 25%):")
    gs = analysis["group_comparison"]
    print(f"    {'Metric':<30s} {'High-SI':>10s} {'Low-SI':>10s} {'Diff':>10s}")
    print(f"    {'-' * 65}")
    for m in ["hf_fraction_top25", "ultra_hf_fraction_top4", "lf_fraction_bottom25",
              "mean_freq_index", "energy_entropy"]:
        h = gs["high_si_top25"][m]
        l = gs["low_si_bottom25"][m]
        print(f"    {m:<30s} {h:10.4f} {l:10.4f} {h - l:+10.4f}")

    print(f"\n  Sub-word-heavy heads (top 10% adj_subword) frequency profile:")
    sp = analysis["subword_head_freq_profile"]
    print(f"    n={sp['count']}, HF_frac={sp['mean_hf_fraction']:.4f}, "
          f"LF_frac={sp['mean_lf_fraction']:.4f}, mean_freq_idx={sp['mean_freq_index']:.1f}, "
          f"mean_R²={sp['mean_r2']:.4f}")

    print(f"\n  Induction heads (top 10%) frequency profile:")
    ip = analysis["induction_head_freq_profile"]
    print(f"    n={ip['count']}, HF_frac={ip['mean_hf_fraction']:.4f}, "
          f"LF_frac={ip['mean_lf_fraction']:.4f}, mean_freq_idx={ip['mean_freq_index']:.1f}, "
          f"mean_R²={ip['mean_r2']:.4f}")

    print(f"\n  Top 10 highest-R² heads — full profile:")
    print(f"    {'L':>3s} {'H':>3s} {'R²':>6s} {'HF%':>7s} {'UHF%':>7s} {'LF%':>7s} {'MFI':>6s} {'AdjSub':>8s} {'WW':>8s} {'Ind':>7s} {'PkPr':>5s}")
    for h in analysis["top20_highest_r2"][:10]:
        print(f"    L{h['layer']:2d} H{h['head']:2d} {h['r2']:.4f} {h['hf_frac']:7.4f} {h['ultra_hf_frac']:7.4f} "
              f"{h['lf_frac']:7.4f} {h['mean_freq_idx']:6.1f} {h['adj_subword']:8.4f} "
              f"{h['within_word']:8.4f} {h['induction']:7.4f} {h['peak_pair']:5d}")

    # ── Save report ──────────────────────────────────────────────────────────
    print(f"\n[5/5] Writing report...")
    report = {
        "experiment": "3.2c_rope_freq_per_head",
        "model": args.model,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "config": {
            "num_sequences": args.num_sequences,
            "seq_len": SEQ_LEN,
        },
        "analysis": analysis,
    }
    (output_dir / "report.json").write_text(
        json.dumps(report, indent=2, default=str), encoding="utf-8"
    )
    print(f"  Report saved to {output_dir / 'report.json'}")
    print(f"\nDone. All artifacts in: {output_dir}")


if __name__ == "__main__":
    main()
