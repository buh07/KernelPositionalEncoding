# Experiment 2 Operations Log (Runbook Archive)

This file holds operational commands and runbook snippets intentionally removed from the scientific overview narrative.

## Scope and policy
1. Operational procedures belong here, not in evidence interpretation sections.
2. Commands are historical templates; use run-specific IDs and environment checks before execution.
3. This file is not a claim source; claims must cite run artifacts.

## Adapter smoke check template
```bash
.venv/bin/python scripts/experiment2_adapter_smoke.py --models all --device cuda:0 --include-logits
```

## Lightweight Exp1 continuity template
```bash
.venv/bin/python experiment1/run.py tokenize --model-profile scaleup_78b --model all --dataset wiki40b_en_pre2019 --seq-len 1024
.venv/bin/python experiment1/run.py track-a --model-profile scaleup_78b --model all --dataset wiki40b_en_pre2019 --seq-len 1024 --device cuda
.venv/bin/python experiment1/run.py track-b --model-profile scaleup_78b --model all --dataset wiki40b_en_pre2019 --seq-len 1024 --device cuda --track-b-centering-mode legacy_per_position --track-b-output-group track_b_scaleup78b_rawcheck
```

## Scale-up feasibility templates
Build:
```bash
.venv/bin/python experiment2/run.py --mode feasibility-build --model-profile scaleup_78b --h12-endpoint-policy co_primary_raw_headroom --run-id exp2_feas_scaleup_<timestamp> --output-root results/experiment2 --device cuda --feasibility-offsets 8,12,16,24,32,48,64,96,128 --lock-candidate-offsets 8,12,16,24,32,48,64,96,128 --floor-threshold 0.15 --print-summary
```

Execute seed shards:
```bash
.venv/bin/python experiment2/run.py --mode execute --manifest results/experiment2/feasibility/exp2_feas_scaleup_<timestamp>/manifest.jsonl --device cuda --output-root results/experiment2 --feasibility-task-only --synthetic-eval-mode restricted --candidate-size 10 --seed-start 0 --seed-end 0 --print-summary
.venv/bin/python experiment2/run.py --mode execute --manifest results/experiment2/feasibility/exp2_feas_scaleup_<timestamp>/manifest.jsonl --device cuda --output-root results/experiment2 --feasibility-task-only --synthetic-eval-mode restricted --candidate-size 10 --seed-start 1 --seed-end 1 --print-summary
.venv/bin/python experiment2/run.py --mode execute --manifest results/experiment2/feasibility/exp2_feas_scaleup_<timestamp>/manifest.jsonl --device cuda --output-root results/experiment2 --feasibility-task-only --synthetic-eval-mode restricted --candidate-size 10 --seed-start 2 --seed-end 2 --print-summary
```

Finalize and lock:
```bash
.venv/bin/python experiment2/run.py --mode feasibility-finalize --model-profile scaleup_78b --run-id exp2_feas_scaleup_<timestamp> --output-root results/experiment2 --feasibility-offsets 8,12,16,24,32,48,64,96,128 --lock-candidate-offsets 8,12,16,24,32,48,64,96,128 --long-task-feasibility-policy retrieval_fallback --floor-threshold 0.15 --print-summary
.venv/bin/python experiment2/run.py --mode lock-long-offsets --model-profile scaleup_78b --sweep-run-id exp2_feas_scaleup_<timestamp> --output-root results/experiment2 --feasibility-offsets 8,12,16,24,32,48,64,96,128 --lock-candidate-offsets 8,12,16,24,32,48,64,96,128 --long-task-feasibility-policy retrieval_fallback --floor-threshold 0.15 --apply --print-summary
```

## Track B OOM recovery template
```bash
bash scripts/scaleup78b_trackb_512_recovery_launch.sh <run_tag>
```
