# Experiment 2 Unexecuted Protocol Phases (Archive)

This file archives phase definitions that were protocol-specified but not executed as primary evidence in the current Experiment 2 narrative rewrite.

## Scope
1. This archive preserves Phase 2C/2D specifications for reproducibility.
2. These phases must not be interpreted as executed evidence unless a corresponding run artifact is explicitly cited.
3. Current scientific narrative in `experiment2overview.md` is results-first and execution-grounded.

## Archived Phase 2C (Exploratory Expansion)
Planned scope:
1. RoPE len-256 sensitivity for 3 RoPE models.
2. AbsPE analog controls (`gpt2-small`, `gpt2-medium`).
3. NoPE baseline (`tinyllama-nope-1.1b`).
4. Tier-1 strong-only transfer subset.
5. Optional span-bridge matrix (`spans={32,64,96}`).

Planned matrix totals:
1. Base Phase 2C total: `762`.
2. Span-bridge add-on: `360`.
3. Combined total: `1122`.

Planned interpretation rule:
1. Exploratory-only; no override of confirmatory H1/H2 adjudication.
2. 7-seed rerun required before headline-style claims from 5-seed exploratory slices.

## Archived Phase 2D (Exploratory Mechanism Probing)
Planned trigger:
1. Execute only if Phase 2B confirmatory criteria 1-5 pass.

Planned scope:
1. Models: `olmo-1b`, `llama-3.2-1b`.
2. Scope-aligned early/deep head-group probing.
3. Tasks: all 4 synthetic tasks at `seq_len=1024`.
4. Seeds: `5`.

Planned matrix totals:
1. Targeted/random interventions: `960`.
2. Optional fallback baselines: up to `40`.

Planned interpretation rule:
1. Exploratory mechanism claims only.
2. 7-seed rerun required for headline-level phrasing.

## Archive Boundary
1. This archive is historical protocol context.
2. Active evidence and conclusions remain in:
   - `experiment2/experiment2overview.md`
   - `experiment2/experiment2presentation.html`
