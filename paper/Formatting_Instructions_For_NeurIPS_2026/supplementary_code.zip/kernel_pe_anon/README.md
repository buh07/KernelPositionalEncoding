# Supplementary Code: The Missing Positional Story in LLMs

This package contains the full experimental codebase for the NeurIPS 2026 submission
**"The Missing Positional Story in LLMs: A Case Study of Shift-Invariant Attention"**.

An identified public repository URL will be provided at camera-ready.

---

## Contents

```
kernel_pe_anon/
├── shared/              # Core utilities: model loading, attention hooks, tokenization
├── experiment1/         # SI measurement (R² per head, Track A + B)
├── experiment2/         # Pairwise intervention sweep
├── experiment3/         # Theory battery + Phase 2 adjudication
├── experiment4/         # SI-guided fine-tuning (Exp. 4A/4C)
├── experiment5/         # Tokenizer effect audit (Exp. 5A/5D)
├── experiment6/         # Extended causal probes
├── experiment7/         # Coherence-gap proxy + phase-transition model (Exp. 7A/7B)
├── experiment8/         # Tokenizer boundary analysis (Exp. 8A)
├── reinforce_exp/       # Reinforcement analyses R1–R5 (multi-domain, PE scheme, etc.)
├── reinforce_exp2/      # Reinforcement analyses Phase B/C (carrier sets, causal trace)
├── reinforce_exp3/      # Robustness controls RC1–RC19 and breadth extensions BC1–BC4
├── scripts/             # Launch scripts, asset downloader, figure generator
├── tests/               # Unit and regression tests
├── pyproject.toml       # Package metadata and loose dependency spec
└── requirements.txt     # Pinned dependency versions (use this for exact reproduction)
```

---

## Hardware Requirements

| Component | Minimum | Used in this work |
|-----------|---------|-------------------|
| GPU VRAM  | 48 GB per card (for 7–8B models at full precision) | Quadro RTX 8000 (48 GB) |
| GPU count | 1 (sequential); 3–6 recommended for full pipeline | 6 × RTX 8000 |
| System RAM | 64 GB | 256 GB |
| Disk      | ~200 GB (models + results) | ~400 GB |
| CUDA      | ≥ 12.1 | 12.8 |
| Python    | 3.10–3.12 | 3.12.3 |

The 1B proxy-scale experiments (experiment1, RC5/RC6) run on a single GPU with ≥16 GB VRAM.
All 7–8B experiments require ≥48 GB VRAM per model due to full-precision forward passes with
intermediate activation capture.

---

## Installation

```bash
# 1. Create and activate a virtual environment
python3 -m venv .venv
source .venv/bin/activate

# 2. Install PyTorch with CUDA 12.x support first
pip install torch==2.7.0 torchvision==0.22.0 --index-url https://download.pytorch.org/whl/cu128

# 3. Install all remaining pinned dependencies
pip install -r requirements.txt

# 4. Install the package itself in editable mode
pip install -e .
```

Alternatively, `scripts/setup_env.sh` automates steps 1 and 4 (but uses unpinned deps;
prefer the manual steps above for exact reproduction).

---

## Model Access

Several models require accepting a license on Hugging Face before downloading.
Log in with a token that has been granted access:

```bash
huggingface-cli login   # paste your HF token when prompted
```

Models requiring license acceptance:
- `meta-llama/Meta-Llama-3.1-8B` — Meta Llama 3 Community License
- `meta-llama/Llama-3.2-1B` — Meta Llama 3 Community License
- `google/gemma-2-9b` — Google Gemma Terms of Use

Freely available (no license gate):
- `mistralai/Mistral-7B-v0.1` (Apache 2.0)
- `allenai/OLMo-2-1124-7B` (Apache 2.0)
- `openai-community/gpt2`, `openai-community/gpt2-medium` (MIT)
- `TinyLlama/TinyLlama-1.1B-intermediate-step-1431k-3T` (Apache 2.0)
- `AntNLP/TinyLlama-NoPE-1.1B` (Apache 2.0)
- `EleutherAI/pythia-410m`, `EleutherAI/pythia-1.4b` (Apache 2.0)
- `Qwen/Qwen2.5-7B` (Tongyi Qianwen License)

---

## Data Download

All datasets are publicly available through the Hugging Face `datasets` library.

```python
# wiki40b (primary evaluation corpus; requires agreement on HF)
from datasets import load_dataset
ds = load_dataset("wiki40b", "en", split="train")

# CodeSearchNet (functional sensitivity probes)
ds = load_dataset("code_search_net", "python", split="train")

# MATH benchmark (experiment 4 evaluation)
ds = load_dataset("hendrycks/competition_math", split="test")
```

The asset downloader script handles all three automatically:

```bash
# Download datasets only (no models)
python scripts/download_assets.py --experiments experiment1 experiment3 experiment4 \
    --datasets-only

# Download 7–8B primary models only
python scripts/download_assets.py --experiments experiment3 \
    --model-profile scaleup_7b --models-only \
    --names llama-3.1-8b olmo-2-7b mistral-7b-v0.1
```

Models are stored under `models/<model-name>/` and datasets under `data/`.
Both paths are resolved relative to the repo root by `shared/config.py`.

---

## Reproducing Main-Text Claims

The table below maps each main-text section / claim to the entry-point script.
All commands assume the repo root as the working directory and `.venv` activated.

### Section 3 — Measurement: R² per head

```bash
# Run Track A (R² scoring) for primary 7–8B models on wiki40b
python -m experiment3.run theory1 --model llama-3.1-8b  --device cuda:0
python -m experiment3.run theory1 --model olmo-2-7b     --device cuda:0
python -m experiment3.run theory1 --model mistral-7b-v0.1 --device cuda:0

# Produces per-head R² parquet files in:
#   results/experiment3/theory1_si_circuits/<model>/kernels_g_h.parquet
#   results/experiment3/theory1_si_circuits/<model>/head_r2_summary.parquet
```

For 1B proxy scale (experiment 1, Figure 1 right panel):

```bash
python -m experiment1.run --model-profile legacy_1b --device cuda:0
```

### Section 4 — Head-Level SI Under Intervention (primary result)

The core intervention result (LM-loss deltas, permutation specificity, dose-response):

```bash
# Kernel ablation + permutation control (RC1, R7) — primary 3-model result
python reinforce_exp3/scripts/run_e17_normmatched_specificity.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0

# 20-bin dose-response (RC12) — Figure 2 + Section 4 gradient claim
python reinforce_exp3/scripts/run_e28a_e26_20bin_exact.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0

# Importance-matched non-SI baseline (RC13)
python reinforce_exp3/scripts/run_e28b_importance_matched_control.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0

# Kernel-transplant specificity (RC15)
python reinforce_exp3/scripts/run_e29a_kernel_transplant_specificity.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0

# Kernel-permutation specificity (R7) — cross-model permutation-specific disruption
python reinforce_exp/exp_new_r14_kernel_permutation.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0

# Absolute-threshold robustness (RC11) — replicates rank-based result at fixed thresholds
python reinforce_exp3/scripts/run_e27_absolute_threshold_robustness.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0
```

### Section 4 — Variance decomposition / proxy heterogeneity (proxy scale)

```bash
# RC5: seed-variance vs. between-model variance decomposition (1B proxy)
python reinforce_exp3/scripts/run_e20_heterogeneity_variance_decomp.py --device cuda:0

# RC6: controlled RoPE vs. NoPE comparison (TinyLlama paired)
python reinforce_exp3/scripts/run_e21_pe_family_training_contrast.py --device cuda:0
```

### Section 5 — Functional Sensitivity

```bash
# Offset-repetition retrieval probe (primary functional result)
python reinforce_exp3/scripts/run_e12_icl_sensitivity.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0

# RC2: strict format-confound adjudication
python reinforce_exp3/scripts/run_e18_icl_format_confound.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0

# RC3: broader probe-diversity transfer (7-family)
python reinforce_exp3/scripts/run_e28c_probe_diversity_transfer.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0

# RC16: semi-naturalistic long-context extension
python reinforce_exp3/scripts/run_e29b_naturaltext_longcontext_probe.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0

# RC18: 2×2 transfer-boundary grid (short/long × high/low offset regularity)
python reinforce_exp3/scripts/run_e30a_probe_boundary_grid.py \
    --models llama-3.1-8b olmo-2-7b mistral-7b-v0.1 --device cuda:0
```

### Breadth consolidation panel — Figure 1 right (11 models, 7 families)

```bash
# BC1: breadth consolidation (reads cached R² parquets; no GPU needed after profiling)
python reinforce_exp3/scripts/run_e31a_breadth_consolidation.py
```

This script reads head_r2_summary.parquet files already produced by the profiling
runs above and by experiment5 (Pythia models). Run experiment5 first for Pythia:

```bash
python -m experiment5.run --sub-experiment 5a --device cuda:0
```

### Experiment 3 — Theory battery (Appendix B/C)

```bash
# Run all theories for a single model
python -m experiment3.run all --model llama-3.1-8b --device cuda:0

# Run a specific theory (e.g., T5a boundary detection, T7 induction feeders, T8 ablation)
python -m experiment3.run theory5b --model llama-3.1-8b --device cuda:0
python -m experiment3.run theory7  --model llama-3.1-8b --device cuda:0
python -m experiment3.run theory8  --model llama-3.1-8b --device cuda:0
```

Phase 2 adjudication (Appendix, sub-experiments A–K):

```bash
# Full Phase 2 pipeline (sequential; runs A through K for both Llama and OLMo)
bash scripts/experiment3_phase2_stage1_gpu0.sh   # Llama on GPU 0
bash scripts/experiment3_phase2_stage1_gpu1.sh   # OLMo on GPU 1
```

### Experiment 4 — SI-guided fine-tuning (Appendix D)

```bash
# 4A: SI-aware LoRA comparison (30 runs: 5 conditions × 3 seeds × 2 models)
python -m experiment4.run 4a --device cuda:0

# 4C: SI trajectory during fine-tuning (checkpoint snapshots)
python -m experiment4.run 4c --device cuda:0
```

### Experiment 7 — Coherence-gap proxy / Phase-transition model (Appendix G/H)

```bash
python -m experiment7.run 7a --device cuda:0   # coherence-gap proxy analysis
python -m experiment7.run 7b --device cuda:0   # phase-transition critical-point fitting
```

### Reinforcement analyses R1–R8 (Appendix)

```bash
# Run all reinforcement analyses sequentially (single GPU; takes several hours)
python reinforce_exp3/scripts/run_pipeline.py \
    --experiments E0,E2,E3,E4,E5,E6,E7,E8,E9,E10,E11,E12 \
    --device-map "llama-3.1-8b:cuda:0,olmo-2-7b:cuda:0,mistral-7b-v0.1:cuda:0"

# Or target individual reinforcement checks (e.g., R1 multi-domain gate)
python reinforce_exp/exp_r1_multidomain_gate.py run-seed \
    --model llama-3.1-8b --seed 0 --domains wiki,code,dialogue \
    --device cuda:0 --num-sequences 48 --output-root results/reinforce_exp/exp_r1_multidomain_gate
```

### Full robustness control suite (Appendix L, RC1–RC19 + BC1–BC4)

```bash
# Orchestrated pipeline (runs all RC/BC controls in dependency order)
python reinforce_exp3/scripts/run_pipeline.py \
    --experiments E17,E18,E19,E20,E21,E24,E24b,E25,E26,E27,E28A,E28B,E28C,E28D,E29A,E29B,E29C,E30A,E30B,E31A,E31B,E31C,E31D \
    --device-map "llama-3.1-8b:cuda:0,olmo-2-7b:cuda:1,mistral-7b-v0.1:cuda:2"
```

### Reproducing paper figures

```bash
python scripts/paper_generate_neurips_figures.py
# Figures written to paper/neurips2026/figures/
```

---

## Output Structure

All experiment outputs are written under `results/`:

```
results/
├── experiment1/              # R² tables, spectral decompositions
├── experiment3/
│   └── theory1_si_circuits/
│       └── <model>/
│           ├── kernels_g_h.parquet       # per-head offset kernel g_h(Δ)
│           └── head_r2_summary.parquet   # per-head R² scores
├── experiment4/              # LoRA fine-tuning checkpoints and accuracy tables
├── experiment5/              # Cross-tokenizer SI profiles (Pythia, etc.)
├── experiment7/              # Coherence-gap tables, phase-transition fits
├── reinforce_exp/            # R1–R5 outputs
├── reinforce_exp3/           # RC1–RC19, BC1–BC4 outputs
└── ...
```

JSON result files are loaded by the figure-generation script and the paper's
appendix tables; path references in those scripts use repo-relative paths and
do not require environment-variable configuration.

---

## Running the Test Suite

```bash
source .venv/bin/activate
pytest tests/ -v
```

Tests cover attention adapter correctness, stats utilities, and experiment-3
snapshot regressions. They do not require GPU access (CPU-only mocks are used).

---

## Compute Budget

Approximate GPU-hours to reproduce each section (single Quadro RTX 8000 equivalent):

| Section / Appendix | Est. GPU-hours | Notes |
|--------------------|---------------|-------|
| SI measurement (all 3 primary models, Exp. 1 + 3 T1) | ~12 h | Parallelises across 3 GPUs |
| Intervention + permutation controls (RC1, R7, RC11–RC15) | ~18 h | 3 models × several passes |
| Functional sensitivity battery (RC2, RC3, RC16, RC18) | ~10 h | Long-context probes are heavier |
| Proxy-scale variance / RoPE-NoPE (RC5, RC6) | ~4 h | 1B models only |
| Theory battery + Phase 2 (Exp. 3) | ~30 h | All 11 sub-experiments |
| Experiment 4 (30 LoRA runs) | ~8 h | 2 models × 5 conditions × 3 seeds |
| Reinforcement R1–R8 | ~15 h | Multi-domain seed sweeps |
| Breadth panel + coherence (BC1–BC4) | ~6 h | Lighter; reads cached R² files |
| **Total (sequential, single GPU)** | **~103 h** | ~17 h with 6× parallelism |

---

## License

Code released under the MIT License. See individual model and dataset licenses
in the paper checklist (all models accessed via Hugging Face Hub under the terms
described there).
